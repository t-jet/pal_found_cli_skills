from pathlib import Path
import subprocess, re, json, datetime

ROOT = Path.cwd()
OUT = ROOT / '.ept/tmp/rest079_acceptance_20261118/retained/cli'
OUT.mkdir(parents=True, exist_ok=True)
records = []
def call(args, name):
    result = subprocess.run(['python', '.ept/tools/tracker/tracker_cli.py', *args], capture_output=True)
    (OUT / name).write_bytes(result.stdout)
    if result.stderr:
        (OUT / (name + '.stderr')).write_bytes(result.stderr)
    records.append({'argv': args, 'exit_code': result.returncode, 'artifact': name})
    if result.returncode:
        raise RuntimeError((args, result.returncode, result.stderr.decode(errors='replace')))
    return result.stdout.decode('utf-8-sig')

for ticket in ['FEATURE-015','DEV-STORY-079','DESIGN-079','DEV-079','UNITTEST-079','CODEREVIEW-080','TESTCASE-079','TESTEXEC-079','QUESTION-197','QUESTION-199','TASK-022','TASK-023']:
    call(['get',ticket,'--author','qa-engineer'], ticket + '-get.txt')
    call(['link','list',ticket,'--direction','all','--author','qa-engineer'], ticket + '-links.txt')
    comments = call(['comment','list',ticket,'--author','qa-engineer'], ticket + '-comments.txt')
    ids = re.findall(r'^(\d{8}-\d{6}-\S+)', comments, re.M)
    for comment in ids:
        safe = comment.replace('@','at_').replace('~','_')
        call(['comment','get',ticket,comment,'--author','qa-engineer'], ticket + '-comment-' + safe + '.txt')
    print(ticket, len(ids), flush=True)
(OUT / 'capture_commands.json').write_text(json.dumps({'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':records},indent=2)+'\n',encoding='utf-8')
