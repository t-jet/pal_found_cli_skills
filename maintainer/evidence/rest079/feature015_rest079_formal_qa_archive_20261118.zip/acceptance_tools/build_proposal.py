from pathlib import Path
import json, hashlib, subprocess, copy, runpy, zipfile, shutil, collections

ROOT=Path.cwd()
BASE=ROOT/'.ept/tmp/rest079_acceptance_20261118'
RETAINED=BASE/'retained'
SKILLS=BASE/'skills'
OUT=SKILLS/'maintainer/evidence/rest079'
OUT.mkdir(parents=True,exist_ok=True)
EXECUTOR='/root/rest079_distinct_formal_executor_20261118'
ACCEPTOR='/root/rest079_independent_formal_acceptance_20261118'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def artifact(path):
    return {'path':path.relative_to(SKILLS).as_posix(),'sha256':sha(path.read_bytes())}

for filename in ['feature015_rest079_author_candidate_20261029.json','feature015_rest079_semantic_review_20261029.json','rest079_retest_probe_20261029.py','rest-ontologies-079-081-083-manifest.json']:
    shutil.copy2(ROOT/'.ept/tmp'/filename,RETAINED/'historical'/filename)
for name in ['capture_cli.py','retain_and_verify.py','build_proposal.py']:
    (RETAINED/'acceptance_tools').mkdir(exist_ok=True)
    shutil.copy2(BASE/name,RETAINED/'acceptance_tools'/name)

binding=load(RETAINED/'independent_binding_review.json')
result=load(RETAINED/'formal/formal_result.json')
coverage=load(RETAINED/'formal/formal_case_coverage.json')
manifest=load(RETAINED/'formal/formal_evidence_manifest.json')
case=load(RETAINED/'cases/rest079_formal_cases.json')
freeze=load(RETAINED/'cases/rest079_assets_freeze.json')
peer=load(RETAINED/'qa_peer/peer_review_v2.json')
approval=load(RETAINED/'techlead/techlead_case_approval_v2.json')
register_path=SKILLS/'maintainer/rest-domain-authoring-register.json'
before=load(register_path)
assert len(before['operations'])==425
selected=[r for r in before['operations'] if r['story']=='DEV-STORY-079']
assert len(selected)==32 and {r['id'] for r in selected}=={c['operation'] for c in case['operations']}
contract=load(SKILLS/'maintainer/rest-contract-register.json')
contract_rows={r['id']:r for r in contract['operations']}
assert all(contract_rows[k]==v for k,v in freeze['register_bindings'].items())
for row in selected:
    for key in ['behavior','example']:
        assert row[key+'_sha256']==freeze['assets'][row[key]]
        assert sha((SKILLS/'.agents/skills/pal-found-dev'/row[key]).read_bytes())==row[key+'_sha256']
assert all(r['independent_qa_status']=='pending' and not r['independent_qa_agent'] for r in selected)
assert sum(r['independent_qa_status']=='accepted' for r in before['operations'])==229
validation=runpy.run_path(str(SKILLS/'scripts/verify_feature015_release.py'))
baseline_report=validation['verify'](root=SKILLS)
assert not any(key in baseline_report.counts for key in ['candidate_sha','input_bundle_sha256','operation_asset_hashes','operation_source_hashes'])
current_bundle=validation['input_bundle_digest'](SKILLS/'.agents/skills/pal-found-dev')
assert current_bundle==before['input_bundle_sha256']
current_anchor=before['candidate_sha']
assert subprocess.run(['git','-C',str(SKILLS),'merge-base','--is-ancestor',current_anchor,'HEAD']).returncode==0
dump(RETAINED/'metadata_gate_baseline.json',{'counts':dict(baseline_report.counts),'examples':dict(baseline_report.examples),'candidate_sha':current_anchor,'current_input_bundle_sha256':current_bundle,'binding_gates_pass':True})
after=copy.deepcopy(before)
delta=[]
for row in after['operations']:
    if row['story']=='DEV-STORY-079':
        previous=copy.deepcopy(row)
        row['independent_qa_status']='accepted'
        row['independent_qa_agent']=EXECUTOR
        changed={key:{'before':previous[key],'after':row[key]} for key in row if previous[key]!=row[key]}
        assert set(changed)=={'independent_qa_status','independent_qa_agent'}
        delta.append({'id':row['id'],'fields':changed})
dump(register_path,after)
proposal_report=validation['verify'](root=SKILLS)
expected_counts=dict(baseline_report.counts)
expected_counts['operation_qa_pending']-=32
expected_counts['operation_qa_provenance']-=32
expected_counts={k:v for k,v in expected_counts.items() if v}
assert dict(proposal_report.counts)==expected_counts,(dict(proposal_report.counts),expected_counts)
proof={
    'kind':'PROPOSED_REST079_METADATA_ACCEPTANCE','task':'TASK-023','root_metadata_approval':'PENDING',
    'proposal_base':'51f594c08403ac49d848e0d8c4af9986377f64d2',
    'register_candidate_anchor_preserved':current_anchor,'register_current_bundle_sha256_preserved':current_bundle,
    'exact_changed_operation_rows':delta,'changed_row_count':32,'changed_fields_per_row':['independent_qa_status','independent_qa_agent'],
    'other393rows_unchanged':all(a==b for a,b in zip(before['operations'],after['operations']) if a['story']!='DEV-STORY-079'),
    'previous229accepted_rows_unchanged':all(a==b for a,b in zip(before['operations'],after['operations']) if a['independent_qa_status']=='accepted'),
    'top_level_metadata_unchanged':all(before[k]==after[k] for k in before if k!='operations'),
    'semantic_accepted':sum(r['semantic_review_status']=='accepted' for r in after['operations']),
    'formal_accepted_before':229,'formal_accepted_proposed':261,'formal_pending_before':196,'formal_pending_proposed':164,
    'baseline_release_gate_counts':dict(baseline_report.counts),'proposal_release_gate_counts':dict(proposal_report.counts),
    'release_gate_still_blocked':bool(proposal_report.counts),
    'validator_decision':'Current metadata anchor and bundle pass. Validator does not require each historical formal run to execute the current whole-reader bundle. Exact original frozen bundle remains in archive with two foreign-guide differences and no claim of current whole-reader execution.',
    'validator_sources':['scripts/verify_feature015_release.py:check_operations','scripts/verify_feature015_release.py:check_candidate_anchor','tests/test_offline_rest_acceptance.py:verify_domain_acceptance'],
    'sad_affected_gate_rule':'SA-DES-014 verification-and-delivery.md section3.4 step6 requires repeat affected gates before delivery complete. Foreign guide correction has distinct six-operation review; REST079 affected inputs equal retained executed bytes.',
    'no_execution_repeated':True,'input_binding_review_sha256':sha((RETAINED/'independent_binding_review.json').read_bytes())}
assert proof['other393rows_unchanged'] and proof['previous229accepted_rows_unchanged'] and proof['semantic_accepted']==425
dump(RETAINED/'proposal_metadata_validation.json',proof)

# Archive original bytes and independent acceptance proofs; inventory is not self-hashed.
source_prefixes={'formal':'.ept/tmp/rest079_formal_execution_20261118','cases':'.ept/tmp/feature015_rest079_formal_cases_20261118','original_nov17':'.ept/tmp/feature015_rest079_formal_cases_20261117','qa_peer':'.ept/tmp/rest079_case_peer_20261118','techlead':'.ept/tmp/rest079_case_techlead_approval_20261118'}
entries=[]
files=sorted(p for p in RETAINED.rglob('*') if p.is_file())
for path in files:
    relative=path.relative_to(RETAINED).as_posix()
    first,_,rest=relative.partition('/')
    source=source_prefixes[first]+'/'+rest if first in source_prefixes else 'Retained read-only CLI/source/review or TASK-023 acceptance proof: '+relative
    entries.append({'member':relative,'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'source':source})
inventory={'kind':'IMMUTABLE_REST079_FORMAL_EVIDENCE_INVENTORY','task':'TASK-023','executor':EXECUTOR,'acceptance_reviewer':ACCEPTOR,'formal_invocations':1,'new_formal_invocations':0,'payload_members':len(entries),'entries':entries,'archive_member_resolution':'Each member is a path inside the ZIP; SHA-256 verifies retained original bytes. Source records the original folder or immutable source/CLI provenance. Historical flags and failures remain unchanged.'}
inventory_path=OUT/'feature015_rest079_formal_qa_inventory.json'
dump(inventory_path,inventory)
archive_path=OUT/'feature015_rest079_formal_qa_archive_20261118.zip'
with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in files:
        archive.writestr(zipfile.ZipInfo(path.relative_to(RETAINED).as_posix(),(2026,11,18,0,0,0)),path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    archive.writestr('feature015_rest079_formal_qa_inventory.json',inventory_path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist())==len(entries)+1 and len(set(archive.namelist()))==len(archive.namelist())
    assert archive.testzip() is None
    for item in entries:
        assert sha(archive.read(item['member']))==item['sha256']
for relative in ['cases/rest079_formal_cases.json','cases/rest079_formal_cases.feature','cases/rest079_formal_execute.py','cases/additional_checks.py','cases/rest079_assets_freeze.json','formal/formal_result.json','formal/formal_measurement.json','formal/formal_case_coverage.json','formal/formal_evidence_manifest.json','formal/environment_preflight.json','qa_peer/peer_review_v2.json','techlead/techlead_case_approval_v2.json','independent_binding_review.json','proposal_metadata_validation.json','sdk101/LICENSE']:
    shutil.copy2(RETAINED/relative,OUT/Path(relative).name)

operations=[]
for row in coverage['scenarios']:
    if 'operation' not in row:
        continue
    operations.append({'operation':row['operation'],'case_id':row['case_id'],'checks':row['formal_check_count'],'formal_result_check_indices_zero_based':row['formal_result_check_indices_zero_based'],'result':'PASS','case_sha256':result['case_sha256'],'available_modes':6,'declared_errors':{}})
canonical={
    'story':'DEV-STORY-079','testcase':'TESTCASE-079','testexec':'TESTEXEC-079','executor':EXECUTOR,
    'case_author':case['author_identity'],'original_case_author':case['original_author_identity'],
    'case_reviewer':peer['reviewer_identity'],'techlead_case_approver':approval['reviewer_identity'],
    'source_reviewer':'/root/rest079_retest_20261029','integration_agent':ACCEPTOR,'acceptance_task':'TASK-023',
    'execution':'PASS','formal_execution':'PASS','formal_workflow_acceptance':'Closed',
    'integration_acceptance':'PROPOSED_PENDING_ROOT_METADATA_GATE','checks':len(result['checks']),'operations_count':32,'annex_scenarios':25,
    'declared_error_count':0,'sdk_release':'1.101.0','source_commit':freeze['source_commit'],
    'cases_sha256':result['case_sha256'],'harness_sha256':result['harness_sha256'],
    'case_approval_sha256':sha((RETAINED/'techlead/techlead_case_approval_v2.json').read_bytes()),
    'readiness_sha256':sha((RETAINED/'formal/current_execution_readiness.json').read_bytes()),
    'formal_run_sha256':sha((RETAINED/'formal/formal_result.json').read_bytes()),
    'source_asset_bindings_checked':4371,'primary_source_bindings_checked':14,
    'all_bindings_current_and_unchanged':False,'relevant_domain_bindings_current':True,
    'binding_review':artifact(OUT/'independent_binding_review.json'),
    'actual_results':result['checks'],'operations':operations,
    'global_checks':[r for r in result['checks'] if r['case_id'] not in {c['case_id'] for c in case['operations']}],
    'formal_attempts':1,'timing':manifest['measurement'],
    'evidence_inventory':artifact(inventory_path),'immutable_archive':artifact(archive_path),
    'closure':{'testcase':'Closed','testexec':'Closed','story':'Deployment','owner_prerequisite_decision':'QUESTION-199 Closed; PM-recorded Owner answer 20261118-132148-@project-manager','architect_incorporation':'QUESTION-197 Closed','results_comment':'20261118-181149-@qa-engineer','closure_comment':'20261118-181211-@qa-engineer','full_cli_capture':'cli/ within archive'},
    'scope':'32-operation Ontology schema/interface domain; synthetic native SDK and MockTransport fixtures; no formal rerun during retention.',
    'limits':manifest['limits'],'metadata_proposal':proof,
    'publication':'Proposal only; no shared source, commit, push or release approval.'}
canonical_path=SKILLS/'maintainer/rest-domain-formal-qa-079.json'
dump(canonical_path,canonical)
acceptance={
    'story':'DEV-STORY-079','formal_qa_status':'accepted','independent_qa_agent':EXECUTOR,
    'case_author':case['author_identity'],'original_case_author':case['original_author_identity'],
    'case_reviewer':peer['reviewer_identity'],'source_reviewer':'/root/rest079_retest_20261029',
    'integration_agent':ACCEPTOR,'acceptance_task':'TASK-023','integration_acceptance':'PROPOSED_PENDING_ROOT_METADATA_GATE',
    'operations':32,'checks':1564,'declared_errors':0,'closure':canonical['closure'],
    'canonical_evidence':artifact(canonical_path),
    'artifacts':{p.name:artifact(p) for p in sorted(OUT.iterdir()) if p.is_file()},
    'inventory_files_preserved':len(entries),'archive_members_including_inventory':len(entries)+1,
    'no_execution_repeated':True,'all_bindings_current_and_unchanged':False,'relevant_domain_bindings_current':True,
    'metadata_proposal':proof,'limits':manifest['limits'],
    'source_notices':'Original copyright headers preserved in frozen SDK sources. Frozen SDK root and reader asset include Apache-2.0 LICENSE; frozen SDK root has no separate NOTICE.',
    'archive_context_mapping':'Canonical operation check indices resolve actual_results and retained formal_result.json. Inventory paths resolve every original/history/reader/source/probe/CLI member inside immutable archive.'}
dump(SKILLS/'maintainer/rest-domain-formal-qa-079-acceptance.json',acceptance)
dump(BASE/'proposal_summary.json',{
    'proposal_clone':str(SKILLS),'task':'TASK-023','status':'PROPOSED_PENDING_ROOT_METADATA_GATE',
    'canonical':artifact(canonical_path),'acceptance':artifact(SKILLS/'maintainer/rest-domain-formal-qa-079-acceptance.json'),
    'archive':artifact(archive_path),'inventory':artifact(inventory_path),'metadata_validation':artifact(OUT/'proposal_metadata_validation.json'),
    'payload_members':len(entries),'total_archive_members':len(entries)+1,'register_delta_rows':len(delta),
    'release_gate_baseline':dict(baseline_report.counts),'release_gate_proposal':dict(proposal_report.counts)})
print((BASE/'proposal_summary.json').read_text())
