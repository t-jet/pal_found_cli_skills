from pathlib import Path
import hashlib, json, shutil, subprocess, collections, datetime, ast

ROOT = Path.cwd()
BASE = ROOT / '.ept/tmp/rest079_acceptance_20261118'
OUT = BASE / 'retained'
SKILLS = BASE / 'skills'
SDK = ROOT / '.ept/docs/customer_input/foundry-platform-python'
SOURCE = '168d51910570b6966afa2320333ab36f6a3f7ccf'
CURRENT = '51f594c08403ac49d848e0d8c4af9986377f64d2'
CASE = ROOT / '.ept/tmp/feature015_rest079_formal_cases_20261118'
FORMAL = ROOT / '.ept/tmp/rest079_formal_execution_20261118'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def git(repo,*args):
    r = subprocess.run(['git','-C',str(repo),*args],capture_output=True)
    assert r.returncode == 0, (args,r.stderr)
    return r.stdout
def retain_tree(relative, destination):
    source = ROOT / relative
    target = OUT / destination
    assert source.exists(), source
    if source.is_dir():
        shutil.copytree(source,target,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','.git'))
    else:
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target)

for relative,destination in [
    ('.ept/tmp/rest079_formal_execution_20261118','formal'),
    ('.ept/tmp/feature015_rest079_formal_cases_20261118','cases'),
    ('.ept/tmp/feature015_rest079_formal_cases_20261117','original_nov17'),
    ('.ept/tmp/rest079_case_peer_20261118','qa_peer'),
    ('.ept/tmp/rest079_case_techlead_approval_20261118','techlead'),
    ('.ept/tmp/feature015_rest079_semantic_retest_20261029.json','historical/semantic_retest_20261029.json')]:
    retain_tree(relative,destination)
for filename in ['rest-domain-independent-review-079-current.json','rest-domain-independent-review-079-initial.json','models-rest077-rest079-acceptance-20261029.json','rest-domain-independent-review-073-result-guidance-20261118.json']:
    retain_tree(str((SKILLS/'maintainer'/filename).relative_to(ROOT)),'reviews/'+filename)
for relative in [
    '.ept/docs/deliverables/architecture/SA-DES-014-offline-development-knowledge/verification-and-delivery.md',
    '.ept/docs/deliverables/development/FEATURE-015-rest-authoring-contract.md',
    '.ept/docs/deliverables/development/FEATURE-015-rest-operation-partitions.json']:
    retain_tree(relative,'requirements/'+Path(relative).name)

freeze=load(CASE/'rest079_assets_freeze.json')
manifest=load(FORMAL/'formal_evidence_manifest.json')
result=load(FORMAL/'formal_result.json')
coverage=load(FORMAL/'formal_case_coverage.json')
cases=load(CASE/'rest079_formal_cases.json')
reader=Path(freeze['skill_root'])
for name,expected in manifest['artifacts'].items():
    assert sha((FORMAL/name).read_bytes()) == expected, name
for name,expected in manifest['approved_inputs'].items():
    assert sha((CASE/name).read_bytes()) == expected, name
checks=result['checks']
assert result['formal_execution'] is True and result['outcome']=='FORMAL_EXECUTION_PASS'
assert result['executor_identity']=='/root/rest079_distinct_formal_executor_20261118'
assert len(checks)==1564 and all(c['result']=='PASS' for c in checks)
assert len(coverage['scenarios'])==57 and len({r['scenario'] for r in coverage['scenarios']})==57
assert {c['operation'] for c in cases['operations']}=={r['operation'] for r in coverage['scenarios'] if 'operation' in r}
for row in coverage['scenarios']:
    indices=row['formal_result_check_indices_zero_based']
    assert len(indices)==row['formal_check_count'] and indices and len(indices)==len(set(indices))
    assert all(0<=i<len(checks) and checks[i]['result']=='PASS' for i in indices)

differences=[]
for relative,expected in freeze['assets'].items():
    raw=(reader/relative).read_bytes()
    assert sha(raw)==expected,relative
    current=(SKILLS/'.agents/skills/pal-found-dev'/relative).read_bytes()
    if sha(current)!=expected:
        differences.append({'path':relative,'executed_sha256':expected,'current_sha256':sha(current)})
assert {d['path'] for d in differences} == {
    'references/rest/v2/third_party_applications/ThirdPartyApplication.md',
    'references/rest/v2/third_party_applications/Version.md'}
assert len(freeze['assets'])==4371
assert len(freeze['model_pages'])==483
for model,info in freeze['model_pages'].items():
    assert sha((reader/info['path']).read_bytes())==sha((SKILLS/'.agents/skills/pal-found-dev'/info['path']).read_bytes()),model
source_rows=[]
for original,expected in freeze['runtime_sources'].items():
    relative='foundry_sdk/'+original.replace('\\','/').split('/foundry_sdk/',1)[1]
    raw=git(SDK,'show',SOURCE+':'+relative)
    assert sha(raw)==expected,relative
    assert sha(Path(original).read_bytes())==expected,original
    target=OUT/'sdk101'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(raw)
    source_rows.append({'source_path':relative,'sha256':expected,'runtime_path_at_execution':original,'immutable_source_matches_runtime':True})
for info in freeze['source_documents'].values():
    raw=git(SDK,'show',SOURCE+':'+info['source_path'])
    assert sha(raw)==info['sha256']
    target=OUT/'sdk101'/info['source_path']
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(raw)
root_names=git(SDK,'ls-tree','--name-only',SOURCE).decode().splitlines()
license_names=[n for n in root_names if n.upper().startswith(('LICENSE','NOTICE'))]
assert 'LICENSE' in license_names
for name in license_names+['pyproject.toml']:
    (OUT/'sdk101'/name).write_bytes(git(SDK,'show',SOURCE+':'+name))
tags=git(SDK,'tag','--points-at',SOURCE).decode().splitlines()
assert any('1.101.0' in tag for tag in tags)
write(OUT/'sdk101/source_provenance.json',{
    'sdk_release':'1.101.0','source_commit':SOURCE,'tags_pointing_to_source_commit':tags,
    'immutable_source_access':'git show exact commit; working checkout HEAD not used',
    'runtime_source_files':source_rows,'license_files_at_frozen_root':license_names,
    'notice_status':'Retained if present at frozen SDK root; no NOTICE file fabricated.',
    'root_tree_names':root_names})
raw_diff=git(SKILLS,'diff','--name-status',freeze['published_skills'],CURRENT)
(OUT/'reviews/full_candidate_diff.txt').write_bytes(raw_diff)
guide_diff=git(SKILLS,'diff',freeze['published_skills'],CURRENT,'--','.agents/skills/pal-found-dev/references/rest/v2/third_party_applications')
(OUT/'reviews/foreign_guide_diff.patch').write_bytes(guide_diff)
proof={
    'kind':'INDEPENDENT_RETENTION_AND_INPUT_BINDING_REVIEW','reviewer_identity':'/root/rest079_independent_formal_acceptance_20261118',
    'task':'TASK-023','reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'executed_candidate':freeze['published_skills'],'integration_candidate':CURRENT,
    'formal_result_sha256':sha((FORMAL/'formal_result.json').read_bytes()),
    'formal_invocations_added_by_acceptance':0,'formal_executor':result['executor_identity'],
    'pass_checks':len(checks),'fail_checks':0,'operation_scenarios':32,'annex_scenarios':25,
    'scenario_count_boundary':coverage['count_boundary'],'original_manifest_artifacts_verified':len(manifest['artifacts']),
    'approved_input_hashes_verified':len(manifest['approved_inputs']),
    'executed_reader_files_verified':len(freeze['assets']),'unchanged_current_reader_files':len(freeze['assets'])-len(differences),
    'current_reader_differences':differences,'all_4371_current_reader_inputs_executed':False,
    'all_bindings_current_and_unchanged':False,'relevant_domain_bindings_current':True,
    'model_definition_pages_unchanged':len(freeze['model_pages']),'frozen_sdk_runtime_source_files_verified':len(source_rows),
    'binding_reason':'Only two ThirdpartyApplication/Version behavior guides differ. All REST079 behavior, examples, fixtures, structural contracts, complete 483-member model pages, navigation and shared input bytes remain identical. SAD 3.4 requires repeat affected gates; these foreign guides have their own six-operation independent correction review. No current whole-reader execution is claimed.',
    'validator_boundary':'verify_domain_acceptance requires current register input_bundle_sha256 and optional candidate_sha. These are integration metadata anchors. Formal079 original full-reader freeze remains retained and differs by two foreign guides; no original global hash is replaced or declared current.',
    'acceptance_status':'PROPOSED_DOMAIN_ACCEPTANCE_PENDING_ROOT_METADATA_GATE',
    'measurement':manifest['measurement'],'limits':manifest['limits'],
    'prior_semantic_review_boundary':'Exact483 membership and unchanged model page hashes preserve earlier semantic review; no fresh exhaustive483-page prose review.',
    'license_files':license_names}
write(OUT/'independent_binding_review.json',proof)
print(json.dumps({'retained':str(OUT),'binding_review_sha256':sha((OUT/'independent_binding_review.json').read_bytes()),'reader_differences':differences,'sources':len(source_rows),'sdk_tags':tags,'sdk_licenses':license_names},indent=2))
