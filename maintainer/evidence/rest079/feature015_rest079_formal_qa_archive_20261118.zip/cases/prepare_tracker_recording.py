"""Prepare CLI comment payloads without mutating tracker or approved case files."""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

data = json.loads((HERE / 'rest079_formal_cases.json').read_text())
proof = json.loads((HERE / 'review_candidate_proof_v2.json').read_text())
for name, expected in proof['hashes'].items():
    assert sha(HERE / name) == expected, name
sidecar = ROOT / '.ept/tmp/rest079_case_techlead_approval_20261118/techlead_case_approval_v2.json'
assert sha(sidecar) == '0d1b2ec7007920c5806b13adf9adc1e43d70aa98de954b262ecf2e0b5aa0e536'
feature = (HERE / 'rest079_formal_cases.feature').read_text()
scenarios = re.findall(r'^  Scenario:.*?(?=^  Scenario:|\Z)', feature, re.M | re.S)
operation_scenarios = [s for s in scenarios if re.match(r'  Scenario: F079-', s)]
annex_scenarios = [s for s in scenarios if s not in operation_scenarios]
assert len(operation_scenarios) == 32 and len(annex_scenarios) == 25
payloads = []
def add(subject, text, **extra):
    payloads.append({'ticket': 'TESTCASE-079', 'subject': subject, 'text': text, **extra})
def batches(parts, prefix, preface):
    groups, current, size = [], [], 0
    for part in parts:
        if current and size + len(part) > 12000:
            groups.append(current)
            current, size = [], 0
        current.append(part)
        size += len(part)
    if current:
        groups.append(current)
    for index, group in enumerate(groups, 1):
        add(f'{prefix} {index}/{len(groups)}', preface + '\n\n```gherkin\nFeature: Frozen REST079 case design revision2\n' + '\n'.join(group) + '\n```')

batches(operation_scenarios, 'Frozen v2 operation Gherkin and exact expected outputs',
        'Approved case specification for actual SDK1.101.0 operations. This records test design; all retained runs are author or peer dry runs. Exact kwargs, wire request, typed response, nested category and adverse outputs are included below. Case JSON SHA2561587b936fc129eab6b91fb86ae276f181b031b4a4d55256c6d33885b1ecfebbe; Gherkin SHA2565a146376ce28c3b077e4c19e5fce9372e0cb1d7027a01f84eb632b214e82e7e3.')
batches(annex_scenarios, 'Frozen v2 closure and nested constraint Gherkin annex',
        'Additional approved source/model closure, opaque-data and nested semantic scenarios. Expected local refusal is distinct from SDK shape validation and live server enforcement.')

add('Frozen v2 source, model, transport and recovery evidence annex', '''## Scope and prerequisites

All32 exact DEV-STORY-079 partition identities are implemented and runnable in prepared SDK1.101.0. Parent DEV-STORY-079 is QA; DEV-079, UNITTEST-079 and CODEREVIEW-080 are Closed. Scope covers v2.ontologies.ActionType, ActionTypeFullMetadata, ObjectType, Ontology, OntologyInterface, OntologyValueType and QueryType. These calls inspect metadata or read/search interface records. Reading Action configuration does not apply an Action or grant execution rights.

Reviewed document_index entries: BA-DES-015 revision2, SA-DES-014 revision2 and its rest-and-sources.md/sdk-baseline.md, FEATURE-015-rest-authoring-contract.md and exact operation partition JSON. These describe local contracts, all transitive models, modes, finite work, independent review and enrollment boundaries. LINK-01840 registers parent containment. Fresh CLI list --parent TESTCASE-079 returned no child Questions; link list showed no active blocker or unregistered dependency.

## Source and model assertions

Published reader4de1e23e98017536bcff0eef2aa1d057e576e056 retains all4371 asset hashes. Source SDK1.101.0 commit168d51910570b6966afa2320333ab36f6a3f7ccf and OpenAPI1.1697.0 remain pinned. Source definitions come from git show at that commit, compared to installed runtime modules; checkout HEAD is not the oracle. Each32 operation checks exact signatures, RequestInfo, four wrapper factories, API v2 stage from frozen resource docs and full reader contract parts. Exact425 catalog identities and separate v1/v2 navigation are checked.

Source-derived graph membership is exactly483 model definitions. Complete definition ASTs cover fields, aliases, defaults, nullability, literals, unions/discriminators and recursive dependencies. The prior483-definition semantic review remains attributable through identical membership and unchanged page hashes; fresh exhaustive483-page prose review is not claimed. Five previously missed definitions occur in numbered Ontology get_full_metadata/load_metadata parts: BranchMetadata, LoadOntologyMetadataRequest, OntologyFullMetadata, SharedPropertyType and VersionedQueryTypeApiName.

Every source RequestInfo throwable_errors map is empty. Narrative ObjectsExceededLimit mentions in interface object-list documentation remain documented limitations; they do not become invented named SDK error unions. Generic403, timeout and argument validation are separate actual runtime paths. Source silence supplies no universal permission, scope, idempotency or retry guarantee. Live visibility, storage version, grant and beta enablement require authorized tenant verification.

## Native modes, errors and lifetimes

Each32 operation runs ordinary/raw/stream sync and async native forms with exact HTTP method/path/query/headers/body and seven-second timeout, typed top-level result and deep independent schema checks. Eight ordinary async methods return AsyncIterator directly; they are not awaited. Generic403 and read timeout are exercised across all six forms, each with one request and no automatic replay. Error name/instance/parameters and httpx.ReadTimeout cause are checked. Zero request timeout raises pydantic.ValidationError before HTTP.

Unconsumed streams close with zero reads; partially read streams close after consumer failure; canceled async consumers propagate CancelledError and close. Raw decode and consumer failures release responses. All32 sync/async caller byte-cap checks retain exactly b'{"da' (four bytes), close and claim no complete result. Upstream first chunk is eight bytes; the cap applies to caller consumption. Native close/aclose bypass mutants and prebuffered-response traps are rejected.

## Paging, batch and schema recovery

Eleven raw pagers in sync/async forms exercise terminal empty, empty intermediate with continuation then data, repeated cursor, three distinct cursor pages and a one-item cap. Retained partial items, unconsumed items, next cursor, stop reason and response closure are asserted. Three-page exhaustion retains cursor079-budget-3. Eight native sync/async iterators separately cover two-page continuation, early stop and empty intermediate continuation. Empty intermediate is defensive synthetic input, not a claim that live server violates a nonempty-page guarantee.

Four actual bulk methods serialize100 input RIDs and decode one visible response, retaining99 omissions. A reader-side101 guard sends zero requests. This tests local budget behavior; it does not invent SDK/server rejection or prove deletion from omission. History retains Object Storage V1 filter limitations. Version labels and API-name/RID roles remain distinct.

Deep faults cover primary-key/title presence and types, interface inheritance/requirements/implementations/link maps, Action summary versus full-rule discriminators and parameter references, typed history keys versus plain create properties, date versus struct constraints and query/value versions. Aggregation requires one selector, known shared properties and valid duration property/unit/value combinations. Unknown record keys and mixed unknown aggregation labels remain raw; unsupported local derivation stops. No global server schema rejection is invented.

## Distributed invocation and access boundary

All32 shipped invoke functions execute with source-derived wire expectations and independent Device079/Inspectable079 response payloads. Product SUCCESS/EXPECTED constants and unit source_contract do not supply oracles. This proves invocation fidelity. Shipped verify/SUCCESS semantics rely on separately preserved source and semantic evidence. Network denial and its probe are checked; no live enrollment, platform effect, publication or formal TESTEXEC acceptance is claimed.
''')

runs = []
for path in sorted(HERE.glob('recovery_author_dry_run*.json')):
    result = json.loads(path.read_text())
    assert result['author_identity'] == data['author_identity']
    runs.append({'file': path.name, 'sha256': sha(path), 'elapsed_seconds': result['elapsed_seconds'], 'outcome': result['outcome']})
seconds = sum(row['elapsed_seconds'] for row in runs)
hours = round(seconds / 3600, 6)
add('Frozen v2 approvals, preserved failures, qualified time and completion gate', '''## Independent approvals and immutable evidence

Tech Lead approval: TESTCASE-079 comment20261118-075618-@tech-lead; reviewer /root/rest079_case_techlead_approval_20261118. Sidecar .ept/tmp/rest079_case_techlead_approval_20261118/techlead_case_approval_v2.json SHA2560d1b2ec7007920c5806b13adf9adc1e43d70aa98de954b262ecf2e0b5aa0e536. Independent QA peer approval: comment20261118-081704-@qa-engineer; reviewer /root/rest079_formal_case_independent_peer_20261118. Peer verdict .ept/tmp/rest079_case_peer_20261118/peer_review_v2.json SHA256a1a451f5362392985e1c87d237a422d8c626a695125d0cab382a076acea9a626.

Candidate .ept/tmp/feature015_rest079_formal_cases_20261118/review_candidate_proof_v2.json SHA256d42963e19e7ef33b89dfffa81247ac0382420b28265b7f692aa669df700c2bd2 binds:

| Artifact | SHA256 |
| --- | --- |
| rest079_formal_cases.json | 1587b936fc129eab6b91fb86ae276f181b031b4a4d55256c6d33885b1ecfebbe |
| rest079_formal_cases.feature | 5a146376ce28c3b077e4c19e5fce9372e0cb1d7027a01f84eb632b214e82e7e3 |
| rest079_formal_execute.py | b7fc8a404cfd5f883c2339955517e5763d34481fb54f8106392df7201d004cb6 |
| additional_checks.py | 90da13bfae5c685a22319d58301e1ddd2ab7c20b48b71ebcf8a466698cbf9044 |
| rest079_assets_freeze.json | 7f6f42060c4cc18535dd4009cf335cf6a8355eb0d80ea44e69ccb36e2563cd8f |

Author dry run recovery_author_dry_run_peer_corrections_v2.json SHA256826b9ce07fc191d67370913e635cd9683886af82237d219c39a7b7589e90a0d3:1564 PASS, formal_execution=false. Independent peer fresh run independent_dry_run_v2.json SHA2565cf5b9cbf2c007516e253c97dbb96d5ea9ef70448df70774186f58a678bf995b:1564 PASS, formal_execution=false. Peer rejected six source/semantic faults, three correction faults and six approval-gate faults. Both case authors are excluded from formal execution; reviewer and executor must differ and hashes must match.

## History and corrections

Original author /root/rest079_unit_independent_qa_20261117 and recovery author /root/rest079_formal_case_author_recover_20261118 remain distinct. All Nov17 artifacts and first_three_author_dry_run.json retain original bytes/identity. The first3 evidence is32 checks; it does not prove later full32 coverage. Initial frozen candidate and1462-check proof remain in candidate_v1_frozen/.

Recovery corrected QA-only drafts: missing totalCount in three response types, history operationId RID shape and normalized timestamp. No product defect was asserted for these draft mistakes. Early incomplete runs did not reach a pass; saved failure reports07/09/10 remain. Peer then found and challenged one-page versus declared three-page behavior, terminal-only empty handling and unused four-byte cap. Frozen v2 corrects all three with exact asserted boundaries. Old failures and first candidate remain preserved; approved artifacts are unchanged.

## Qualified time

The frontmatter time entry is measured automated validation runtime only, summed from retained recovery-author reports listed below. It is not elapsed authoring time, contributor or human effort, peer time or a reconstructed historical timesheet. Unmeasured work is not estimated. Twelve saved runs total ''' + f'{seconds:.9f} seconds; time_spent_hours={hours:.6f}' + ''' after numeric rounding.

```json
''' + json.dumps(runs, indent=2) + '''
```

## Case completion boundary

Full32 operation Gherkin/expected results plus25 source/nested scenarios are recorded in preceding comments. Actual implementation, source/reader bindings, related indexed documents, parent link, independent QA and Tech Lead approval, coverage and qualified time support case completion. No child Question or active blocking link belongs to TESTCASE-079.

TESTEXEC-079 remains Blocked by Open QUESTION-197 about literal Resolved-versus-Closed implementation prerequisites. That question blocks TESTEXEC only; case closure is independent. The historical Tech Lead approval deliberately retains testcase_closed=false and testexec_prerequisites_verified=false. This recording does not edit those flags or grant execution readiness. Different formal executor must verify current prerequisites after owner clarification and create fresh permitted execution evidence. No formal run or stage transition is claimed here.
''', time_spent_hours=hours)

destination = HERE / 'tracker_case_payloads.json'
destination.write_text(json.dumps({'kind': 'PREPARED_CLI_COMMENT_PAYLOADS', 'tracker_mutations_performed': False,
    'time_spent_hours': hours, 'time_basis': 'Measured automated validation runtime only',
    'operation_scenarios': 32, 'annex_scenarios': 25, 'payloads': payloads}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'payloads': len(payloads), 'operation_scenarios': 32, 'annex_scenarios': 25,
                  'max_comment_chars': max(len(p['text']) for p in payloads), 'time_spent_hours': hours,
                  'payload_sha256': sha(destination), 'tracker_mutations_performed': False}))
