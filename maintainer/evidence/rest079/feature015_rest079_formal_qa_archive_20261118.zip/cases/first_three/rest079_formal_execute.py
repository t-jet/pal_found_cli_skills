"""Independent REST079 case harness; author validation cannot confer formal acceptance."""
import argparse
import ast
import asyncio
import copy
import dataclasses
import hashlib
import importlib
import importlib.metadata
import inspect
import json
from pathlib import Path
import socket
import sys
import textwrap
import time
from unittest.mock import patch
from contextlib import contextmanager, asynccontextmanager
from urllib.parse import unquote

import httpx
import pydantic
from foundry_sdk import Config, UserTokenAuth, PermissionDeniedError, ReadTimeout, _core

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
AUTHOR = '/root/rest079_unit_independent_qa_20261117'
TOKEN = 'independent-qa079-token'
ROWS = []


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(case, name, **details):
    ROWS.append({'case_id': case['case_id'] if isinstance(case, dict) else case,
                 'check': name, 'result': 'PASS', **details})


def normalize(value):
    if isinstance(value, pydantic.BaseModel):
        return value.model_dump(mode='json', by_alias=True, exclude_unset=True)
    if isinstance(value, (list, tuple)):
        return [normalize(child) for child in value]
    if isinstance(value, dict):
        return {key: normalize(child) for key, child in value.items()}
    return value


def class_for(case, asynchronous=False):
    resource = case['operation'].split('.')[2]
    return getattr(importlib.import_module(case['source']['module']), ('Async' if asynchronous else '') + resource + 'Client')


@contextmanager
def sync_client(case, handler):
    with httpx.Client(transport=httpx.MockTransport(handler), timeout=7) as session:
        with patch('foundry_sdk._core.api_client.HttpClient', return_value=session):
            client = class_for(case)(auth=UserTokenAuth(token=TOKEN), hostname='qa079.invalid',
                                     config=Config(timeout=7, max_retries=0))
        yield client
    assert session.is_closed


@asynccontextmanager
async def async_client(case, handler):
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler), timeout=7) as session:
        with patch('foundry_sdk._core.api_client.AsyncHttpClient', return_value=session):
            client = class_for(case, True)(auth=UserTokenAuth(token=TOKEN), hostname='qa079.invalid',
                                           config=Config(timeout=7, max_retries=0))
        yield client
    assert session.is_closed


def invoke(client, case, mode, kwargs=None):
    target = {'ordinary': client, 'raw': client.with_raw_response, 'stream': client.with_streaming_response}[mode]
    return getattr(target, case['operation'].split('.')[-1])(**copy.deepcopy(case['kwargs'] if kwargs is None else kwargs), request_timeout=7)


def check_wire(request, case):
    wire = case['wire']
    assert request.method == wire['method']
    assert unquote(request.url.path) == '/api' + wire['path']
    assert sorted(request.url.params.multi_items()) == sorted(httpx.QueryParams(wire['query']).multi_items())
    assert request.headers['Authorization'] == 'Bearer ' + TOKEN
    for name, value in wire['headers'].items():
        assert request.headers[name] == value
    assert (json.loads(request.content) if request.content else None) == wire['body']
    assert request.extensions['timeout'] == dict(connect=7, read=7, write=7, pool=7)


def typed_value(case, value):
    module_name, name = case['source']['response_type'].rsplit('.', 1)
    expected = getattr(importlib.import_module(module_name), name)
    assert type(value) is expected, (type(value), expected)
    return normalize(value)


def semantic(case, value):
    if case['semantic'] == 'device_schema':
        assert value['apiName'] == case['kwargs']['object_type'] == 'Device079'
        for selector in ('primaryKey', 'titleProperty'):
            field = value[selector]
            assert field in value['properties']
            assert value['properties'][field]['dataType'] == {'type': 'string'}
        assert value['primaryKey'] == 'deviceId' and value['titleProperty'] == 'label'
    elif case['semantic'] == 'action_rule':
        summary = value['actionType']
        assert summary['apiName'] == case['kwargs']['action_type'] == 'rename-device079'
        operation, = summary['operations']
        rule, = value['fullLogicRules']
        assert operation == {'type': 'modifyInterfaceObject', 'interfaceTypeApiName': 'Inspectable079'}
        assert rule['type'] == 'modifyInterface'
        parameter = summary['parameters'][rule['interfaceObjectToModify']]
        assert parameter['required'] is True
        assert parameter['dataType'] == {'type': 'interfaceObject', 'interfaceTypeApiName': 'Inspectable079'}
        assert rule['sharedPropertyArguments'] == {'label': {'type': 'parameterId', 'parameterId': 'labelText'}}
        assert summary['parameters']['labelText']['dataType'] == {'type': 'string'}
    elif case['semantic'] == 'aggregate_schema':
        body = case['wire']['body']
        schema = {'deviceId': 'string', 'label': 'string', 'recordedAt': 'timestamp'}
        for selector in body['aggregation'] + body['groupBy']:
            assert ('field' in selector) != ('propertyIdentifier' in selector)
            name = selector.get('field') or selector['propertyIdentifier']['apiName']
            assert name in schema
            if selector['type'] == 'duration':
                assert schema[name] in ('timestamp', 'date')
                if selector['unit'] in ('YEARS', 'QUARTERS', 'MONTHS', 'WEEKS'):
                    assert selector['value'] == 1
        bucket, = value['data']
        assert bucket['metrics'] == [{'name': body['aggregation'][0]['name'], 'value': 2}]
        assert bucket['group'] == {'recordedAt': '2026-11-16T00:00:00Z'}
        assert value['accuracy'] == 'APPROXIMATE'


def response_for(case):
    return httpx.Response(200, stream=httpx.ByteStream(json.dumps(case['response']).encode()),
                          headers={'Content-Type': 'application/json'})


def sync_success(case, mode):
    responses = []
    def handler(request):
        check_wire(request, case)
        response = response_for(case)
        responses.append(response)
        return response
    with sync_client(case, handler) as client:
        pending = invoke(client, case, mode)
        if mode == 'stream':
            with pending as response:
                assert not responses[0].is_closed
                value = json.loads(b''.join(response.iter_bytes()))
        elif mode == 'raw':
            try:
                value = typed_value(case, pending.decode())
            finally:
                pending.close()
        else:
            value = typed_value(case, pending)
        assert value == case['response']
        semantic(case, value)
    assert len(responses) == 1 and responses[0].is_closed
    record(case, 'sync_' + mode, actual=value, expected=case['response'], requests=1, closed=True)


async def async_success(case, mode):
    responses = []
    def handler(request):
        check_wire(request, case)
        response = response_for(case)
        responses.append(response)
        return response
    async with async_client(case, handler) as client:
        pending = invoke(client, case, mode)
        if mode == 'stream':
            async with pending as response:
                assert not responses[0].is_closed
                value = json.loads(b''.join([chunk async for chunk in response.aiter_bytes()]))
        else:
            assert inspect.isawaitable(pending)
            result = await pending
            if mode == 'raw':
                try:
                    assert not inspect.iscoroutinefunction(result.decode)
                    assert inspect.iscoroutinefunction(result.aclose)
                    value = typed_value(case, result.decode())
                finally:
                    await result.aclose()
            else:
                value = typed_value(case, result)
        assert value == case['response']
        semantic(case, value)
    assert len(responses) == 1 and responses[0].is_closed
    record(case, 'async_' + mode, actual=value, expected=case['response'], requests=1, closed=True)


def source_check(case):
    module = importlib.import_module(case['source']['module'])
    assert digest(module.__file__) == case['source']['sha256']
    resource, method = case['operation'].split('.')[-2:]
    for client_name, expected in case['source']['methods'].items():
        fn = getattr(getattr(module, client_name), method)
        node = ast.parse(textwrap.dedent(inspect.getsource(fn))).body[0]
        assert ast.dump(node.args) == expected['arguments_ast']
        assert ast.unparse(node.returns) == expected['return_annotation']
        assert isinstance(node, ast.AsyncFunctionDef) == expected['coroutine_definition']
        request, = [n for n in ast.walk(node) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'RequestInfo']
        actual = {kw.arg: ast.unparse(kw.value) for kw in request.keywords}
        assert actual == expected['request_ast']
        assert actual['throwable_errors'] == '{}'
    record(case, 'exact_frozen_source_signatures_wire_and_zero_named_errors')


def expect_assertion(function):
    try:
        function()
    except Exception as error:
        assert isinstance(error, (AssertionError, KeyError)) or isinstance(error.__cause__, AssertionError), type(error)
    else:
        raise AssertionError('Negative control survived')


def semantic_controls(case):
    damaged = copy.deepcopy(case['response'])
    if case['semantic'] == 'device_schema':
        damaged['properties'].pop(damaged['primaryKey'])
    elif case['semantic'] == 'action_rule':
        damaged['actionType']['parameters']['labelText']['dataType'] = {'type': 'date'}
    else:
        damaged['data'][0]['metrics'][0]['name'] = 'wrongMetric'
    expect_assertion(lambda: semantic(case, damaged))
    record(case, 'independent_semantic_mutant_rejected')
    native = _core.ApiClient.call_api
    for fault in ('path', 'query'):
        def damaged_request(self, info):
            if fault == 'path':
                info = dataclasses.replace(info, resource_path=info.resource_path + '/wrong')
            else:
                info = dataclasses.replace(info, query_params={**info.query_params, 'wrongQuery': '1'})
            return native(self, info)
        with patch.object(_core.ApiClient, 'call_api', damaged_request):
            expect_assertion(lambda: sync_success(case, 'ordinary'))
        record(case, 'native_sdk_' + fault + '_mutant_rejected')


def freeze_check(data):
    freeze = json.loads((HERE / 'rest079_assets_freeze.json').read_text())
    assert freeze['published_skills'] == data['published_skills']
    skill = Path(freeze['skill_root'])
    for path, expected in freeze['assets'].items():
        assert digest(skill / path) == expected, path
    assert importlib.metadata.version('foundry-platform-sdk') == '1.101.0'
    record('F079-FREEZE', 'reader_assets_hash_bound', assets=len(freeze['assets']))


def denied(*args, **kwargs):
    raise AssertionError('PUBLIC_NETWORK_DENIED_F079')


async def run(data):
    for case in data['operations']:
        source_check(case)
        semantic_controls(case)
        for mode in ('ordinary', 'raw', 'stream'):
            sync_success(case, mode)
            await async_success(case, mode)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--author-check', action='store_true')
    parser.add_argument('--executor')
    parser.add_argument('--approval')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert args.author_check, 'Formal execution disabled until independently reviewed final case bundle'
    start = time.perf_counter()
    data = json.loads((HERE / 'rest079_formal_cases.json').read_text())
    freeze_check(data)
    loop = asyncio.new_event_loop()
    try:
        with patch.object(socket.socket, 'connect', denied), patch.object(socket.socket, 'connect_ex', denied), \
             patch.object(socket, 'getaddrinfo', denied), patch.object(socket, 'create_connection', denied), \
             patch.object(httpx.HTTPTransport, 'handle_request', denied), \
             patch.object(httpx.AsyncHTTPTransport, 'handle_async_request', denied):
            loop.run_until_complete(run(data))
            expect_assertion(lambda: socket.getaddrinfo('public.example.invalid', 443))
            record('F079-NETWORK', 'denial_probe', actual='PUBLIC_NETWORK_DENIED_F079')
    finally:
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()
    report = {'kind': 'AUTHOR_DRY_RUN', 'formal_execution': False, 'author_identity': AUTHOR,
              'outcome': 'AUTHOR_DRY_RUN_PASS', 'elapsed_seconds': time.perf_counter() - start,
              'case_sha256': digest(HERE / 'rest079_formal_cases.json'),
              'harness_sha256': digest(__file__), 'checks': ROWS}
    args.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'outcome': report['outcome'], 'checks': len(ROWS), 'formal_execution': False}))


if __name__ == '__main__':
    main()
