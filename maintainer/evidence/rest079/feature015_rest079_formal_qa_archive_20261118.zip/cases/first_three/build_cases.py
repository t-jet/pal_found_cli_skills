"""Author independent REST079 cases from frozen SDK source and reader contracts."""
import ast
import copy
import hashlib
import importlib
import inspect
import io
import json
from pathlib import Path
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PUBLISHED = '4de1e23e98017536bcff0eef2aa1d057e576e056'
SDK_COMMIT = '168d51910570b6966afa2320333ab36f6a3f7ccf'
REPO = ROOT / '.ept/tmp/feature015_rest079_unit_modes'
SDK_REPO = ROOT / '.ept/docs/customer_input/foundry-platform-python'
AUTHOR = '/root/rest079_unit_independent_qa_20261117'
SKILL = HERE / 'reader/.agents/skills/pal-found-dev'


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, default=lambda v: v.model_dump(mode='json', by_alias=True, exclude_none=True)) + '\n', encoding='utf-8')


if not SKILL.exists():
    archive = git(REPO, 'archive', '--format=zip', PUBLISHED, '.agents/skills/pal-found-dev')
    with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
        bundle.extractall(HERE / 'reader')

# This QA schema is declared here, independently of distributed fixture constants.
DEVICE = {
    'apiName': 'Device079', 'displayName': 'Inspection device', 'pluralDisplayName': 'Inspection devices',
    'status': 'EXPERIMENTAL', 'rid': 'ri.qa.main.object-type.device079',
    'icon': {'type': 'blueprint', 'name': 'wrench', 'color': '#126734'},
    'primaryKey': 'deviceId', 'titleProperty': 'label',
    'properties': {name: {'rid': 'ri.qa.main.property.' + name, 'dataType': {'type': kind}}
                   for name, kind in [('deviceId', 'string'), ('label', 'string'), ('recordedAt', 'timestamp')]},
}
ACTION_FULL = {
    'actionType': {
        'apiName': 'rename-device079', 'status': 'EXPERIMENTAL', 'rid': 'ri.qa.main.action-type.rename-device079',
        'parameters': {
            'device': {'displayName': 'Device', 'required': True,
                       'dataType': {'type': 'interfaceObject', 'interfaceTypeApiName': 'Inspectable079'}},
            'labelText': {'displayName': 'Label', 'required': True, 'dataType': {'type': 'string'}},
        },
        'operations': [{'type': 'modifyInterfaceObject', 'interfaceTypeApiName': 'Inspectable079'}],
    },
    'fullLogicRules': [{'type': 'modifyInterface', 'interfaceObjectToModify': 'device',
                        'sharedPropertyArguments': {'label': {'type': 'parameterId', 'parameterId': 'labelText'}},
                        'structPropertyArguments': {}}],
}
AGGREGATE_BODY = {
    'aggregation': [{'type': 'approximateDistinct', 'field': 'deviceId', 'name': 'uniqueDevices079'}],
    'groupBy': [{'type': 'duration', 'field': 'recordedAt', 'value': 2, 'unit': 'DAYS'}],
}
AGGREGATE_RESULT = {'accuracy': 'APPROXIMATE', 'data': [
    {'group': {'recordedAt': '2026-11-16T00:00:00Z'},
     'metrics': [{'name': 'uniqueDevices079', 'value': 2}]}]}


def source_record(resource, method, kwargs):
    module_name = 'foundry_sdk.v2.ontologies.' + ''.join('_' + c.lower() if c.isupper() else c for c in resource).lstrip('_')
    raw = git(SDK_REPO, 'show', SDK_COMMIT + ':' + module_name.replace('.', '/') + '.py')
    module = importlib.import_module(module_name)
    assert raw == Path(module.__file__).read_bytes()
    tree = ast.parse(raw)
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    methods = {}
    for prefix in ('', 'Async'):
        cls = classes[prefix + resource + 'Client']
        fn = next(node for node in cls.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == method)
        calls = [node for node in ast.walk(fn) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute) and node.func.attr == 'RequestInfo']
        request, = calls
        fields = {kw.arg: kw.value for kw in request.keywords}
        assert ast.literal_eval(fields['throwable_errors']) == {}
        methods[prefix + resource + 'Client'] = {
            'arguments_ast': ast.dump(fn.args), 'return_annotation': ast.unparse(fn.returns),
            'coroutine_definition': isinstance(fn, ast.AsyncFunctionDef),
            'request_ast': {name: ast.unparse(value) for name, value in fields.items()},
        }
    fn = getattr(getattr(module, resource + 'Client'), method)
    bound = inspect.signature(fn).bind(None, **kwargs, request_timeout=7)
    bound.apply_defaults()
    env = bound.arguments
    wire = {name: eval(compile(ast.Expression(node), '<frozen source authoring only>', 'eval'), vars(module), env)
            for name, node in fields.items()}
    response = wire['response_type']
    wire = {'method': wire['method'], 'path': wire['resource_path'].format(**wire['path_params']),
            'query': {key: value for key, value in wire['query_params'].items() if value is not None},
            'headers': wire['header_params'], 'body': wire['body']}
    return {'module': module_name, 'sha256': sha(raw), 'methods': methods,
            'response_type': response.__module__ + '.' + response.__name__,
            'source_named_errors': []}, wire


DEFINITIONS = [
    ('ObjectType', 'get', {'ontology': 'qa-ontology079', 'object_type': 'Device079', 'branch': 'qa-branch079',
                          'include_datasources': False}, DEVICE, 'device_schema'),
    ('ActionTypeFullMetadata', 'get', {'ontology': 'qa-ontology079', 'action_type': 'rename-device079',
                                      'branch': 'qa-branch079', 'preview': True}, ACTION_FULL, 'action_rule'),
    ('OntologyInterface', 'aggregate', {'ontology': 'qa-ontology079', 'interface_type': 'Inspectable079',
                                       'aggregation': AGGREGATE_BODY['aggregation'],
                                       'group_by': AGGREGATE_BODY['groupBy'], 'branch': 'qa-branch079',
                                       'preview': True}, AGGREGATE_RESULT, 'aggregate_schema'),
]
cases = []
for resource, method, kwargs, response, semantic in DEFINITIONS:
    source, wire = source_record(resource, method, kwargs)
    case_id = 'F079-' + resource + '-' + method
    cases.append({'case_id': case_id, 'operation': 'v2.ontologies.' + resource + '.' + method,
                  'kwargs': copy.deepcopy(kwargs), 'wire': wire, 'response': copy.deepcopy(response),
                  'source': source, 'semantic': semantic,
                  'reader': {'behavior': f'references/rest/v2/ontologies/{resource}.md',
                             'heading': f'{resource}.{method}',
                             'contract': f'references/rest/contracts/v2/ontologies/{resource}/{method}.md'},
                  'given': 'Frozen SDK1.101, synthetic Device079/Inspectable079 schema, fake identity and denied public network',
                  'when': f'Invoke native {resource}Client.{method} with the exact recorded kwargs in all six exposed forms',
                  'then': 'Exact HTTP fields, typed result and nested schema checks match; responses close; generic403/timeout/invalid arguments stop within finite budgets'})
data = {'testcase': 'TESTCASE-079', 'testexec': 'TESTEXEC-079', 'author_identity': AUTHOR,
        'published_skills': PUBLISHED, 'sdk_release': '1.101.0', 'source_commit': SDK_COMMIT,
        'approval': 'PENDING_INDEPENDENT_REVIEW', 'formal_execution': False,
        'checkpoint': 'FIRST_THREE', 'schema': {'object_type': DEVICE, 'action_full': ACTION_FULL},
        'budgets': {'timeout_seconds': 7, 'max_requests': 3, 'max_pages': 3, 'max_stream_bytes': 4},
        'operations': cases}
json_write('rest079_formal_cases.json', data)
assets = {path.relative_to(SKILL).as_posix(): sha(path.read_bytes()) for path in SKILL.rglob('*') if path.is_file()}
json_write('rest079_assets_freeze.json', {'published_skills': PUBLISHED, 'skill_root': str(SKILL),
                                        'assets': assets, 'source_commit': SDK_COMMIT,
                                        'source_modules': {case['source']['module']: case['source']['sha256'] for case in cases}})
feature = ['Feature: Frozen REST079 Ontology schema and interface contracts',
           '  # Author candidate only. Independent review and separate formal execution required.']
for case in cases:
    feature += ['', '  Scenario: ' + case['case_id'] + ' ' + case['operation'],
                '    Given ' + case['given'], '    When ' + case['when'], '    Then ' + case['then'],
                '    And request path is ' + case['wire']['path'],
                '    And source declares zero named throwable errors']
(HERE / 'rest079_formal_cases.feature').write_text('\n'.join(feature) + '\n', encoding='utf-8')
print(json.dumps({'cases': len(cases), 'frozen_reader_assets': len(assets), 'formal_execution': False}))
