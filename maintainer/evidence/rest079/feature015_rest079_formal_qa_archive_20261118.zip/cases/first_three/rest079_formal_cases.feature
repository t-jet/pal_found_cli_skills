Feature: Frozen REST079 Ontology schema and interface contracts
  # Author candidate only. Independent review and separate formal execution required.

  Scenario: F079-ObjectType-get v2.ontologies.ObjectType.get
    Given Frozen SDK1.101, synthetic Device079/Inspectable079 schema, fake identity and denied public network
    When Invoke native ObjectTypeClient.get with the exact recorded kwargs in all six exposed forms
    Then Exact HTTP fields, typed result and nested schema checks match; responses close; generic403/timeout/invalid arguments stop within finite budgets
    And request path is /v2/ontologies/qa-ontology079/objectTypes/Device079
    And source declares zero named throwable errors

  Scenario: F079-ActionTypeFullMetadata-get v2.ontologies.ActionTypeFullMetadata.get
    Given Frozen SDK1.101, synthetic Device079/Inspectable079 schema, fake identity and denied public network
    When Invoke native ActionTypeFullMetadataClient.get with the exact recorded kwargs in all six exposed forms
    Then Exact HTTP fields, typed result and nested schema checks match; responses close; generic403/timeout/invalid arguments stop within finite budgets
    And request path is /v2/ontologies/qa-ontology079/actionTypes/rename-device079/fullMetadata
    And source declares zero named throwable errors

  Scenario: F079-OntologyInterface-aggregate v2.ontologies.OntologyInterface.aggregate
    Given Frozen SDK1.101, synthetic Device079/Inspectable079 schema, fake identity and denied public network
    When Invoke native OntologyInterfaceClient.aggregate with the exact recorded kwargs in all six exposed forms
    Then Exact HTTP fields, typed result and nested schema checks match; responses close; generic403/timeout/invalid arguments stop within finite budgets
    And request path is /v2/ontologies/qa-ontology079/interfaces/Inspectable079/aggregate
    And source declares zero named throwable errors
