"""Extend inherited Nov17 case data while preserving its authorship and evidence."""
import ast
import hashlib
import importlib
import json
from pathlib import Path
import subprocess
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
AUTHOR = '/root/rest079_formal_case_author_recover_20261118'
OLD = ROOT / '.ept/tmp/feature015_rest079_formal_cases_20261117'
data = json.loads((OLD / 'rest079_formal_cases.json').read_text())
data['original_author_identity'] = data['author_identity']
data['author_identity'] = AUTHOR
data['recovery_date'] = '2026-11-18'
data['preserved_history'] = {name: hashlib.sha256((OLD / name).read_bytes()).hexdigest()
                             for name in ['first_three_author_dry_run.json', 'rest079_formal_cases.json',
                                          'rest079_formal_execute.py', 'rest079_assets_freeze.json']}
extension_tree = ast.parse((HERE / 'additional_checks.py').read_text())
fault_function = next(n for n in extension_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'semantic_fault_matrix')
data['semantic_faults'] = ast.literal_eval(fault_function.body[0].value)
repo = ROOT / '.ept/tmp/feature015_rest079_unit_modes'
register_raw = subprocess.check_output(['git', '-C', str(repo), 'show', data['published_skills'] + ':maintainer/rest-contract-register.json'])
(HERE / 'published_register.json').write_bytes(register_raw)
register = json.loads(register_raw)
bindings = {r['id']: r for r in register['operations']}
source_docs = {}
source_repo = ROOT / '.ept/docs/customer_input/foundry-platform-python'
(HERE / 'source_docs').mkdir(exist_ok=True)
for resource in {c['operation'].split('.')[2] for c in data['operations']}:
    source_path = f'docs/v2/Ontologies/{resource}.md'
    raw = subprocess.check_output(['git', '-C', str(source_repo), 'show', data['source_commit'] + ':' + source_path])
    path = HERE / 'source_docs' / (resource + '.md')
    path.write_bytes(raw)
    source_docs[resource] = {'path': str(path), 'source_path': source_path, 'sha256': hashlib.sha256(raw).hexdigest()}
for case in data['operations']:
    if case['operation'] in ('v2.ontologies.ActionType.search', 'v2.ontologies.OntologyInterface.search', 'v2.ontologies.OntologyInterface.list_objects_for_interface'):
        case['response']['totalCount'] = '1'
    if case['operation'] == 'v2.ontologies.ObjectType.get_edits_history':
        case['response']['data'][0]['operationId'] = 'ri.qa.main.operation.history079'
        case['response']['data'][0]['timestamp'] = '2026-11-16T08:00:00+00:00'
    binding = bindings[case['operation']]
    resource, method = case['operation'].split('.')[-2:]
    doc = Path(source_docs[resource]['path']).read_text()
    stage = re.search(r'\[\*\*' + re.escape(method) + r'\*\*\]\([^)]*\) \| \*\*\w+\*\* [^|]+\| ([^|]+) \|', doc).group(1).strip()
    assert stage == binding['stage']
    section = doc.split('# **' + method + '**', 1)[1].split('\n# **', 1)[0]
    case['source']['narrative_error_mentions'] = ['ObjectsExceededLimit'] if 'ObjectsExceededLimit' in section else []
    case['availability'] = {'api_version': 'v2', 'stage': stage,
                            'named_sdk_errors': [], 'source_silence': 'No universal scope, permission, idempotency or retry guarantee is inferred.'}
    case['adverse'] = {'generic_403': {'class': 'PermissionDeniedError', 'errorName': 'IndependentDenied079', 'requests': 1},
                       'timeout': {'class': 'ReadTimeout', 'cause': 'httpx.ReadTimeout', 'requests': 1, 'replay': False},
                       'invalid_timeout': {'request_timeout': 0, 'exception': 'pydantic.ValidationError', 'requests': 0},
                       'stream': {'unread': True, 'interrupted': True, 'async_cancel': True, 'closed': True,
                                  'caller_consumed_byte_limit': data['budgets']['max_stream_bytes'], 'transport_chunk_may_be_larger': True},
                       'paging': {'enabled': case['source']['paged'], 'page_budget': 3, 'item_budget': 1,
                                  'empty': 'complete', 'empty_with_continuation': 'continue-until-next-data',
                                  'repeated_cursor': 'stop-retain', 'budget': 'three-distinct-cursors-partial-retain'}}
    case['given'] = 'SDK1.101.0, frozen published reader, fake identity, independently declared Device079/Inspectable079 schema and denied public network'
    case['when'] = 'Invoke ' + case['operation'] + ' in six native forms with exact kwargs below'
    case['then'] = 'Match exact wire and typed nested result; generic403/timeout each send once; zero timeout sends nothing; unread/interrupted/canceled responses close'
    module = importlib.import_module(case['source']['module'])
    tree = ast.parse(Path(module.__file__).read_bytes())
    resource, method = case['operation'].split('.')[-2:]
    wrappers = {}
    for prefix in ('', 'Async'):
        for suffix in ('Raw', 'Streaming'):
            class_name = '_' + prefix + resource + 'Client' + suffix
            cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name)
            init = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == '__init__')
            stub = next(n for n in init.body if isinstance(n, ast.FunctionDef) and n.name == method)
            assignment = next(n for n in init.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Attribute) and t.attr == method for t in n.targets))
            wrappers[class_name] = {'response_annotation': ast.unparse(stub.args.args[0].annotation),
                                    'factory': ast.unparse(assignment.value)}
    case['source']['wrapper_factories'] = wrappers

freeze = json.loads((OLD / 'rest079_assets_freeze.json').read_text())
freeze['original_skill_root'] = freeze['skill_root']
freeze['skill_root'] = str(HERE / 'reader/.agents/skills/pal-found-dev')
freeze['published_register_sha256'] = hashlib.sha256(register_raw).hexdigest()
freeze['partition_sha256'] = hashlib.sha256((ROOT / '.ept/docs/deliverables/development/FEATURE-015-rest-operation-partitions.json').read_bytes()).hexdigest()
freeze['register_bindings'] = {c['operation']: bindings[c['operation']] for c in data['operations']}
freeze['source_documents'] = source_docs

# Freeze every linked model page's actual source definition, including aliases.
skill = Path(freeze['skill_root'])
model_pages = {}
source_definitions = {}
for case in data['operations']:
    contract = '\n'.join((skill / part).read_text() for part in bindings[case['operation']]['parts'])
    import re
    for name, relative in re.findall(r'\[([^\]]+)\]\(([^)]+\.md)\)', contract):
        if not name.startswith('foundry_sdk.'):
            continue
        path = (skill / case['reader']['contract']).parent / relative
        path = path.resolve()
        text = path.read_text()
        blocks = re.findall(r'```python\n(.*?)\n```', text, re.S)
        definition = next((b for b in blocks if re.search(r'\b' + re.escape(name.rsplit('.', 1)[1]) + r'\b', b)), None)
        assert definition, name
        model_pages[name] = {'path': path.relative_to(skill).as_posix(), 'definition_ast': ast.dump(ast.parse(definition), include_attributes=False)}
freeze['model_pages'] = model_pages
pending = list(model_pages)
while pending:
    qualified = pending.pop()
    page = skill / model_pages[qualified]['path']
    for name, relative in re.findall(r'\[([^\]]+)\]\(([^)]+\.md)\)', page.read_text()):
        if not name.startswith('foundry_sdk.') or name in model_pages:
            continue
        path = (page.parent / relative).resolve()
        blocks = re.findall(r'```python\n(.*?)\n```', path.read_text(), re.S)
        definition = next((b for b in blocks if re.search(r'\b' + re.escape(name.rsplit('.', 1)[1]) + r'\b', b)), None)
        assert definition, name
        model_pages[name] = {'path': path.relative_to(skill).as_posix(), 'definition_ast': ast.dump(ast.parse(definition), include_attributes=False)}
        pending.append(name)
freeze['runtime_sources'] = {}
source_repo = ROOT / '.ept/docs/customer_input/foundry-platform-python'
modules = {name.rsplit('.', 1)[0] for name in model_pages} | {c['source']['module'] for c in data['operations']}
for module_name in sorted(modules):
    module = importlib.import_module(module_name)
    path = Path(module.__file__)
    relative = module_name.replace('.', '/') + ('/__init__.py' if path.name == '__init__.py' else '.py')
    frozen_bytes = subprocess.check_output(['git', '-C', str(source_repo), 'show', data['source_commit'] + ':' + relative])
    assert path.read_bytes() == frozen_bytes, module_name
    freeze['runtime_sources'][str(path)] = hashlib.sha256(frozen_bytes).hexdigest()
for filename, payload in [('rest079_formal_cases.json', data), ('rest079_assets_freeze.json', freeze)]:
    (HERE / filename).write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')

lines = ['Feature: REST079 source-bound Ontology schema and interface cases',
         '  # Recovered 2026-11-18; independent review and separate executor required.']
for c in data['operations']:
    lines += ['', '  Scenario: ' + c['case_id'], '    Given ' + c['given'],
              '    When ' + c['when'], '    Then ' + c['then'],
              '    And API v2 release stage is ' + c['availability']['stage'],
              '    And exact SDK inputs are', '      """', '      ' + json.dumps(c['kwargs'], sort_keys=True), '      """',
              '    And exact HTTP expectation is', '      """', '      ' + json.dumps(c['wire'], sort_keys=True), '      """',
              '    And exact decoded response is', '      """', '      ' + json.dumps(c['response'], sort_keys=True), '      """',
              '    And runtime response type is ' + c['source']['response_type'],
              '    And nested schema category is ' + c['semantic'],
              '    And source named SDK error union is empty']
    lines += ['    And exact adverse outcomes are', '      """', '      ' + json.dumps(c['adverse'], sort_keys=True), '      """']
    if c['source']['paged']:
        lines += ['    And terminal empty page completes; intermediate empty page follows continuation to next data',
                  '    And repeated cursor stops; three distinct cursor pages or one-item budget retains partial items and continuation']
    lines += ['    And caller consumes at most four stream bytes, retains partial bytes and closes response even when transport chunk is larger']
lines += ['', '  Scenario: Source and reader closure',
          '    Given exact32 partition and frozen425 catalog',
          '    When source AST, mode annotations, all model definitions and local links are reconciled',
          '    Then every source definition, operation identity and version route agrees; changed claims fail',
          '', '  Scenario: Opaque fields and local schema decisions',
          '    Given unknown object or aggregation keys and declared interface schema',
          '    When SDK decodes raw values and reader considers local derivation',
          '    Then retain opaque data and stop unsupported derivation without inventing server rejection']
for suffix, fault, path, replacement in data['semantic_faults']:
    lines += ['', '  Scenario: Nested constraint ' + suffix + ' ' + fault,
              '    Given independent expected response for v2.ontologies.' + suffix,
              '    When path ' + json.dumps(path) + ' becomes ' + json.dumps(replacement),
              '    Then local semantic check rejects this response and records whether source SDK shape validation accepts it',
              '    And no server validation or live execution is claimed']
(HERE / 'rest079_formal_cases.feature').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps({'cases': len(data['operations']), 'model_pages': len(model_pages), 'author': AUTHOR}))
