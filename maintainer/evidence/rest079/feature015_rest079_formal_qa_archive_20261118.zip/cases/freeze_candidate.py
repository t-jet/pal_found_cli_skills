"""Hash the review candidate and verify preserved history and execution gates."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

data = json.loads((HERE / 'rest079_formal_cases.json').read_text())
freeze = json.loads((HERE / 'rest079_assets_freeze.json').read_text())
report_name = 'recovery_author_dry_run_peer_corrections_v2.json'
report = json.loads((HERE / report_name).read_text())
assert report['outcome'] == 'AUTHOR_DRY_RUN_PASS' and report['formal_execution'] is False
assert report['author_identity'] == data['author_identity']
files = ['rest079_formal_cases.json', 'rest079_formal_cases.feature', 'rest079_formal_execute.py',
         'additional_checks.py', 'rest079_assets_freeze.json', 'published_register.json',
         'complete_cases.py', report_name]
hashes = {name: sha(HERE / name) for name in files}
for key, name in [('case_sha256', 'rest079_formal_cases.json'), ('harness_sha256', 'rest079_formal_execute.py'),
                  ('additional_checks_sha256', 'additional_checks.py'), ('freeze_sha256', 'rest079_assets_freeze.json'),
                  ('feature_sha256', 'rest079_formal_cases.feature')]:
    assert report[key] == hashes[name]
old = ROOT / '.ept/tmp/feature015_rest079_formal_cases_20261117'
for name, expected in data['preserved_history'].items():
    assert sha(old / name) == expected
assert sha(HERE / 'first_three_author_dry_run.json') == sha(old / 'first_three_author_dry_run.json')
original_freeze = json.loads((old / 'rest079_assets_freeze.json').read_text())
assert freeze['assets'] == original_freeze['assets']
for relative, expected in freeze['assets'].items():
    assert sha(Path(freeze['skill_root']) / relative) == expected
audit_path = ROOT / '.ept/tmp/feature015_rest079_unit_modes/maintainer/rest-domain-independent-review-079-current.json'
audit = json.loads(audit_path.read_text())
prior_roster = {r['symbol'] for r in audit['model_source_and_asset_evidence']}
assert prior_roster == set(freeze['model_pages'])
closure = next(c for c in report['checks'] if c['check'] == 'source_derived_per32_membership_and_changed_definition_mutant')
assert set().union(*(set(v) for v in closure['operation_closures'].values())) == prior_roster
gates = []
for executor in (data['author_identity'], data['original_author_identity']):
    output = HERE / ('forbidden_execution_' + str(len(gates)) + '.json')
    assert not output.exists()
    result = subprocess.run([sys.executable, str(HERE / 'rest079_formal_execute.py'),
                             '--executor', executor, '--output', str(output)], capture_output=True, text=True)
    assert result.returncode != 0 and 'Different formal executor required' in result.stderr
    assert not output.exists()
    gates.append({'executor': executor, 'exit_code': result.returncode, 'reason': 'Different formal executor required', 'execution_started': False})
proof = {'kind': 'CASE_REVIEW_CANDIDATE', 'candidate_revision': 2, 'created_date': '2026-11-18',
         'author_identity': data['author_identity'], 'original_author_identity': data['original_author_identity'],
         'formal_execution': False, 'review_status': 'PENDING_INDEPENDENT_REVIEW',
         'testcase': 'TESTCASE-079', 'testexec': 'TESTEXEC-079',
         'published_skills': data['published_skills'], 'sdk_source_commit': data['source_commit'],
         'hashes': hashes, 'original_history': data['preserved_history'],
         'reader_assets': len(freeze['assets']), 'model_definition_members': sorted(prior_roster),
         'prior_roster_comparison': {'artifact_sha256': sha(audit_path), 'exact_membership_match': True,
             'expectation_boundary': 'Prior roster comparison follows independent frozen-source AST and graph checks; prior tests supplied no expected payloads.'},
         'operation_count': len(data['operations']), 'pagers': sum(c['source']['paged'] for c in data['operations']),
         'ordinary_async_iterators': sum(c['source']['iterator'] for c in data['operations']),
         'source_runtime_files': len(freeze['runtime_sources']), 'source_documents': len(freeze['source_documents']),
         'author_checks': len(report['checks']), 'gate_negative_controls': gates,
         'prior_candidate_preserved': {'folder': str(HERE / 'candidate_v1_frozen'),
             'proof_sha256': sha(HERE / 'candidate_v1_frozen/review_candidate_proof.json')},
         'peer_corrections': ['Three requested pages with distinct continuation cursors retain partial result after exact budget',
             'Eleven sync/async raw pagers and eight sync/async native iterators continue after empty intermediate page',
             'All32 sync/async streams consume exactly four caller bytes and close; larger transport chunk is explicit'],
         'unclosed_gates': ['Independent case review and tracker Gherkin recording',
                           'TESTCASE079 DoD and closure by authorized owner',
                           'Different executor verifies TESTEXEC079 prerequisites and executes approved hashes'],
         'live_enrollment_execution': False}
destination = HERE / 'review_candidate_proof_v2.json'
destination.write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'outcome': report['outcome'], 'checks': len(report['checks']), 'reader_assets': len(freeze['assets']),
                  'models': len(prior_roster), 'proof_sha256': sha(destination), 'hashes': hashes}, indent=2))
