"""v2.widgets.DevModeSettingsV2.set_widget_set_manifest: SDK request, decoded result and declared error fixtures.

Synthetic identifiers do not name tenant resources. Prepared SDK 1.101.0/httpx
required. No network connections or live mutations occur.
"""
import json
import sys
import urllib.parse
import datetime
from pathlib import Path

import httpx
from foundry_sdk import PalantirRPCException
from foundry_sdk.v2.widgets.dev_mode_settings_v2 import DevModeSettingsV2Client

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / 'common'))
from mock_transport import mock_resource

EXPECTED_METHOD = 'POST'
EXPECTED_PATH = '/api/v2/widgets/devModeSettingsV2/setWidgetSetManifest'
EXPECTED_BODY = {'widgetSetRid': 'ri.widgets.main.widget-set.00000000-0000-0000-0000-000000000001',
 'manifest': {'manifestVersion': '1.0.0', 'devSettings': {'baseHref': 'http://localhost:5173/', 'widgets': {'inspection-summary': {'id': 'inspection-summary', 'name': 'Inspection summary', 'type': 'workshopWidgetV1', 'entrypointJs': [{'path': 'http://localhost:5173/assets/inspection.js', 'type': 'module'}], 'entrypointCss': [{'path': 'http://localhost:5173/assets/inspection.css'}], 'parameters': {}, 'events': {}}}, 'inputSpec': {'discovered': {'sdks': []}}}}}
EXPECTED_QUERY = {'preview': None}
EXPECTED_HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}
SUCCESS = {'status': 'ENABLED'}
ERRORS = [{'name': 'InvalidDevModeBaseHref',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'baseHref': 'synthetic-value'}},
 {'name': 'InvalidDevModeEntrypointCssCount',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'reason': 'synthetic-value', 'entrypointCssCount': 1}},
 {'name': 'InvalidDevModeEntrypointJsCount',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'reason': 'synthetic-value', 'entrypointJsCount': 1}},
 {'name': 'InvalidDevModeFilePath',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'reason': 'synthetic-value', 'filePath': 'synthetic-value'}},
 {'name': 'InvalidDevModeWidgetSettingsCount',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'reason': 'synthetic-value', 'widgetSettingsCount': 1}},
 {'name': 'InvalidManifest',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'reason': 'synthetic-value'}},
 {'name': 'SetWidgetSetManifestDevModeSettingsV2PermissionDenied',
  'status': 403,
  'code': 'PERMISSION_DENIED',
  'parameters': {}},
 {'name': 'WidgetIdNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'widgetSetRid': 'ri.widgets.main.widget-set.00000000-0000-0000-0000-000000000001',
                 'widgetId': 'synthetic-value'}}]

# SDK documents the envelope; nested fields follow the official osdk-ts widget API.
# This fixture uses a published widget without Ontology SDK dependencies.
def invoke(client):
    return client.with_raw_response.set_widget_set_manifest(manifest={'manifestVersion': '1.0.0', 'devSettings': {'baseHref': 'http://localhost:5173/', 'widgets': {'inspection-summary': {'id': 'inspection-summary', 'name': 'Inspection summary', 'type': 'workshopWidgetV1', 'entrypointJs': [{'path': 'http://localhost:5173/assets/inspection.js', 'type': 'module'}], 'entrypointCss': [{'path': 'http://localhost:5173/assets/inspection.css'}], 'parameters': {}, 'events': {}}}, 'inputSpec': {'discovered': {'sdks': []}}}}, widget_set_rid='ri.widgets.main.widget-set.00000000-0000-0000-0000-000000000001', request_timeout=30)

def check_request(request):
    assert request.method == EXPECTED_METHOD
    assert urllib.parse.unquote(request.url.path) == EXPECTED_PATH
    assert request.headers['Authorization'] == 'Bearer offline-fixture-token'
    for key, value in EXPECTED_HEADERS.items():
        if value is None:
            assert key not in request.headers
        else:
            assert request.headers[key] == str(value)
    expected = httpx.QueryParams({key: value for key,value in EXPECTED_QUERY.items() if value is not None})
    assert sorted(request.url.params.multi_items()) == sorted(expected.multi_items())
    if isinstance(EXPECTED_BODY, bytes):
        assert request.content == EXPECTED_BODY
    elif EXPECTED_BODY is not None:
        assert json.loads(request.content) == EXPECTED_BODY

def normalized(value):
    if isinstance(value, dict):
        return {key: normalized(child) for key,child in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalized(child) for child in value]
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.isoformat()
    if isinstance(value, bytes):
        return bytes(value)
    if hasattr(value, 'model_dump'):
        return value.model_dump(mode='json', by_alias=True, exclude_none=True)
    return value

def verify():
    calls = []
    def success(request):
        check_request(request)
        calls.append(True)
        if isinstance(SUCCESS, bytes):
            return httpx.Response(200, content=SUCCESS)
        if SUCCESS is None:
            return httpx.Response(204)
        return httpx.Response(200, json=SUCCESS)
    with mock_resource(DevModeSettingsV2Client, success) as client:
        raw = invoke(client)
        try:
            assert normalized(raw.decode()) == SUCCESS
        finally:
            raw.close()
    assert len(calls) == 1
    for error_case in ERRORS:
        def failure(request):
            check_request(request)
            return httpx.Response(error_case['status'], json={
                'errorName':error_case['name'], 'errorCode':error_case['code'],
                'parameters':error_case['parameters'],
                'errorInstanceId':'00000000-0000-0000-0000-000000000004',
            })
        with mock_resource(DevModeSettingsV2Client, failure) as client:
            try:
                raw = invoke(client)
                raw.close()
            except PalantirRPCException as error:
                assert error.name == error_case['name']
                assert type(error).__name__ == error_case['name']
                assert normalized(error.parameters) == error_case['parameters']
            else:
                raise AssertionError('Expected ' + error_case['name'])

if __name__ == '__main__':
    verify()
    print('v2.widgets.DevModeSettingsV2.set_widget_set_manifest' + ': serialized request, decoded result and ' + str(len(ERRORS)) + ' named errors passed')
