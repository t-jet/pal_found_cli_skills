"""v2.admin.MarkingRoleAssignment.add: SDK request, decoded result and declared error fixtures.

Synthetic identifiers do not name tenant resources. Prepared SDK 1.101.0/httpx
required. No network connections or live mutations occur.
"""
import json
import sys
import urllib.parse
import datetime
from pathlib import Path

import httpx
from foundry_sdk import PalantirRPCException
from foundry_sdk.v2.admin.marking_role_assignment import MarkingRoleAssignmentClient

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / 'common'))
from mock_transport import mock_resource

EXPECTED_METHOD = 'POST'
EXPECTED_PATH = '/api/v2/admin/markings/synthetic-value/roleAssignments/add'
EXPECTED_BODY = {'roleAssignments': [{'role': 'USE',
                      'principalId': '00000000-0000-0000-0000-000000000001'}]}
EXPECTED_QUERY = {}
EXPECTED_HEADERS = {'Content-Type': 'application/json'}
SUCCESS = None
ERRORS = [{'name': 'AddMarkingRoleAssignmentsPermissionDenied',
  'status': 403,
  'code': 'PERMISSION_DENIED',
  'parameters': {'markingId': 'synthetic-value'}},
 {'name': 'GetMarkingPermissionDenied',
  'status': 403,
  'code': 'PERMISSION_DENIED',
  'parameters': {'markingId': 'synthetic-value'}},
 {'name': 'MarkingNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'markingId': 'synthetic-value'}},
 {'name': 'OrganizationMarkingAdministerRoleNotSupported',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'markingId': 'synthetic-organization-marking',
                 'organizationRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001'}},
 {'name': 'PrincipalNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'principalId': '00000000-0000-0000-0000-000000000001'}}]

def invoke(client, role='USE', marking_id='synthetic-value'):
    return client.with_raw_response.add(marking_id=marking_id, role_assignments=[{'role': role, 'principalId': '00000000-0000-0000-0000-000000000001'}], request_timeout=30)

def check_request(request, role='USE', marking_id='synthetic-value'):
    assert request.method == EXPECTED_METHOD
    assert urllib.parse.unquote(request.url.path) == EXPECTED_PATH.replace('/synthetic-value/', f'/{marking_id}/')
    assert request.headers['Authorization'] == 'Bearer offline-fixture-token'
    for key, value in EXPECTED_HEADERS.items():
        if value is None:
            assert key not in request.headers
        else:
            assert request.headers[key] == str(value)
    expected = httpx.QueryParams({key: value for key,value in EXPECTED_QUERY.items() if value is not None})
    assert sorted(request.url.params.multi_items()) == sorted(expected.multi_items())
    assert json.loads(request.content) == {'roleAssignments': [
        {'role': role, 'principalId': '00000000-0000-0000-0000-000000000001'}]}

def normalized(value):
    if isinstance(value, dict):
        return {key: normalized(child) for key,child in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalized(child) for child in value]
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.isoformat()
    if isinstance(value, bytes):
        return bytes(value)
    if hasattr(value, 'model_dump'):
        return value.model_dump(mode='json', by_alias=True, exclude_none=True)
    return value

def verify():
    calls = []
    def success(request):
        check_request(request)
        calls.append(True)
        if isinstance(SUCCESS, bytes):
            return httpx.Response(200, content=SUCCESS)
        if SUCCESS is None:
            return httpx.Response(204)
        return httpx.Response(200, json=SUCCESS)
    with mock_resource(MarkingRoleAssignmentClient, success) as client:
        raw = invoke(client)
        try:
            assert normalized(raw.decode()) == SUCCESS
        finally:
            raw.close()
    assert len(calls) == 1
    for error_case in ERRORS:
        organization_error = error_case['name'] == 'OrganizationMarkingAdministerRoleNotSupported'
        role = 'ADMINISTER' if organization_error else 'USE'
        marking_id = 'synthetic-organization-marking' if organization_error else 'synthetic-value'
        def failure(request):
            check_request(request, role=role, marking_id=marking_id)
            return httpx.Response(error_case['status'], json={
                'errorName':error_case['name'], 'errorCode':error_case['code'],
                'parameters':error_case['parameters'],
                'errorInstanceId':'00000000-0000-0000-0000-000000000004',
            })
        with mock_resource(MarkingRoleAssignmentClient, failure) as client:
            try:
                raw = invoke(client, role=role, marking_id=marking_id)
                raw.close()
            except PalantirRPCException as error:
                assert error.name == error_case['name']
                assert type(error).__name__ == error_case['name']
                assert normalized(error.parameters) == error_case['parameters']
            else:
                raise AssertionError('Expected ' + error_case['name'])

if __name__ == '__main__':
    verify()
    print('v2.admin.MarkingRoleAssignment.add' + ': serialized request, decoded result and ' + str(len(ERRORS)) + ' named errors passed')
