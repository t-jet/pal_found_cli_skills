"""v2.ontologies.ObjectType.get_edits_history: SDK request, decoded result and declared error fixtures.

Synthetic identifiers do not name tenant resources. Prepared SDK 1.101.0/httpx
required. No network connections or live mutations occur.
"""
import json
import sys
import urllib.parse
import datetime
from pathlib import Path

import httpx
from foundry_sdk import PalantirRPCException
from foundry_sdk.v2.ontologies.object_type import ObjectTypeClient

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / 'common'))
from mock_transport import mock_resource

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from synthetic_schema import check_history

EXPECTED_METHOD = 'POST'
EXPECTED_PATH = '/api/v2/ontologies/synthetic-value/objectTypes/Asset/editsHistory'
EXPECTED_BODY = {}
EXPECTED_QUERY = {'branch': None, 'preview': None, 'scenarioRid': None}
EXPECTED_HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}
SUCCESS = {'data': [{'objectPrimaryKey': {'assetId': {'type': 'stringValue', 'value': 'A-1'}}, 'operationId': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001', 'actionTypeRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001', 'userId': 'synthetic-value', 'timestamp': '2026-10-07T00:00:00+00:00', 'edit': {'properties': {'assetId': 'A-1', 'name': 'Pump A-1', 'observedAt': '2026-10-07T00:00:00Z'}, 'type': 'createEdit'}}]}
ERRORS = []

def invoke(client):
    return client.with_raw_response.get_edits_history(ontology='synthetic-value', object_type='Asset', request_timeout=30)

def check_request(request):
    assert request.method == EXPECTED_METHOD
    assert urllib.parse.unquote(request.url.path) == EXPECTED_PATH
    assert request.headers['Authorization'] == 'Bearer offline-fixture-token'
    for key, value in EXPECTED_HEADERS.items():
        if value is None:
            assert key not in request.headers
        else:
            assert request.headers[key] == str(value)
    expected = httpx.QueryParams({key: value for key,value in EXPECTED_QUERY.items() if value is not None})
    assert sorted(request.url.params.multi_items()) == sorted(expected.multi_items())
    if isinstance(EXPECTED_BODY, bytes):
        assert request.content == EXPECTED_BODY
    elif EXPECTED_BODY is not None:
        assert json.loads(request.content) == EXPECTED_BODY

def normalized(value):
    if isinstance(value, dict):
        return {key: normalized(child) for key,child in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalized(child) for child in value]
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.isoformat()
    if isinstance(value, bytes):
        return bytes(value)
    if hasattr(value, 'model_dump'):
        return value.model_dump(mode='json', by_alias=True, exclude_none=True)
    return value

def check_result(value):
    check_history(value)


def verify():
    calls = []
    def success(request):
        check_request(request)
        calls.append(True)
        if isinstance(SUCCESS, bytes):
            return httpx.Response(200, content=SUCCESS)
        if SUCCESS is None:
            return httpx.Response(204)
        return httpx.Response(200, json=SUCCESS)
    with mock_resource(ObjectTypeClient, success) as client:
        raw = invoke(client)
        try:
            decoded = normalized(raw.decode())
            assert decoded == SUCCESS
            check_result(decoded)
        finally:
            raw.close()
    assert len(calls) == 1
    for error_case in ERRORS:
        def failure(request):
            check_request(request)
            return httpx.Response(error_case['status'], json={
                'errorName':error_case['name'], 'errorCode':error_case['code'],
                'parameters':error_case['parameters'],
                'errorInstanceId':'00000000-0000-0000-0000-000000000004',
            })
        with mock_resource(ObjectTypeClient, failure) as client:
            try:
                raw = invoke(client)
                raw.close()
            except PalantirRPCException as error:
                assert error.name == error_case['name']
                assert type(error).__name__ == error_case['name']
                assert normalized(error.parameters) == error_case['parameters']
            else:
                raise AssertionError('Expected ' + error_case['name'])

if __name__ == '__main__':
    verify()
    print('v2.ontologies.ObjectType.get_edits_history' + ': serialized request, decoded result and ' + str(len(ERRORS)) + ' named errors passed')
