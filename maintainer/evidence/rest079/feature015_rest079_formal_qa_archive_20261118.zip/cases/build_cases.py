"""Author independent REST079 cases from frozen SDK source and reader contracts."""
import ast
import copy
import hashlib
import importlib
import inspect
import io
import json
from pathlib import Path
import subprocess
import zipfile
import typing

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PUBLISHED = '4de1e23e98017536bcff0eef2aa1d057e576e056'
SDK_COMMIT = '168d51910570b6966afa2320333ab36f6a3f7ccf'
REPO = ROOT / '.ept/tmp/feature015_rest079_unit_modes'
SDK_REPO = ROOT / '.ept/docs/customer_input/foundry-platform-python'
AUTHOR = '/root/rest079_unit_independent_qa_20261117'
SKILL = HERE / 'reader/.agents/skills/pal-found-dev'


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, default=lambda v: v.model_dump(mode='json', by_alias=True, exclude_none=True)) + '\n', encoding='utf-8')


if not SKILL.exists():
    archive = git(REPO, 'archive', '--format=zip', PUBLISHED, '.agents/skills/pal-found-dev')
    with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
        bundle.extractall(HERE / 'reader')

# This QA schema is declared here, independently of distributed fixture constants.
DEVICE = {
    'apiName': 'Device079', 'displayName': 'Inspection device', 'pluralDisplayName': 'Inspection devices',
    'status': 'EXPERIMENTAL', 'rid': 'ri.qa.main.object-type.device079',
    'icon': {'type': 'blueprint', 'name': 'wrench', 'color': '#126734'},
    'primaryKey': 'deviceId', 'titleProperty': 'label',
    'properties': {name: {'rid': 'ri.qa.main.property.' + name, 'dataType': {'type': kind}}
                   for name, kind in [('deviceId', 'string'), ('label', 'string'), ('recordedAt', 'timestamp')]},
}
ACTION_FULL = {
    'actionType': {
        'apiName': 'rename-device079', 'status': 'EXPERIMENTAL', 'rid': 'ri.qa.main.action-type.rename-device079',
        'parameters': {
            'device': {'displayName': 'Device', 'required': True,
                       'dataType': {'type': 'interfaceObject', 'interfaceTypeApiName': 'Inspectable079'}},
            'labelText': {'displayName': 'Label', 'required': True, 'dataType': {'type': 'string'}},
        },
        'operations': [{'type': 'modifyInterfaceObject', 'interfaceTypeApiName': 'Inspectable079'}],
    },
    'fullLogicRules': [{'type': 'modifyInterface', 'interfaceObjectToModify': 'device',
                        'sharedPropertyArguments': {'label': {'type': 'parameterId', 'parameterId': 'labelText'}},
                        'structPropertyArguments': {}}],
}
AGGREGATE_BODY = {
    'aggregation': [{'type': 'approximateDistinct', 'field': 'deviceId', 'name': 'uniqueDevices079'}],
    'groupBy': [{'type': 'duration', 'field': 'recordedAt', 'value': 2, 'unit': 'DAYS'}],
}
AGGREGATE_RESULT = {'accuracy': 'APPROXIMATE', 'data': [
    {'group': {'recordedAt': '2026-11-16T00:00:00Z'},
     'metrics': [{'name': 'uniqueDevices079', 'value': 2}]}]}
SHARED = {name: {'rid': 'ri.qa.main.shared-property.' + name, 'apiName': name, 'displayName': name,
                 'dataType': copy.deepcopy(prop['dataType']), 'required': True, 'type': 'interfaceSharedPropertyType'}
          for name, prop in DEVICE['properties'].items()}
INTERFACE_LINK = {'rid': 'ri.qa.main.interface-link-type.inspectables079', 'apiName': 'inspectedPeers079',
                  'displayName': 'Inspected peers', 'linkedEntityApiName': {'type': 'interfaceTypeApiName', 'apiName': 'Inspectable079'},
                  'cardinality': 'MANY', 'required': True}
INTERFACE = {'rid': 'ri.qa.main.interface-type.inspectable079', 'apiName': 'Inspectable079', 'displayName': 'Inspectable',
             'properties': copy.deepcopy(SHARED), 'allProperties': copy.deepcopy(SHARED), 'propertiesV2': copy.deepcopy(SHARED),
             'allPropertiesV2': {name: {**{key: value for key, value in prop.items() if key not in ('required', 'type')},
                                            'requireImplementation': True} for name, prop in SHARED.items()},
             'extendsInterfaces': [], 'allExtendsInterfaces': [], 'implementedByObjectTypes': ['Device079'],
             'links': {'inspectedPeers079': copy.deepcopy(INTERFACE_LINK)}, 'allLinks': {'inspectedPeers079': copy.deepcopy(INTERFACE_LINK)}}
OBJECT_LINK = {'apiName': 'relatedDevices079', 'displayName': 'Related devices', 'status': 'EXPERIMENTAL',
               'objectTypeApiName': 'Device079', 'cardinality': 'MANY', 'linkTypeRid': 'ri.qa.main.link-type.related-devices079'}
DEVICE_FULL = {'objectType': copy.deepcopy(DEVICE), 'linkTypes': [copy.deepcopy(OBJECT_LINK)],
               'implementsInterfaces': ['Inspectable079'], 'implementsInterfaces2': {
                   'Inspectable079': {'apiName': 'Inspectable079', 'rid': INTERFACE['rid'],
                                       'properties': {name: name for name in SHARED},
                                       'propertiesV2': {name: {'type': 'localPropertyImplementation', 'propertyApiName': name} for name in SHARED},
                                       'links': {'inspectedPeers079': ['relatedDevices079']}}},
               'sharedPropertyTypeMapping': {name: name for name in SHARED}}
VALUE_TYPE = {'apiName': 'InspectionDate079', 'displayName': 'Inspection date', 'rid': 'ri.qa.main.value-type.inspection-date079',
              'fieldType': {'type': 'date'}, 'version': '3', 'constraints': []}
QUERY = {'apiName': 'countDevices079', 'rid': 'ri.qa.main.query-type.count-devices079', 'version': '2.3.0',
         'parameters': {'labelPrefix': {'dataType': {'type': 'string'}, 'required': True}},
         'output': {'type': 'integer'}, 'typeReferences': {}}
ONTOLOGY = {'apiName': 'qa-ontology079', 'displayName': 'QA Ontology 079', 'description': 'Synthetic inspection metadata',
            'rid': 'ri.qa.main.ontology.inspection079'}
ONTOLOGY_FULL = {'ontology': copy.deepcopy(ONTOLOGY), 'objectTypes': {'Device079': copy.deepcopy(DEVICE_FULL)},
                 'actionTypes': {'rename-device079': copy.deepcopy(ACTION_FULL['actionType'])},
                 'queryTypes': {'countDevices079': copy.deepcopy(QUERY)}, 'interfaceTypes': {'Inspectable079': copy.deepcopy(INTERFACE)},
                 'sharedPropertyTypes': {name: {key: value for key, value in prop.items() if key not in ('required', 'type')} for name, prop in SHARED.items()},
                 'valueTypes': {'InspectionDate079': copy.deepcopy(VALUE_TYPE)}}
HISTORY = {'data': [{'objectPrimaryKey': {'deviceId': {'type': 'stringValue', 'value': 'D-079'}},
                     'operationId': 'qa-history079', 'actionTypeRid': ACTION_FULL['actionType']['rid'],
                     'userId': 'qa-user079', 'timestamp': '2026-11-16T08:00:00Z',
                     'edit': {'type': 'createEdit', 'objectType': 'Device079',
                              'properties': {'deviceId': 'D-079', 'label': 'Valve 079', 'recordedAt': '2026-11-16T08:00:00Z'}}}]}


def object_payload(key):
    return {'__apiName': 'Device079', '__primaryKey': key, '__rid': 'ri.qa.main.object.' + key,
            'deviceId': key, 'label': 'Device ' + key, 'recordedAt': '2026-11-16T08:00:00Z'}


def source_record(resource, method, kwargs):
    module_name = 'foundry_sdk.v2.ontologies.' + ''.join('_' + c.lower() if c.isupper() else c for c in resource).lstrip('_')
    raw = git(SDK_REPO, 'show', SDK_COMMIT + ':' + module_name.replace('.', '/') + '.py')
    module = importlib.import_module(module_name)
    assert raw == Path(module.__file__).read_bytes()
    tree = ast.parse(raw)
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    methods = {}
    for prefix in ('', 'Async'):
        cls = classes[prefix + resource + 'Client']
        fn = next(node for node in cls.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == method)
        calls = [node for node in ast.walk(fn) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute) and node.func.attr == 'RequestInfo']
        request, = calls
        fields = {kw.arg: kw.value for kw in request.keywords}
        assert ast.literal_eval(fields['throwable_errors']) == {}
        methods[prefix + resource + 'Client'] = {
            'arguments_ast': ast.dump(fn.args), 'return_annotation': ast.unparse(fn.returns),
            'coroutine_definition': isinstance(fn, ast.AsyncFunctionDef),
            'request_ast': {name: ast.unparse(value) for name, value in fields.items()},
        }
    fn = getattr(getattr(module, resource + 'Client'), method)
    bound = inspect.signature(fn).bind(None, **kwargs, request_timeout=7)
    bound.apply_defaults()
    env = bound.arguments
    wire = {name: eval(compile(ast.Expression(node), '<frozen source authoring only>', 'eval'), vars(module), env)
            for name, node in fields.items()}
    response = wire['response_type']
    iterator = wire['response_mode'] == 'ITERATOR'
    wire = {'method': wire['method'], 'path': wire['resource_path'].format(**wire['path_params']),
            'query': {key: value for key, value in wire['query_params'].items() if value is not None},
            'headers': wire['header_params'], 'body': wire['body']}
    element = None
    if iterator:
        data_type = response.model_fields['data'].annotation
        if isinstance(data_type, typing.ForwardRef):
            response.model_rebuild()
            data_type = response.model_fields['data'].annotation
        child_type = typing.get_args(data_type)[0]
        child_type = typing.get_origin(child_type) or child_type
        element = child_type.__module__ + '.' + child_type.__name__
    return {'module': module_name, 'sha256': sha(raw), 'methods': methods, 'iterator': iterator,
            'paged': 'page_token' in bound.arguments, 'element_type': element,
            'response_type': response.__module__ + '.' + response.__name__,
            'source_named_errors': []}, wire


FIRST_THREE_DEFINITIONS = [
    ('ObjectType', 'get', {'ontology': 'qa-ontology079', 'object_type': 'Device079', 'branch': 'qa-branch079',
                          'include_datasources': False}, DEVICE, 'device_schema'),
    ('ActionTypeFullMetadata', 'get', {'ontology': 'qa-ontology079', 'action_type': 'rename-device079',
                                      'branch': 'qa-branch079', 'preview': True}, ACTION_FULL, 'action_rule'),
    ('OntologyInterface', 'aggregate', {'ontology': 'qa-ontology079', 'interface_type': 'Inspectable079',
                                       'aggregation': AGGREGATE_BODY['aggregation'],
                                       'group_by': AGGREGATE_BODY['groupBy'], 'branch': 'qa-branch079',
                                       'preview': True}, AGGREGATE_RESULT, 'aggregate_schema'),
]
partition = json.loads((ROOT / '.ept/docs/deliverables/development/FEATURE-015-rest-operation-partitions.json').read_text())['partitions']['DEV-STORY-079']['operation_ids']
DEFINITIONS = []
for identity in partition:
    resource, method = identity.split('.')[2:]
    module_name = 'foundry_sdk.v2.ontologies.' + ''.join('_' + c.lower() if c.isupper() else c for c in resource).lstrip('_')
    signature = inspect.signature(getattr(getattr(importlib.import_module(module_name), resource + 'Client'), method))
    candidates = {'ontology': 'qa-ontology079', 'branch': 'qa-branch079', 'preview': True, 'page_size': 2,
                  'object_type': 'Device079', 'action_type': 'rename-device079', 'action_type_rid': ACTION_FULL['actionType']['rid'],
                  'interface_type': 'Inspectable079', 'interface_link_type': 'inspectedPeers079', 'link_type': 'relatedDevices079',
                  'primary_key': 'D-079', 'value_type': 'InspectionDate079', 'query_api_name': 'countDevices079',
                  'sdk_package_rid': 'ri.qa.main.sdk.package079', 'sdk_version': '0.7.9', 'version': '2.3.0',
                  'include_datasources': False, 'select': ['deviceId', 'label', 'recordedAt'], 'snapshot': True, 'exclude_rid': False}
    kwargs = {name: value for name, value in candidates.items() if name in signature.parameters}
    if method == 'get_by_rid_batch':
        key = {'ActionType': 'actionTypeRid', 'ObjectType': 'objectTypeRid', 'QueryType': 'queryTypeRid'}[resource]
        value = {'ActionType': ACTION_FULL['actionType']['rid'], 'ObjectType': DEVICE['rid'], 'QueryType': QUERY['rid']}[resource]
        kwargs['requests'] = [{key: value}]
    if method == 'get_outgoing_link_types_by_object_type_rid_batch':
        kwargs.update(requests=[{'objectTypeRid': DEVICE['rid']}], filter_link_type_rids=[OBJECT_LINK['linkTypeRid']])
    if method == 'get_edits_history':
        kwargs.update(object_primary_key={'deviceId': {'type': 'stringValue', 'value': 'D-079'}}, sort_order='oldest_first', include_all_previous_properties=True)
    if method == 'aggregate':
        kwargs.update(aggregation=copy.deepcopy(AGGREGATE_BODY['aggregation']), group_by=copy.deepcopy(AGGREGATE_BODY['groupBy']), accuracy='ALLOW_APPROXIMATE')
    if resource == 'OntologyInterface' and method == 'search':
        kwargs.update(augmented_interface_property_types={}, augmented_properties={}, augmented_shared_property_types={},
                      other_interface_types=[], selected_interface_property_types=[], selected_object_types=['Device079'],
                      selected_shared_property_types=['deviceId', 'label', 'recordedAt'],
                      where={'type': 'eq', 'field': 'label', 'value': 'Device D-079'})
    if resource == 'ActionType' and method == 'search':
        kwargs['where'] = {'type': 'actionTypeApiName', 'value': {'type': 'exact', 'value': 'rename-device079'}}
    if resource == 'Ontology' and method == 'load_metadata':
        kwargs.update(action_types=['rename-device079'], interface_types=['Inspectable079'], link_types=['relatedDevices079'],
                      object_types=['Device079'], query_types=['countDevices079'])
    if resource == 'ActionType':
        payload, semantic = ACTION_FULL['actionType'], 'action_summary'
    elif resource == 'ActionTypeFullMetadata':
        payload, semantic = ACTION_FULL, 'action_rule'
    elif resource == 'ObjectType':
        payload, semantic = DEVICE, 'device_schema'
        if method == 'get_full_metadata':
            payload, semantic = DEVICE_FULL, 'device_full'
        elif method == 'get_edits_history':
            payload, semantic = HISTORY, 'history'
        elif 'outgoing_link' in method:
            payload, semantic = OBJECT_LINK, 'object_link'
    elif resource == 'Ontology':
        payload, semantic = (ONTOLOGY_FULL, 'ontology_full') if method in ('get_full_metadata', 'load_metadata') else (ONTOLOGY, 'ontology')
    elif resource == 'OntologyInterface':
        payload, semantic = INTERFACE, 'interface'
        if method == 'aggregate':
            payload, semantic = AGGREGATE_RESULT, 'aggregate_schema'
        elif method in ('get_outgoing_interface_link_type', 'list_outgoing_interface_link_types'):
            payload, semantic = INTERFACE_LINK, 'interface_link'
        elif method in ('list_interface_linked_objects', 'list_objects_for_interface', 'search'):
            payload, semantic = object_payload('D-080' if method == 'list_interface_linked_objects' else 'D-079'), 'object_record'
    elif resource == 'OntologyValueType':
        payload, semantic = VALUE_TYPE, 'value_type'
    else:
        payload, semantic = QUERY, 'query'
    if method in ('list', 'search', 'get_by_rid_batch', 'list_outgoing_link_types', 'list_interface_linked_objects', 'list_objects_for_interface', 'list_outgoing_interface_link_types'):
        payload = {'data': [copy.deepcopy(payload)]}
    if method == 'get_outgoing_link_types_by_object_type_rid_batch':
        payload = {'data': {DEVICE['rid']: [copy.deepcopy(OBJECT_LINK)]}}
    DEFINITIONS.append((resource, method, kwargs, payload, semantic))
cases = []
for resource, method, kwargs, response, semantic in DEFINITIONS:
    source, wire = source_record(resource, method, kwargs)
    case_id = 'F079-' + resource + '-' + method
    cases.append({'case_id': case_id, 'operation': 'v2.ontologies.' + resource + '.' + method,
                  'kwargs': copy.deepcopy(kwargs), 'wire': wire, 'response': copy.deepcopy(response),
                  'source': source, 'semantic': semantic,
                  'reader': {'behavior': f'references/rest/v2/ontologies/{resource}.md',
                             'heading': f'{resource}.{method}',
                             'contract': f'references/rest/contracts/v2/ontologies/{resource}/{method}.md'},
                  'given': 'Frozen SDK1.101, synthetic Device079/Inspectable079 schema, fake identity and denied public network',
                  'when': f'Invoke native {resource}Client.{method} with the exact recorded kwargs in all six exposed forms',
                  'then': 'Exact HTTP fields, typed result and nested schema checks match; responses close; generic403/timeout/invalid arguments stop within finite budgets'})
data = {'testcase': 'TESTCASE-079', 'testexec': 'TESTEXEC-079', 'author_identity': AUTHOR,
        'published_skills': PUBLISHED, 'sdk_release': '1.101.0', 'source_commit': SDK_COMMIT,
        'approval': 'PENDING_INDEPENDENT_REVIEW', 'formal_execution': False,
        'checkpoint': 'ALL_32_AUTHOR_CANDIDATE', 'schema': {'object_type': DEVICE, 'action_full': ACTION_FULL, 'interface': INTERFACE},
        'budgets': {'timeout_seconds': 7, 'max_requests': 3, 'max_pages': 3, 'max_stream_bytes': 4},
        'operations': cases}
json_write('rest079_formal_cases.json', data)
assets = {path.relative_to(SKILL).as_posix(): sha(path.read_bytes()) for path in SKILL.rglob('*') if path.is_file()}
json_write('rest079_assets_freeze.json', {'published_skills': PUBLISHED, 'skill_root': str(SKILL),
                                        'assets': assets, 'source_commit': SDK_COMMIT,
                                        'source_modules': {case['source']['module']: case['source']['sha256'] for case in cases}})
feature = ['Feature: Frozen REST079 Ontology schema and interface contracts',
           '  # Author candidate only. Independent review and separate formal execution required.']
for case in cases:
    feature += ['', '  Scenario: ' + case['case_id'] + ' ' + case['operation'],
                '    Given ' + case['given'], '    When ' + case['when'], '    Then ' + case['then'],
                '    And request path is ' + case['wire']['path'],
                '    And source declares zero named throwable errors']
(HERE / 'rest079_formal_cases.feature').write_text('\n'.join(feature) + '\n', encoding='utf-8')
print(json.dumps({'cases': len(cases), 'frozen_reader_assets': len(assets), 'formal_execution': False}))
