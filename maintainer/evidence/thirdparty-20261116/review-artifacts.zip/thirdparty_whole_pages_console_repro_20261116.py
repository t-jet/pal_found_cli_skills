"""Run the frozen console entry with fake native SDK transport and no network."""
import asyncio
import json
import os
from pathlib import Path
import socket
import sys
from unittest.mock import patch

OUT = Path(__file__).resolve().parent / 'thirdparty_whole_pages_review_20261116'
sys.path.insert(0, str(OUT / 'prepared_cli'))
import httpx
from pal_found_cli.third_party_applications.scripts import pal_found_third_party_applications_cli as cli

def deny(*a, **k):
    raise AssertionError('Native network and DNS denied')

original_connect = socket.socket.connect
def connect(sock, address):
    if isinstance(address, tuple) and address[0] in ('127.0.0.1','::1'):
        return original_connect(sock, address)
    return deny(sock,address)

socket.socket.connect = connect
socket.create_connection = deny
socket.getaddrinfo = deny
httpx.AsyncHTTPTransport.handle_async_request = deny
httpx.HTTPTransport.handle_request = deny

def handler(request):
    print(json.dumps({'unexpected_http':str(request.url)}), file=sys.stderr)
    return httpx.Response(404,json={'errorCode':'NOT_FOUND','errorName':'QaNotFound','errorInstanceId':'00000000-0000-0000-0000-000000000001','parameters':{}})

env={'FOUNDRY_AGENTIC_CLI_ENV_FILE':str(OUT/'empty.env'),'FOUNDRY_TOKEN':'offline-qa-fake','FOUNDRY_HOSTNAME':'https://qa.invalid','FOUNDRY_AGENTIC_CLI_READONLY':'false','FOUNDRY_AGENTIC_CLI_DEFAULT_FORMAT':'json'}
client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
with patch.dict(os.environ,env,clear=True),patch('foundry_sdk._core.api_client.AsyncHttpClient',return_value=client):
    sys.argv=['pal-found-third-party-applications',*sys.argv[1:]]
    raise SystemExit(cli.console_main())
