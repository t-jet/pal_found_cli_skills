"""Add structural and independent source-contract detail to raw QA evidence."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'thirdparty_whole_pages_review_20261116'
raw=json.loads((OUT/'raw_proof.json').read_text())
SOURCE=ROOT.parent/'docs/customer_input/foundry-platform-python'
oracles=[]
for filename in ['third_party_application.py','website.py','version.py']:
    data=subprocess.check_output(['git','-C',str(SOURCE),'show','1.101.0:foundry_sdk/v2/third_party_applications/'+filename],text=True)
    tree=ast.parse(data)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name.startswith('Async'))
    for fn in cls.body:
        if not isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)) or fn.name.startswith('_'):
            continue
        info=next((n for n in ast.walk(fn) if isinstance(n,ast.Call) and ast.unparse(n.func)=='core.RequestInfo'),None)
        if info:
            fields={k.arg:ast.unparse(k.value) for k in info.keywords}
            oracles.append({'operation':filename[:-3]+'.'+fn.name,'source':filename,'line':fn.lineno,'public_class':cls.name,'signature':ast.unparse(fn.args),'request':fields,'source_sha256':hashlib.sha256(data.encode()).hexdigest()})

navigation=[]
for page in (OUT/'skill').rglob('*.md'):
    for label,target in re.findall(r'\[([^]]+)\]\(([^)]+)\)',page.read_text()):
        if target.startswith(('https:','http:')):
            navigation.append({'source':str(page.relative_to(OUT/'skill')),'target':target,'type':'optional_source_attribution'})
            continue
        path=target.split('#')[0]
        navigation.append({'source':str(page.relative_to(OUT/'skill')),'target':target,'exists':(page.parent/path).exists(),'inside_skill':(page.parent/path).resolve().is_relative_to((OUT/'skill').resolve())})

scenario_template='Scenario: {name}\n  Given frozen standalone skill and prepared SDK 1.101.0 with fake credential\n  And native network and DNS are denied\n  When documented CLI argv {argv} runs through actual parser, guard and SDK\n  Then exit is {exit}\n  And first HTTP request is {http}'
scenarios=[scenario_template.format(name=c['case'],argv=json.dumps(c['argv']),exit=c['expected_exit'],http=c['expected_http'] or 'absent') for c in raw['cases']]
report={
 'scope':'Provisional independent offline whole-page review, not formal TESTEXEC or release acceptance',
 'raw_proof':'raw_proof.json',
 'per_page':[dict(p,qa_verdict='FAIL',reason='Essential command setup omitted; eight documented operations fail in native SDK CLI route before HTTP.' if p['path']=='SKILL.md' else 'Eight of nine documented CLI examples fail before HTTP; APP_RID acquisition and actionable failure recovery missing.') for p in raw['pages']],
 'structural':{'all_leaves_at_most_300_lines':all(p['lines']<=300 for p in raw['pages']),'links':navigation,'entry_reaches_reference':True,'reference_backlink_to_entry':False,'declared_operation_headings':9,'unsupported_search_command':'None documented or implemented; version list is discovery route. No search operation invented.'},
 'source_oracles':oracles,
 'source_fidelity':{'pinned_tag_commit':raw['sdk_tag_commit'],'all_installed_namespace_sources_match_tag':all(v['installed_matches_frozen_tag'] for v in raw['sources'].values()),'source_checkout_head_warning':'Checkout HEAD differs from tag and models.py differs from frozen tag; installed101 and tag101 are the authoritative expectations.'},
 'defects':[
  {'id':'TPA-CLI-01','severity':'blocking','owner':'FEATURE-012 CLI corrector requested from coordinator','cause':'OP_SPECS client paths omit ThirdPartyApplication parent for Website and Version.','affected':['website.deploy','website.get','website.undeploy','version.delete','version.get','version.list','version.upload','version.upload_snapshot'],'actual':'Exit 6 with AttributeError before any HTTP request','expected':'Resolve root.third_party_applications.ThirdPartyApplication.Website and nested .Version; issue pinned SDK HTTP contracts.','proof':'raw_proof.json cases example.* and independent SDK reference probes','remedy':'Correct CLI SDK client paths and rerun actual native SDK examples plus paging; do not replace CLI with REST examples.'},
  {'id':'TPA-DOC-01','severity':'blocking','owner':'DEV-STORY-061 guidance corrector requested','pages':['SKILL.md','references/01-applications.md'],'missing':['Explicit FOUNDRY_HOSTNAME and FOUNDRY_TOKEN setup and configuration precedence','Prepared command/runtime versus authorized enrollment prerequisites','How to obtain and verify existing Developer Console application RID before setting APP_RID','CLI UserTokenAuth bearer-token identity and boundaries for service-account/non-interactive usage; no built-in OAuth grant flow','Local policy flags needed to understand and resolve exit8 with authorized policy approval','Actionable 401/403/404 and token/policy/invalid-input recovery; deleting then verifying missing version','Read-only local archive preparation versus online upload/deploy/sharing and administrator boundaries'],'observed_source_only_facts':['CLI factory uses UserTokenAuth(FOUNDRY_TOKEN) with FOUNDRY_HOSTNAME','Missing credentials currently exit9, 401 exit2, 403 exit3, 404 exit4, local write block exit8','Frozen SDK declares operation permission error classes but no universal OAuth scope or IAM role grants'],'remedy':'Add self-contained setup and recovery without inventing exact scopes; retain source-silence boundaries and local navigation.'}
 ],
 'case_counts':{'actual_cli':len(raw['cases']),'pass':sum(c['pass'] for c in raw['cases']),'fail':sum(not c['pass'] for c in raw['cases']),'independent_native_sdk_reference':len(raw['sdk_reference']),'native_sdk_reference_pass':sum(c['pass'] for c in raw['sdk_reference'])},
 'gherkin':scenarios,
 'unresolved':[{'area':'CLI pagination and recovery','verdict':'FAIL','detail':'First page, resume, bounded pages, --all, and invalid page-size requests all exit6 before transport due to TPA-CLI-01. Their semantics remain unaccepted until CLI fix retest.'},{'area':'Hosting UI/login/client-facing/sharing and asset-scan statements','verdict':'UNCERTAIN','detail':'Frozen SDK proves static upload/snapshot/deploy models but does not document all hosting UI details; public attribution is optional source, and no live tenant behavior was tested. Existing authored review cannot substitute for independent supplied-source proof.'}],
 'boundaries':'No source pages or CLI edited. No live writes, tracker writes, ledger promotion or release acceptance. Only own temporary QA artifacts created.'
}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':str(OUT/'review.json'),'pages':[(p['path'],p['qa_verdict']) for p in report['per_page']],'oracles':len(oracles),'counts':report['case_counts']},indent=2))
