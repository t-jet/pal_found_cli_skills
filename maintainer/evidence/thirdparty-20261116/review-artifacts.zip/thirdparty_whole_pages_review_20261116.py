"""Independent whole-page probes using the shipped CLI and native SDK transport."""
import ast
import asyncio
import contextlib
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import traceback
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'thirdparty_whole_pages_review_20261116'
OUT.mkdir(exist_ok=True)
INTEGRATION = ROOT / 'feature015_integration'
CLI = ROOT / 'feature015_shared_cli_fixes'
SKILL = 'pal-found-third-party-applications'
SOURCE = ROOT.parent / 'docs/customer_input/foundry-platform-python'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
git = lambda root, *args: subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()
audit = json.loads((INTEGRATION / 'maintainer/offline-knowledge-audit.json').read_text())
rows = [r for r in audit['files'] if r['path'].startswith(SKILL + '\\')]
shutil.copytree(INTEGRATION / '.agents/skills' / SKILL, OUT / 'skill', dirs_exist_ok=True)
shutil.copytree(CLI / 'src/pal_found_cli', OUT / 'prepared_cli/pal_found_cli', dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__'))
sys.path.insert(0, str(OUT / 'prepared_cli'))
with zipfile.ZipFile(OUT / 'website.zip', 'w') as z:
    z.writestr('index.html', '<html><body>offline QA</body></html>')
(OUT / 'empty.env').write_text('')
os.chdir(OUT)

import httpx
import foundry_sdk
from foundry_sdk import AsyncFoundryClient, UserTokenAuth
from foundry_sdk._core.config import Config
from pal_found_cli.third_party_applications.scripts import pal_found_third_party_applications_cli as cli

RID = 'ri.third-party-applications.main.application.00000000-0000-0000-0000-000000000001'
BASE = '/api/v2/thirdPartyApplications/' + RID
VBASE = BASE + '/website/versions'
CASES = [
 ('third_party_application.get', ['third-party-application','get',RID], 'GET',BASE, {'rid':RID}),
 ('website.deploy',['website','deploy',RID,'--version','1.2.0'],'POST',BASE+'/website/deploy',{'deployedVersion':'1.2.0','subdomains':['qa']}),
 ('website.get',['website','get',RID],'GET',BASE+'/website',{'deployedVersion':'1.2.0','subdomains':['qa']}),
 ('website.undeploy',['website','undeploy',RID],'POST',BASE+'/website/undeploy',{'subdomains':['qa']}),
 ('version.delete',['version','delete',RID,'1.2.0'],'DELETE',VBASE+'/1.2.0',None),
 ('version.get',['version','get',RID,'1.2.0'],'GET',VBASE+'/1.2.0',{'version':'1.2.0'}),
 ('version.list',['version','list',RID,'--page-size','50'],'GET',VBASE,{'data':[{'version':'1.2.0'}],'nextPageToken':'qa-next'}),
 ('version.upload',['version','upload',RID,'--version','1.2.0','--file','./website.zip'],'POST',VBASE+'/upload',{'version':'1.2.0'}),
 ('version.upload_snapshot',['version','upload-snapshot',RID,'--version','1.2.0-snapshot.1','--file','./website.zip','--snapshot-identifier','review-42'],'POST',VBASE+'/uploadSnapshot',{'version':'1.2.0-snapshot.1'}),
]

def forbidden(*a, **k):
    raise AssertionError('Native network/DNS forbidden in offline QA')
original_connect = socket.socket.connect
def connect(sock, address):
    if isinstance(address, tuple) and address[0] in ('127.0.0.1','::1'):
        return original_connect(sock, address)
    return forbidden(sock, address)
socket.socket.connect = connect
socket.create_connection = forbidden
socket.getaddrinfo = forbidden
httpx.AsyncHTTPTransport.handle_async_request = forbidden
httpx.HTTPTransport.handle_request = forbidden

ENV = {
 'FOUNDRY_AGENTIC_CLI_ENV_FILE':str(OUT / 'empty.env'),
 'FOUNDRY_HOSTNAME':'https://qa.invalid', 'FOUNDRY_TOKEN':'offline-qa-fake',
 'FOUNDRY_AGENTIC_CLI_READONLY':'false', 'FOUNDRY_AGENTIC_CLI_DEFAULT_FORMAT':'json',
 'FOUNDRY_AGENTIC_CLI_LOG_LEVEL':'CRITICAL',
}

async def run_case(name, argv, expected_exit=0, expected_http=None, response=None, status=200, env_changes=None):
    requests=[]
    failures=[]
    def handler(request):
        requests.append({'method':request.method,'url':str(request.url),'path':request.url.path,
                         'query':dict(request.url.params),'body':request.content.decode(errors='replace'),
                         'content_type':request.headers.get('content-type'),
                         'auth_fake_present':request.headers.get('authorization') == 'Bearer offline-qa-fake'})
        data = response(request,len(requests)) if callable(response) else response
        return httpx.Response(status,json=data) if data is not None else httpx.Response(204)
    def serialize(exc):
        failures.append({'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
        return original_serialize(exc)
    original_serialize = cli._serialize_error
    env = dict(ENV)
    env.update(env_changes or {})
    for k in list(env):
        if env[k] is None:
            del env[k]
    stdout,stderr=io.StringIO(),io.StringIO()
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as transport:
        with patch.dict(os.environ,env,clear=True), patch.object(sys,'argv',['pal-found-third-party-applications',*argv]), patch('foundry_sdk._core.api_client.AsyncHttpClient',return_value=transport), patch.object(cli,'_serialize_error',serialize), contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
            exit_code=await cli.main()
    passed=exit_code==expected_exit
    if expected_http:
        passed=passed and bool(requests) and (requests[0]['method'],requests[0]['path']) == expected_http
    return {'case':name,'argv':['pal-found-third-party-applications',*argv], 'expected_exit':expected_exit,'actual_exit':exit_code,
            'expected_http':expected_http,'http':requests,'stdout':stdout.getvalue(),'stderr':stderr.getvalue(),'exceptions':failures,'pass':passed}

async def direct_sdk_reference():
    results=[]
    for name,argv,method,path,response in CASES:
        requests=[]
        def handler(request):
            requests.append({'method':request.method,'url':str(request.url),'body':request.content.decode(errors='replace')})
            return httpx.Response(200,json=response) if response is not None else httpx.Response(204)
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as transport:
            with patch('foundry_sdk._core.api_client.AsyncHttpClient',return_value=transport):
                root=AsyncFoundryClient(auth=UserTokenAuth('offline-qa-fake'),hostname='https://qa.invalid',config=Config(max_retries=0),preview=True)
                app=root.third_party_applications.ThirdPartyApplication
                resource,op=name.split('.')
                client=app if resource=='third_party_application' else app.Website if resource=='website' else app.Website.Version
                args=[RID]
                kwargs={}
                if op in ('get','delete') and resource=='version': args.append('1.2.0')
                if op in ('deploy','upload','upload_snapshot'): kwargs['version']='1.2.0'
                if op in ('upload','upload_snapshot'): args.append((OUT/'website.zip').read_bytes())
                if op=='upload_snapshot': kwargs['snapshot_identifier']='review-42'
                if op=='list':
                    result=await client.with_raw_response.list(*args,page_size=50)
                    value=result.decode().to_dict()
                else: value=await getattr(client,op)(*args,**kwargs)
                if hasattr(value,'to_dict'): value=value.to_dict()
        results.append({'operation':name,'route':'root.third_party_applications.ThirdPartyApplication'+('' if resource=='third_party_application' else '.Website'+('.Version' if resource=='version' else '')),
                        'http':requests,'result':value,'pass':len(requests)==1 and requests[0]['method']==method and httpx.URL(requests[0]['url']).path==path,
                        'scope':'Independent SDK contract reference only; does not substitute for CLI execution.'})
    return results

async def main():
    outcomes=[]
    for name,argv,method,path,response in CASES:
        outcomes.append(await run_case('example.'+name,argv,expected_http=(method,path),response=response))
    errors={401:2,403:3,404:4}
    for status,exit_code in errors.items():
        error={'errorCode':{401:'UNAUTHORIZED',403:'PERMISSION_DENIED',404:'NOT_FOUND'}[status], 'errorName':'QaError','errorInstanceId':'00000000-0000-0000-0000-000000000001','parameters':{}}
        outcomes.append(await run_case('http.'+str(status),CASES[0][1],exit_code,('GET',BASE),error,status))
    outcomes.append(await run_case('missing_credentials',CASES[0][1],9,env_changes={'FOUNDRY_TOKEN':None}))
    outcomes.append(await run_case('guard.readonly.deploy',CASES[1][1],8,env_changes={'FOUNDRY_AGENTIC_CLI_READONLY':'true'}))
    outcomes.append(await run_case('guard.readonly.upload_before_file', ['version','upload',RID,'--version','1.2.0','--file','./absent.zip'],8,env_changes={'FOUNDRY_AGENTIC_CLI_READONLY':'true'}))
    outcomes.append(await run_case('missing_file',['version','upload',RID,'--version','1.2.0','--file','./absent.zip'],1))
    with (OUT/'oversized.zip').open('wb') as f: f.truncate(16*1024*1024+1)
    outcomes.append(await run_case('oversized_file',['version','upload',RID,'--version','1.2.0','--file','./oversized.zip'],1))
    for name,argv in [('missing_version',['website','deploy',RID]),('bad_timeout',['third-party-application','get',RID,'--timeout','0']),('bad_format',['third-party-application','get',RID,'--format','xml']),('empty_rid',['third-party-application','get',''])]:
        outcomes.append(await run_case('invalid.'+name,argv,1))
    paged=lambda r,n: {'data':[{'version':'1.2.'+str(n)}],**({'nextPageToken':'qa-'+str(n)} if n<3 else {})}
    for label,flags in [('first',['--page-size','50']),('resume',['--page-token','qa-1']),('two_pages',['--max-pages','2']),('all',['--all','--max-pages','1']),('zero_page_size',['--page-size','0'])]:
        outcomes.append(await run_case('paging.'+label,['version','list',RID,*flags],1 if label=='zero_page_size' else 0,('GET',VBASE),paged))
    sources={}
    sdk_dir=Path(foundry_sdk.__file__).parent/'v2/third_party_applications'
    for filename in ['_client.py','third_party_application.py','website.py','version.py','models.py','errors.py']:
        current=SOURCE/'foundry_sdk/v2/third_party_applications'/filename
        pinned=subprocess.check_output(['git','-C',str(SOURCE),'show','1.101.0:foundry_sdk/v2/third_party_applications/'+filename])
        sources[filename]={'installed_sha256':sha(sdk_dir/filename),'checkout_sha256':sha(current),'tag_1_101_0_sha256':hashlib.sha256(pinned).hexdigest(),'installed_matches_frozen_tag':(sdk_dir/filename).read_bytes().replace(b'\r\n',b'\n')==pinned.replace(b'\r\n',b'\n')}
    pages=[]
    for row in rows:
        rel=Path(row['path'].replace('\\','/')).relative_to(SKILL)
        src=INTEGRATION/'.agents/skills'/SKILL/rel
        frozen=OUT/'skill'/rel
        pages.append({'path':str(rel),'audit_sha256':row['sha256'],'before_sha256':sha(frozen),'after_sha256':sha(src),'unchanged':sha(frozen)==sha(src),'lines':len(frozen.read_text().splitlines()),'headings':[l for l in frozen.read_text().splitlines() if l.startswith('#')]})
    result={'reviewer':'/root/thirdparty_whole_pages_review_20261116','integration_commit':git(INTEGRATION,'rev-parse','HEAD'),'cli_commit':git(CLI,'rev-parse','HEAD'),'cli_tree':git(CLI,'rev-parse','HEAD^{tree}'),'cli_sha256':sha(OUT/'prepared_cli/pal_found_cli/third_party_applications/scripts/pal_found_third_party_applications_cli.py'), 'sdk_version':importlib.metadata.version('foundry-platform-sdk'),'sdk_tag_commit':git(SOURCE,'rev-parse','1.101.0^{}'),'sources':sources,'pages':pages,'cases':outcomes,'sdk_reference':await direct_sdk_reference(),'network':'Native HTTP transports and DNS denied; only httpx.MockTransport allowed. No live calls.','boundaries':'No tracker writes, source corrections, audit promotion, or release acceptance.'}
    (OUT/'raw_proof.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'cases':len(outcomes),'pass':sum(x['pass'] for x in outcomes),'failures':[{'case':x['case'],'exit':x['actual_exit'],'error':x['exceptions']} for x in outcomes if not x['pass']], 'output':str(OUT/'raw_proof.json')},indent=2))

asyncio.run(main())
