"""Run independent process proofs for both SDK environments."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'feature015_thirdparty_independent_retest_20261116'
SCRIPT=ROOT/'feature015_thirdparty_independent_retest_20261116.py'
RUNTIME=ROOT/'bug048_runtimefix_20261116'
envs={'1.101.0':ROOT/'feature015_shared_cli_qa_env/Scripts','1.111.0':ROOT/'feature015_functions_sdk111_env/Scripts'}
proof=[]
for version,scripts in envs.items():
    env=os.environ.copy()
    env['PATH']=str(scripts)+os.pathsep+env['PATH']
    env['PYTHONPATH']=str(RUNTIME/'src')
    for i in range(9):
        cmd=[str(scripts/'python.exe'),str(SCRIPT),'--console',str(i)]
        p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=30)
        detail=json.loads((OUT/('console_'+version+'_'+str(i)+'.json')).read_text())
        raw=json.loads((OUT/('raw_'+version+'.json')).read_text())
        expected=raw['cases'][i]
        request=detail['requests'][0]
        contract=expected['requests'][0]
        proof.append({'command':cmd,'sdk':version,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'detail':detail,'pass':p.returncode==0 and len(detail['requests'])==1 and json.loads(p.stdout)==json.loads(expected['stdout']) and all(request[k]==contract[k] for k in ['method','path','query','body_sha256','bearer_correct'])})
    launcher=envs['1.101.0']/'pal-found-third-party-applications.exe'
    cmd=[str(launcher),'--help']
    p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=30)
    proof.append({'command':cmd,'sdk_environment':version,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'scope':'Prepared Windows launcher help only. SDK111 launcher embeds SDK101 interpreter; SDK111 runtime proof uses its explicit python.exe and native console_main above.','pass':p.returncode==0 and 'third-party-application' in p.stdout})
result={'cases':proof,'pass':all(r['pass'] for r in proof)}
(OUT/'process_proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass'],'cases':len(proof),'failures':[r['command'] for r in proof if not r['pass']]}))
