"""Assemble source-bound independent findings without changing candidates."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'feature015_thirdparty_independent_retest_20261116'
RUNTIME=ROOT/'bug048_runtimefix_20261116'
GUIDANCE=ROOT/'feature015_thirdparty_guidance_fixes'
SOURCE=GUIDANCE/'.agents/skills/pal-found-third-party-applications'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda p,*args:subprocess.check_output(['git','-C',str(p),*args],text=True).strip()
raw=[json.loads((OUT/('raw_'+v+'.json')).read_text()) for v in ('1.101.0','1.111.0')]
process=json.loads((OUT/'process_proof.json').read_text())
pages=[]
for rel,previous in [('SKILL.md','413f638aaeba2fd184bbe7f119a94625fbb130b8f3c2a610e0dd265cc445077a'),('references/01-applications.md','c84560dc2058d0e31740b18ea30c962072b2021428adcebe4ace2c2deaf0b7cd')]:
    p=SOURCE/rel
    frozen=OUT/'final_guidance'/rel
    text=frozen.read_text()
    links=[]
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if '://' not in target:
            targetpath=(frozen.parent/target.split('#')[0]).resolve()
            links.append({'target':target,'exists':targetpath.is_file(),'inside_copied_skill':targetpath.is_relative_to((OUT/'final_guidance').resolve())})
    assert p.read_bytes()==frozen.read_bytes()
    assert 'ConflictError' in text and 'may omit `http_status`' in text
    pages.append({'path':rel,'before_sha256':previous,'after_sha256':sha(p),'reviewed_copy_sha256':sha(frozen),'lines':len(text.splitlines()),'local_links':links,'previous_verdict':'FAIL','previous_finding':'Conflict recovery directed reader to inspect http_status, which native ConflictError does not provide.','verdict':'PASS','standalone_decisions':[
      'Use prepared executable, Python and SDK. Help is local; tenant operations need authorized enrollment. Offline fixtures cannot establish hosting or visitor access.',
      'Obtain enrollment hostname and approved bearer token externally. UserTokenAuth has no client credentials grant, interactive login or refresh flow. Ask administrator for identity/grants where source is silent.',
      'Explicit environment file wins file search; existing process values win file values. Missing explicit file fails. Obtain owner-supplied application RID and verify application get before writes.',
      'Build supplied production frontend, exclude secrets, put index.html at archive root, use file <=16MiB. CLI checks size/existence, not ZIP validity. SDK/server can reject archive or semantic version.',
      'Distinguish local ENABLED/READONLY/METADATA_ONLY from tenant permissions. Inspect blocked rule with policy owner. Override cannot bypass disabled controls.',
      'Interpret 401/403/404 through identity, permission and target checks; conflict may be exit1/ConflictError with no http_status. Reconcile website/version state before writes or replay.',
      'Version list emits records to stdout and continuation metadata to stderr. Resume actual token, bound pages and inspect remaining token even with --all. Recover from last successful batch; incomplete batch proves no absence.',
      'Verify deploy/undeploy with website get, upload with version get, and delete with missing version plus application access check. Optional deployedVersion, subdomains, Version and null deletion retain meanings.',
      'Hosting/login/sharing/scan details remain tenant-specific and require owner/admin checks. Optional external attribution supplies no essential missing local step.'
    ]})
assert all(p['lines']<=300 and all(l['exists'] and l['inside_copied_skill'] for l in p['local_links']) for p in pages)
old=(OUT/'frozen_guidance/01-applications.md').read_text()
new=(OUT/'final_guidance/references/01-applications.md').read_text()
examples=lambda text:re.findall(r'\*\*Example:\*\* `([^`]+)`',text)
assert len(examples(new))==9 and examples(old)==examples(new)
ops=[]
decisions=[
 'Compare application RID with owner target before writes.',
 'Confirm uploaded label first; deploy selects production version; verify website get deployedVersion.',
 'Treat absent deployedVersion as no selected version. subdomains does not establish access.',
 'Verify no deployedVersion remains; uploaded versions remain independent.',
 'JSON null is successful empty API deletion response. Confirm version missing and application still accessible.',
 'Compare returned version label; no checksum or scan proof exists.',
 'Discover versions only for known application. Capture stderr cursor and continue until terminal token.',
 'Send exact ZIP bytes and version query; filename stays local. Verify label then deploy separately.',
 'Send exact bytes plus snapshotIdentifier; snapshot temporary two days; upload does not select production deployment.'
]
for i,example in enumerate(examples(new)):
    rows=[r['cases'][i] for r in raw]
    ops.append({'command':example,'decision':decisions[i],'verdict':'PASS','sdk_proofs':[{'sdk':r['sdk_version'],'case':r['cases'][i]['case'],'pass':r['cases'][i]['pass'],'requests':r['cases'][i]['requests'],'stdout':r['cases'][i]['stdout'],'stderr':r['cases'][i]['stderr']} for r in raw]})
module='src/pal_found_cli/third_party_applications/scripts/pal_found_third_party_applications_cli.py'
files=[module,'tests/test_third_party_applications_sdk_wire.py','tests/test_pal_found_third_party_applications_cli.py']
expected=['2b5396b614ed078774a54d55e16c62448049f1ddc2c5bb747bef2383b0d860ad','7e9da0500c9d11410cbfba888b618b41fc1fe84f00862e84d2bbddf7fe9bf919','037f185a0ae1125d11938bd242cfa7b5200a1c0a06b10d3c111051d3dba7efce']
bindings=[{'path':p,'expected_sha256':h,'actual_sha256':sha(RUNTIME/p)} for p,h in zip(files,expected)]
assert all(r['expected_sha256']==r['actual_sha256'] for r in bindings)
support=[]
for p in sorted((RUNTIME/'src/pal_found_cli/common').rglob('*.py')):
    rel=p.relative_to(RUNTIME).as_posix()
    original=subprocess.check_output(['git','-C',str(RUNTIME),'show','HEAD:'+rel])
    support.append({'path':rel,'current_sha256':sha(p),'head_sha256':hashlib.sha256(original).hexdigest(),'normalized_unchanged':p.read_bytes().replace(b'\r\n',b'\n')==original.replace(b'\r\n',b'\n')})
assert all(s['normalized_unchanged'] for s in support)
tree=ast.parse((RUNTIME/module).read_text())
base=ast.parse(subprocess.check_output(['git','-C',str(RUNTIME),'show','HEAD:'+module],text=True))
def specs(tree):
    return next(n.value for n in tree.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='OP_SPECS')
before=specs(base)
after=specs(tree)
changes=[]
for a,b in zip(before.elts,after.elts):
    if ast.dump(a)!=ast.dump(b):
        changes.append({'resource':ast.literal_eval(b.args[0]),'operation':ast.literal_eval(b.args[1]),'before_path':ast.literal_eval(a.args[2]),'after_path':ast.literal_eval(b.args[2])})
        a.args[2]=b.args[2]
assert len(changes)==8 and ast.dump(base)==ast.dump(tree)
prior=ROOT/'thirdparty_whole_pages_review_20261116'
priorhash={'review.json':'3cf8ffc912e2341aa3ff29d0f39470acfb968b3f2ec6e21eabcf8d50297f699f','raw_proof.json':'ce6553c3a1a9e1694467377dd4b6bb7debb5757b1cb097b236cd73ea51f71d5e','console_process.json':'a435303ffc23c3afa88860190c902de64ebc9c272a1703e91b9bed1f54c74bda'}
preserved=[{'path':str(prior/name),'expected_sha256':h,'actual_sha256':sha(prior/name),'unchanged':sha(prior/name)==h} for name,h in priorhash.items()]
assert all(r['unchanged'] for r in preserved)
report={'reviewer':'/root/thirdparty_independent_retest_20261116','bugs':['BUG-048','BUG-049'],'runtime_verdict':'PASS','guidance_verdict':'PASS','runtime_head':git(RUNTIME,'rev-parse','HEAD'),'guidance_head':git(GUIDANCE,'rev-parse','HEAD'),'runtime_bindings':bindings,'runtime_ast_review':{'only_changes':'Eight ThirdPartyApplication parent path insertions. Remaining module AST equals HEAD.','changes':changes},'pages':pages,'canonical_examples_preserved':len(ops),'operations':ops,'sdk_runs':[{'sdk':r['sdk_version'],'tag_commit':r['sdk_tag_commit'],'namespace_files':len(r['namespace_sources']),'all_namespace_sources_match_tag':all(s['normalized_match'] for s in r['namespace_sources']),'runtime_cases':len(r['cases']),'runtime_pass':r['pass'],'network_controls':r['network_controls']} for r in raw],'process_proof':{'path':str(OUT/'process_proof.json'),'cases':len(process['cases']),'pass':process['pass']},'prior_failure_evidence_preserved':preserved,'source_boundaries':[
 'Both SDK whole third_party_applications namespaces contain seven Python files including __init__, clients, models and errors; every file compared against its version tag with CRLF normalization. Exact per-file SHA256s retained in raw proof.',
 'Only native SDK _get_async_transport is replaced with MockTransport. Parser, ConfigLoader, AccessControlGuard, AsyncClientFactory, UserTokenAuth, SDK AsyncHttpClient/header construction, model decoding and retry/pagination remain native.',
 'Native socket/DNS and sync/async HTTP negative controls pass. Windows asyncio self-pipe loopback connect is explicitly exempt; public native transport cannot operate.',
 'Actual per-SDK Python subprocess invokes shipped console_main for all nine operations. Prepared Windows executable help uses SDK101 interpreter; SDK111 runtime proof uses its explicit Python environment.',
 'Synthetic deterministic ZIP passes zipfile CRC and contains root index.html. It proves byte fidelity only. It is not a validated production frontend or live archive acceptance.',
 'Native ConflictError carries exit1 and exception_type but no http_status. Corrected guide describes this and requires reconciliation. Shared serializer policy unchanged.',
 'Initial exploratory harness output retained separately. Corrections to expected timeout/rate-limit constants, terminal cursor omission and canonical tracing key reflect inspected source. Final transport seam preserves SDK header construction.',
 'Runtime CRLF files trigger plain git diff --check warnings; git -c core.whitespace=cr-at-eol diff --check passes without source edits.',
 'Existing console unit test mocks asyncio.run and leaves main coroutine unawaited; supplemental author test run passes with RuntimeWarning. Independent real process proof validates console behavior.'
 ],'limits':'Offline source/CLI/guidance acceptance only. No live Foundry deployment, visitor access, formal audit promotion, tracker transition, commit or push performed.'}
assert all(r['pass'] for r in raw) and process['pass']
reportpath=ROOT/'feature015_thirdparty_independent_retest_20261116.json'
report['runtime_common_source_bindings']=support
report['metadata_allowlist_sha256']=sha(RUNTIME/'src/pal_found_cli/third_party_applications/metadata-allow-list.md')
report['review_head']=git(ROOT.parent.parent,'rev-parse','HEAD')
reportpath.write_text(json.dumps(report,indent=2)+'\n')
manifest={'report':{'path':str(reportpath),'sha256':sha(reportpath)},'artifacts':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file() and 'pytest_' not in str(p) and p.name!='evidence_manifest.json'],'executables':[{'path':str(ROOT/name),'sha256':sha(ROOT/name)} for name in ['feature015_thirdparty_independent_retest_20261116.py','feature015_thirdparty_independent_process_20261116.py','feature015_thirdparty_independent_report_20261116.py']]}
(OUT/'evidence_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'runtime':'PASS','guidance':'PASS','pages':[{k:p[k] for k in ('path','after_sha256','lines','verdict')} for p in pages],'report':str(reportpath),'sha256':sha(reportpath)},indent=2))
