"""Independent BUG-048/049 probes. All generated evidence stays in .ept/tmp."""
import asyncio
import contextlib
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import traceback
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'feature015_thirdparty_independent_retest_20261116'
OUT.mkdir(exist_ok=True)
RUNTIME = ROOT / 'bug048_runtimefix_20261116'
GUIDANCE = ROOT / 'feature015_thirdparty_guidance_fixes'
SDK_SOURCE = ROOT.parent / 'docs/customer_input/foundry-platform-python'
sys.path.insert(0, str(RUNTIME / 'src'))
os.chdir(OUT)
import httpx
import foundry_sdk
from pal_found_cli.third_party_applications.scripts import pal_found_third_party_applications_cli as cli
from pal_found_cli.common import pagination_helper

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
git = lambda p, *a: subprocess.check_output(['git','-C',str(p),*a],text=True).strip()
SDK_VERSION = importlib.metadata.version('foundry-platform-sdk')
RID = 'ri.third-party-applications.main.application.00000000-0000-0000-0000-000000000001'
B = '/api/v2/thirdPartyApplications/' + RID
V = B + '/website/versions'
TOKEN = 'independent-offline-fake-token'
ZIP = OUT / 'website.zip'
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr(zipfile.ZipInfo('index.html',(2026,1,1,0,0,0)),'<!doctype html><title>offline fixture</title>')
    z.writestr(zipfile.ZipInfo('assets/data.bin',(2026,1,1,0,0,0)),bytes(range(256)))
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None and 'index.html' in z.namelist()
BINARY = ZIP.read_bytes()
(OUT/'empty.env').write_text('')
with (OUT/'oversized.zip').open('wb') as f:
    f.truncate(16777217)
ENV = {
 'FOUNDRY_HOSTNAME':'https://qa.invalid','FOUNDRY_TOKEN':TOKEN,
 'FOUNDRY_AGENTIC_CLI_ENV_FILE':str(OUT/'empty.env'),
 'FOUNDRY_AGENTIC_CLI_READONLY':'false','FOUNDRY_AGENTIC_CLI_DEFAULT_FORMAT':'json',
 'FOUNDRY_AGENTIC_CLI_LOG_LEVEL':'CRITICAL',
 'FOUNDRY_AGENTIC_CLI_RETRY_MAX_ATTEMPTS':'2',
 'FOUNDRY_AGENTIC_CLI_RETRY_INITIAL_DELAY_MS':'0',
 'FOUNDRY_AGENTIC_CLI_RETRY_JITTER':'false',
}
DENIALS=[]
def denied(*args, **kwargs):
    DENIALS.append('native network denied')
    raise AssertionError('Independent QA forbids native network')
original_connect=socket.socket.connect
def guarded_connect(sock,address):
    if isinstance(address,tuple) and address[0] in ('127.0.0.1','::1'):
        return original_connect(sock,address)
    return denied(sock,address)
socket.socket.connect=guarded_connect
socket.socket.connect_ex=denied
socket.create_connection=denied
socket.getaddrinfo=denied
httpx.HTTPTransport.handle_request=denied
httpx.AsyncHTTPTransport.handle_async_request=denied

# Expectations written from frozen SDK operation contracts, independent of author tests.
CASES=[
 ('application.get',['third-party-application','get',RID],'GET',B,{},None,{'rid':RID},{'rid':RID}),
 ('website.deploy',['website','deploy',RID,'--version','1.2.0'],'POST',B+'/website/deploy',{}, {'version':'1.2.0'},{'deployedVersion':'1.2.0','subdomains':['qa']},{'deployedVersion':'1.2.0','subdomains':['qa']}),
 ('website.get',['website','get',RID],'GET',B+'/website',{},None,{'subdomains':[]},{'subdomains':[]}),
 ('website.undeploy',['website','undeploy',RID],'POST',B+'/website/undeploy',{},None,{'subdomains':[]},{'subdomains':[]}),
 ('version.delete',['version','delete',RID,'1.2.0'],'DELETE',V+'/1.2.0',{},None,None,None),
 ('version.get',['version','get',RID,'1.2.0'],'GET',V+'/1.2.0',{},None,{'version':'1.2.0'},{'version':'1.2.0'}),
 ('version.list',['version','list',RID,'--page-size','50'],'GET',V,{'pageSize':'50'},None,{'data':[{'version':'1.2.0'}],'nextPageToken':'cursor-A'},[{'version':'1.2.0'}]),
 ('version.upload',['version','upload',RID,'--version','1.2.0','--file',str(ZIP)],'POST',V+'/upload',{'version':'1.2.0'},'binary',{'version':'1.2.0'},{'version':'1.2.0'}),
 ('version.upload-snapshot',['version','upload-snapshot',RID,'--version','1.2.0-snapshot.1','--file',str(ZIP),'--snapshot-identifier','review-42'],'POST',V+'/uploadSnapshot',{'version':'1.2.0-snapshot.1','snapshotIdentifier':'review-42'},'binary',{'version':'1.2.0-snapshot.1'},{'version':'1.2.0-snapshot.1'}),
]

async def run(name,argv,reply,exit=0,count=1,check=None,env=None,timeout_check=None):
    requests=[]
    async def handler(req):
        requests.append({'method':req.method,'host':req.url.host,'path':req.url.path,'query':dict(req.url.params),
          'body_sha256':hashlib.sha256(req.content).hexdigest(),'body_length':len(req.content),
          'body_json':json.loads(req.content) if req.content and req.headers.get('content-type')=='application/json' else None,
          'content_type':req.headers.get('content-type'),'bearer_correct':req.headers.get('authorization')=='Bearer '+TOKEN,
          'trace_headers':{k:v for k,v in req.headers.items() if k.startswith('x-b3')},'timeout':req.extensions.get('timeout'),
          'attribution_present':any('attribution' in k for k in req.headers)})
        res=reply(req,len(requests)) if callable(reply) else reply
        if isinstance(res,BaseException): raise res
        if isinstance(res,tuple): status,data=res
        else: status,data=200,res
        return httpx.Response(status,json=data) if data is not None else httpx.Response(204)
    effective=dict(ENV)
    effective.update(env or {})
    effective={k:v for k,v in effective.items() if v is not None}
    stdout,stderr=io.StringIO(),io.StringIO()
    failures=[]
    original=cli._serialize_error
    def record(exc):
        failures.append({'type':type(exc).__name__,'traceback':traceback.format_exc()})
        return original(exc)
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        with patch.dict(os.environ,effective,clear=True),patch.object(sys,'argv',['pal-found-third-party-applications',*argv]),patch('foundry_sdk._core.http_client._get_async_transport',return_value=httpx.MockTransport(handler)),patch.object(cli,'_serialize_error',record),contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
            actual=await cli.main()
    row={'case':name,'argv':argv,'expected_exit':exit,'actual_exit':actual,'expected_requests':count,'requests':requests,'stdout':stdout.getvalue(),'stderr':stderr.getvalue(),'exceptions':failures}
    problems=[]
    if actual!=exit: problems.append('exit mismatch')
    if len(requests)!=count: problems.append('request count mismatch')
    if TOKEN in stdout.getvalue()+stderr.getvalue(): problems.append('credential leaked')
    if requests and not all(r['bearer_correct'] for r in requests): problems.append('bearer mismatch')
    if timeout_check and any(set(r['timeout'].values())!={timeout_check} for r in requests): problems.append('timeout mismatch')
    if check:
        try: check(row)
        except Exception: problems.append(traceback.format_exc())
    row['problems']=problems
    row['pass']=not problems
    return row

def assert_value(condition,message):
    assert condition,message
def pagination(row,versions,token,queries):
    assert json.loads(row['stdout'])==[{'version':x} for x in versions]
    lines=row['stderr'].splitlines()
    metadata=[json.loads(line) for line in lines if line.startswith('{') and 'pages_fetched' in line]
    assert len(metadata)==1,(lines,metadata)
    assert metadata[0].get('next_page_token')==token,metadata
    assert [r['query'] for r in row['requests']]==queries
    assert 'next_page_token' not in row['stdout']

async def main():
    controls=[]
    for name,fn in [('dns',lambda:socket.getaddrinfo('qa.invalid',443)),('connect',lambda:socket.socket().connect(('192.0.2.1',443))),('sync_http',lambda:httpx.get('https://qa.invalid'))]:
        try: fn(); controls.append({'case':name,'pass':False})
        except AssertionError: controls.append({'case':name,'pass':True})
    try:
        async with httpx.AsyncClient() as native: await native.get('https://qa.invalid')
        controls.append({'case':'async_http','pass':False})
    except AssertionError: controls.append({'case':'async_http','pass':True})
    outcomes=[]
    for name,argv,method,path,query,body,response,result in CASES:
        def check(row,method=method,path=path,query=query,body=body,result=result):
            req=row['requests'][0]
            assert (req['method'],req['path'],req['query'])==(method,path,query),req
            assert json.loads(row['stdout'])==result,row['stdout']
            if body=='binary':
                assert req['body_sha256']==sha(ZIP) and req['body_length']==len(BINARY)
                assert req['content_type']=='application/octet-stream'
            elif body: assert req['body_json']==body
            else: assert req['body_length']==0
            assert not req['attribution_present']
        outcomes.append(await run('example.'+name,argv,response,check=check))
    get=CASES[0][1]
    for status,expected in [(401,2),(403,3),(404,4),(409,1),(429,7),(503,6)]:
        err={'errorCode':{401:'UNAUTHORIZED',403:'PERMISSION_DENIED',404:'NOT_FOUND',409:'CONFLICT',429:'TOO_MANY_REQUESTS',503:'INTERNAL'}[status],'errorName':'IndependentQaError','errorInstanceId':'00000000-0000-0000-0000-000000000001','parameters':{}}
        outcomes.append(await run('http.'+str(status),get,(status,err),exit=expected,count=2 if status in (429,503) else 1,check=lambda r,s=status:assert_value(json.loads(r['stdout']).get('http_status')==(None if s==409 else s),'http_status')))
    for name,argv,expected,changes in [
      ('missing_token',get,9,{'FOUNDRY_TOKEN':None}),('missing_host',get,9,{'FOUNDRY_HOSTNAME':None}),
      ('readonly_before_file',['version','upload',RID,'--version','1.2.0','--file','absent.zip'],8,{'FOUNDRY_AGENTIC_CLI_READONLY':'true'}),
      ('disabled',get,8,{'FOUNDRY_AGENTIC_CLI_ENABLED':'false'}),
      ('disabled_even_override',CASES[1][1],8,{'FOUNDRY_AGENTIC_CLI_ENABLED':'false','FOUNDRY_AGENTIC_CLI_THIRD_PARTY_APPLICATIONS_WEBSITE_DEPLOY_READONLY':'false'}),
      ('missing_file',['version','upload',RID,'--version','1.2.0','--file','absent.zip'],1,{}),
      ('oversized_file',['version','upload',RID,'--version','1.2.0','--file',str(OUT/'oversized.zip')],1,{}),
      ('missing_version',['website','deploy',RID],1,{}),('empty_rid',['website','get',''],1,{}),
      ('timeout_zero',get+['--timeout','0'],1,{}),('bad_format',get+['--format','xml'],1,{}),
      ('page_size_zero',['version','list',RID,'--page-size','0'],1,{}),
      ('max_pages_negative',['version','list',RID,'--max-pages','-1'],1,{})]:
        outcomes.append(await run('negative.'+name,argv,None,exit=expected,count=0,env=changes))
    outcomes.append(await run('guard.approved_override',CASES[1][1],CASES[1][6],env={'FOUNDRY_AGENTIC_CLI_READONLY':'true','FOUNDRY_AGENTIC_CLI_THIRD_PARTY_APPLICATIONS_WEBSITE_DEPLOY_READONLY':'false'}))
    for i in (1,3,4,7,8):
        outcomes.append(await run('guard.readonly.'+CASES[i][0],CASES[i][1],None,exit=8,count=0,env={'FOUNDRY_AGENTIC_CLI_READONLY':'true'}))
    outcomes.append(await run('guard.namespace_disabled',get,None,exit=8,count=0,env={'FOUNDRY_AGENTIC_CLI_THIRD_PARTY_APPLICATIONS_ENABLED':'false'}))
    outcomes.append(await run('guard.operation_disabled',get,None,exit=8,count=0,env={'FOUNDRY_AGENTIC_CLI_THIRD_PARTY_APPLICATIONS_THIRD_PARTY_APPLICATION_GET_ENABLED':'false'}))
    (OUT/'precedence.env').write_text('FOUNDRY_HOSTNAME=https://wrong.invalid\nFOUNDRY_TOKEN=wrong-offline-token\n')
    outcomes.append(await run('config.process_over_file',get,{'rid':RID},env={'FOUNDRY_AGENTIC_CLI_ENV_FILE':str(OUT/'precedence.env')},check=lambda row:assert_value(row['requests'][0]['host']=='qa.invalid','process hostname did not win')))
    (OUT/'file_only.env').write_text('FOUNDRY_HOSTNAME=https://qa.invalid\nFOUNDRY_TOKEN='+TOKEN+'\n')
    outcomes.append(await run('config.file_credentials',get,{'rid':RID},env={'FOUNDRY_AGENTIC_CLI_ENV_FILE':str(OUT/'file_only.env'),'FOUNDRY_HOSTNAME':None,'FOUNDRY_TOKEN':None}))
    outcomes.append(await run('config.explicit_missing',get,None,exit=9,count=0,env={'FOUNDRY_AGENTIC_CLI_ENV_FILE':str(OUT/'missing.env')}))
    outcomes.append(await run('timeout.configured',get,{'rid':RID},env={'FOUNDRY_AGENTIC_CLI_TIMEOUT_S':'19'},timeout_check=19))
    outcomes.append(await run('timeout.flag_precedence',get+['--timeout','7'],{'rid':RID},env={'FOUNDRY_AGENTIC_CLI_TIMEOUT_S':'19'},timeout_check=7))
    outcomes.append(await run('timeout.retry_bounds',get,lambda r,n:httpx.ReadTimeout('synthetic timeout'),exit=5,count=2))
    outcomes.append(await run('tracing.native',get,{'rid':RID},env={'FOUNDRY_AGENTIC_CLI_ENABLE_TRACING':'true'},check=lambda row:assert_value(all(re.fullmatch('[0-9a-f]{32}',r['trace_headers'].get('x-b3-traceid','')) and re.fullmatch('[0-9a-f]{16}',r['trace_headers'].get('x-b3-spanid','')) for r in row['requests']),'B3 headers missing')))
    args=['version','list',RID]
    def pages(req,n): return {'data':[{'version':'1.2.'+str(n)}],'nextPageToken':'cursor-'+str(n)}
    for name,flags,num in [('first',['--page-size','3'],1),('bounded',['--page-size','3','--max-pages','2'],2),('all_cap',['--page-size','3','--all','--max-pages','1'],40)]:
        queries=[{'pageSize':'3',**({'pageToken':'cursor-'+str(n)} if n else {})} for n in range(num)]
        outcomes.append(await run('paging.'+name,args+flags,pages,count=num,check=lambda row,num=num,queries=queries:pagination(row,['1.2.'+str(i) for i in range(1,num+1)],'cursor-'+str(num),queries)))
    outcomes.append(await run('paging.resume',args+['--page-token','cursor-A','--page-size','3'],{'data':[{'version':'1.2.8'}]},check=lambda row:pagination(row,['1.2.8'],None,[{'pageSize':'3','pageToken':'cursor-A'}])))
    outcomes.append(await run('paging.empty_intermediate',args+['--max-pages','2'],lambda r,n:{'data':[],'nextPageToken':'empty-next'} if n==1 else {'data':[{'version':'1.2.3'}]},count=2,check=lambda row:pagination(row,['1.2.3'],None,[{'pageSize':'100'},{'pageSize':'100','pageToken':'empty-next'}])))
    def retry_page(req,n):
        if n==2: return httpx.ReadTimeout('synthetic interrupted page')
        return {'data':[{'version':'1.2.2' if req.url.params.get('pageToken') else '1.2.1'}],**({} if req.url.params.get('pageToken') else {'nextPageToken':'retry-cursor'})}
    outcomes.append(await run('paging.retry_whole_batch',args+['--max-pages','2'],retry_page,count=4,check=lambda row:pagination(row,['1.2.1','1.2.2'],None,[{'pageSize':'100'},{'pageSize':'100','pageToken':'retry-cursor'},{'pageSize':'100'},{'pageSize':'100','pageToken':'retry-cursor'}])))
    outcomes.append(await run('paging.interrupted',args+['--max-pages','2'],lambda r,n:({'data':[{'version':'1.2.1'}],'nextPageToken':'cursor-1'} if n%2 else asyncio.CancelledError()),exit=5,count=2,check=lambda row:assert_value(isinstance(json.loads(row['stdout']),dict) and 'next_page_token' not in row['stderr'],'failed batch must not publish partial success')))
    outcomes.append(await run('paging.recovery_from_last_success',args+['--page-token','cursor-1'],{'data':[{'version':'1.2.2'}]},check=lambda row:pagination(row,['1.2.2'],None,[{'pageSize':'100','pageToken':'cursor-1'}])))
    tag=SDK_VERSION
    installed=Path(foundry_sdk.__file__).parent/'v2/third_party_applications'
    namespace=[]
    for p in sorted(installed.rglob('*.py')):
        rel=p.relative_to(installed).as_posix()
        ref='foundry_sdk/v2/third_party_applications/'+rel
        frozen=subprocess.check_output(['git','-C',str(SDK_SOURCE),'show',tag+':'+ref])
        namespace.append({'path':ref,'installed_sha256':sha(p),'frozen_tag_sha256':hashlib.sha256(frozen).hexdigest(),'normalized_match':p.read_bytes().replace(b'\r\n',b'\n')==frozen.replace(b'\r\n',b'\n')})
    result={'sdk_version':SDK_VERSION,'sdk_tag_commit':git(SDK_SOURCE,'rev-parse',tag+'^{}'),'runtime_head':git(RUNTIME,'rev-parse','HEAD'),'runtime_module_sha256':sha(Path(cli.__file__)),'loaded_cli':cli.__file__,'namespace_sources':namespace,'network_controls':controls,'network_boundary':'Native DNS/connect/connect_ex/create_connection and HTTP transports denied. Windows asyncio self-pipe loopback connect only is exempt. MockTransport only; no public HTTP.','fixture':{'zip_sha256':sha(ZIP),'zip_crc_test':True,'index_at_root':True,'scope':'Valid synthetic ZIP fixture; not a production app or tenant acceptance.'},'cases':outcomes,'operation_count':len(cli.OP_SPECS),'pass':all(x['pass'] for x in outcomes+controls) and all(x['normalized_match'] for x in namespace)}
    path=OUT/('raw_'+SDK_VERSION+'.json')
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'sdk':SDK_VERSION,'cases':len(outcomes),'pass':result['pass'],'failed':[{k:r[k] for k in ('case','actual_exit','problems')} for r in outcomes if not r['pass']],'namespace_files':len(namespace),'raw':str(path)},indent=2))

def console_probe(index):
    name,argv,method,path,query,body,response,result=CASES[index]
    requests=[]
    async def handler(req):
        requests.append({'method':req.method,'path':req.url.path,'query':dict(req.url.params),'body_sha256':hashlib.sha256(req.content).hexdigest(),'bearer_correct':req.headers.get('authorization')=='Bearer '+TOKEN})
        return httpx.Response(200,json=response) if response is not None else httpx.Response(204)
    with patch.dict(os.environ,ENV,clear=True),patch.object(sys,'argv',['pal-found-third-party-applications',*argv]),patch('foundry_sdk._core.http_client._get_async_transport',return_value=httpx.MockTransport(handler)):
        code=cli.console_main()
    (OUT/('console_'+SDK_VERSION+'_'+str(index)+'.json')).write_text(json.dumps({'sdk':SDK_VERSION,'operation':name,'requests':requests,'exit':code,'loaded_cli':cli.__file__},indent=2)+'\n')
    return code

if __name__=='__main__':
    if '--console' in sys.argv: raise SystemExit(console_probe(int(sys.argv[-1])))
    asyncio.run(main())
