import pathlib, json, subprocess, sys, datetime, time, re, hashlib, collections, zipfile
ROOT=pathlib.Path.cwd()
OUT=ROOT/'.ept/tmp/rest077_recovery_20261117'; OUT.mkdir(exist_ok=True)
OLD=ROOT/'.ept/tmp/rest077_executor_20261116'
B=ROOT/'.ept/tmp/rest077_formal_corrected_v2_20261116'
PEER=ROOT/'.ept/tmp/feature015_rest077_case_peer_final_20261116b.json'
TIDS=['TESTEXEC-078','TESTCASE-078','DEV-078','UNITTEST-078','CODEREVIEW-079','DESIGN-078','DEV-STORY-077']
IDENTITY='/root/rest077_formal_close_recover_20261117'
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(p,v): pathlib.Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
def cli(*args):
    cmd=[sys.executable,'.ept/tools/tracker/tracker_cli.py',*args]; start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.perf_counter()
    p=subprocess.run(cmd,capture_output=True,encoding='utf-8'); elapsed=time.perf_counter()-t
    with (OUT/'transcript.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(command=cmd,started_utc=start,elapsed_seconds=elapsed,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
    if p.returncode: raise RuntimeError((cmd,p.returncode,p.stderr,p.stdout))
    return p.stdout
def export(tid,phase):
    folder=OUT/phase;folder.mkdir(exist_ok=True)
    count=0
    for name,args in [('get',('get',tid)),('links',('link','list',tid)),('comments',('comment','list',tid))]:
        s=cli(*args,'--author','qa-engineer');(folder/f'{tid}-{name}.txt').write_text(s,encoding='utf-8')
        if name=='comments':
            ids=re.findall(r'^(\d{8}-\d{6}-\S+)',s,re.M)
            for cid in ids:(folder/f'{tid}-{cid}.txt').write_text(cli('comment','get',tid,cid,'--author','qa-engineer'),encoding='utf-8')
            count=len(ids)
    return count
def comment(subject,text):
    s=cli('comment','create','TESTEXEC-078','--subject',subject,'--text',text.replace('\\','/'),'--author','qa-engineer')
    cid=re.search(r'\d{8}-\d{6}-\S+',s).group()
    (OUT/f'TESTEXEC-078-{cid}.txt').write_text(cli('comment','get','TESTEXEC-078',cid,'--author','qa-engineer'),encoding='utf-8')
    return cid
def verify():
    run=json.loads((OLD/'formal-run.json').read_text()); cases=json.loads((B/'rest077_formal_cases.json').read_text()); peer=json.loads(PEER.read_text());freeze=json.loads((B/'rest077_assets_freeze.json').read_text())
    cmd=json.loads((OLD/'formal-command.json').read_text());before=json.loads((OLD/'before-verification.json').read_text());after=json.loads((OLD/'after-verification.json').read_text())
    assert run['formal_execution'] and run['outcome']=='FORMAL_EXECUTION_PASS' and cmd['exit_code']==0
    assert run['executor_identity']=='/root/rest077_distinct_formal_executor_20261116' and run['executor_identity']!=run['author_identity']
    assert len(run['checks'])==597 and all(x['result']=='PASS' for x in run['checks'])
    for name,key in [('rest077_formal_cases.json','cases_sha256'),('rest077_formal_execute.py','harness_sha256'),('rest077_formal_cases.feature','feature_sha256'),('rest077_assets_freeze.json','freeze_sha256')]:
        assert sha(B/name)==run[key]==peer[key]==before['bundle_hashes'][name]==after['bundle_hashes'][name]
    assert sha(PEER)==before['peer_sha256']==after['peer_sha256']
    assert peer['disposition']=='APPROVED' and len(peer['per_case'])==23
    for n,h in freeze['assets'].items():assert sha(pathlib.Path(freeze['skill_root'])/n)==h,n
    for n,h in freeze['primary_sources'].items():assert sha(n)==h,n
    assert before['assets']==after['assets']==len(freeze['assets'])==855
    assert before['primary_sources']==after['primary_sources']==len(freeze['primary_sources'])==42
    assert (OLD/'formal-stderr.txt').stat().st_size==0 and '597' in (OLD/'formal-stdout.txt').read_text()
    transcript=[json.loads(x) for x in (OLD/'transcript.jsonl').read_text().splitlines()]
    assert all(x['exit_code']==0 for x in transcript)
    status=[x for x in transcript if 'update' in x['command'] and '--status' in x['command'] and 'In Progress' in x['command']]
    assert len(status)==1 and status[0]['started_utc']<cmd['started_utc']
    grouped=collections.defaultdict(list)
    for check in run['checks']:grouped[check['case_id']].append(check)
    assert len(cases['operations'])==23 and all(c['case_id'] in grouped for c in cases['operations'])
    summary=dict(verified_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),recovery_identity=IDENTITY,executor_identity=run['executor_identity'],author_identity=run['author_identity'],reviewer_identity='/root/rest077_corrected_cases_fresh_peer_20261116b',formal_run_sha256=sha(OLD/'formal-run.json'),peer_sha256=sha(PEER),command=cmd,before=before,after=after,total_checks=len(run['checks']),case_results=[dict(case_id=c['case_id'],operation=c['operation'],outcome='PASS',check_count=len(grouped[c['case_id']]),checks=grouped[c['case_id']]) for c in cases['operations']],annex_results={k:v for k,v in grouped.items() if k not in {c['case_id'] for c in cases['operations']}},time_basis='Only measured original subprocess wall elapsed; historical human effort and recovery work unmeasured. CPU time not recorded.',time_spent_hours=cmd['process_elapsed_seconds']/3600,original_cli_commands=len(transcript),in_progress_transition=status[0])
    save(OUT/'independent-verification.json',summary)
    return summary
if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':
        print(cli('search','TESTEXEC-078','--in-content','--author','qa-engineer'))
        counts={t:export(t,'before') for t in TIDS}
        for typ in ['testexec','codereview','dev_story']:(OUT/f'{typ}-type-info.txt').write_text(cli('type-info',typ,'--author','qa-engineer'),encoding='utf-8')
        (OUT/'status-In Progress.txt').write_text(cli('workflow','status','testexec','In Progress','--author','qa-engineer'),encoding='utf-8')
        v=verify();print(json.dumps(dict(counts=counts,checks=v['total_checks'],cases=[(c['case_id'],c['check_count']) for c in v['case_results']],annexes={k:len(v) for k,v in v['annex_results'].items()},time=v['command']),indent=2))
    elif action=='outcomes':
        v=verify(); cases=json.loads((B/'rest077_formal_cases.json').read_text())
        common=f"Original execution {v['command']['started_utc']} to {v['command']['ended_utc']}; executor {v['executor_identity']}. Recovery recorder {IDENTITY}, 2026-11-17. Environment {v['before']['environment']}; imported SDK1.101.0, source commit168d51910570b6966afa2320333ab36f6a3f7ccf. Test data are synthetic approved case kwargs, wire fixtures and response values. Actual raw proof .ept/tmp/rest077_executor_20261116/formal-run.json SHA256 {v['formal_run_sha256']}; formal-command.json exit0, stdout PASS597, stderr empty. Approved case SHA256 d8348cc55625780dc53c7a91872a2d3519dd289ccef58555d8cf2ea59decc20b; unchanged harness a2fd951f64ceb2081426e59d73d31ad37224387de61a4fd9dd5580513642a460. Independent verification .ept/tmp/rest077_recovery_20261117/independent-verification.json. No new execution occurred during recovery."
        ids=[]
        ids.append(comment('Formal execution recovery provenance and evidence 2026-11-17',common+'\n\nOriginal executor completed approved v2 run on November16, then stopped before workflow outcomes/archive. Existing raw results independently verified against approval, cases, before/after bindings855 reader assets and42 primary sources. Original approval file is an executor copy with separate prerequisite attestation; immutable peer original preserved. All23 cases and annexes PASS597. No defects observed, so no BUG-SUB required. No unresolved Question or Blocks links observed. Case author and reviewer remain distinct from actual executor. Recovery records prior actual outcomes only.'))
        for c,op in zip(v['case_results'],cases['operations']):
            detail='\n'.join(f"PASS {x['check']}: {json.dumps({k:z for k,z in x.items() if k not in ['case_id','check','result']},ensure_ascii=False,sort_keys=True)}" for x in c['checks'])
            ids.append(comment(f"Actual PASS {c['case_id']} {c['operation']}",common+f"\n\n{c['check_count']} actual checks PASS. Synthetic request kwargs {json.dumps(op['kwargs'],sort_keys=True)}. Expected wire {json.dumps(op['wire'],sort_keys=True)}.\n"+detail))
        for k,checks in v['annex_results'].items():
            ids.append(comment(f'Actual PASS annex {k}',common+'\n\n'+json.dumps(checks,ensure_ascii=False,indent=2)))
        save(OUT/'outcome-comment-ids.json',ids);print('RECORDED',len(ids))
    elif action=='close':
        v=verify()
        for tid in ['TESTCASE-078','DEV-078','UNITTEST-078','CODEREVIEW-079','DESIGN-078']:assert 'current_status: Closed' in cli('get',tid,'--author','qa-engineer')
        assert 'current_status: In Progress' in cli('get','TESTEXEC-078','--author','qa-engineer')
        links=cli('link','list','TESTEXEC-078','--direction','all','--author','qa-engineer');assert 'Blocks' not in links
        ids=json.loads((OUT/'outcome-comment-ids.json').read_text());assert len(ids)>=25
        print(comment('In Progress DoD satisfied from recovered actual execution 2026-11-17',f"All23 approved cases and annexes recorded as individual actual PASS comments, IDs {','.join(ids)}. Original597-check raw run and independent hash verification preserved. Related indexed authoring contract and exact partitions reviewed in approved case/source evidence; critical checks include independent oracle, source-empty named errors, all declared modes, generic403, timeout/cancel/cleanup, finite paging, uncertain mutation reconciliation and SDK-opaque grouping policy. No defects or unresolved questions; all prerequisite implementation/review/design/case tickets Closed. CodeReview type supports Closed Approved and no Resolved stage; completed later-stage evidence satisfies completed/resolved intent. Links verified; no outgoing Blocks exists to remove. Reporting only original measured subprocess elapsed {v['command']['process_elapsed_seconds']} seconds = {v['time_spent_hours']:.15f} hours. Historical human effort and recovery effort unmeasured; CPU time unavailable; estimate10h unchanged. Evidence attached through exact local raw paths and hashes in preceding outcomes. Request QA Resolved then QA Closed after readback verification; no story/manual release or register update."))
        print(cli('update','TESTEXEC-078','--field',f"time_spent_hours={v['time_spent_hours']:.15f}",'--author','qa-engineer'))
        print(cli('workflow','transitions','testexec','In Progress','--author','qa-engineer'))
        s=cli('update','TESTEXEC-078','--status','Resolved','--author','qa-engineer');(OUT/'Resolved-context.txt').write_text(s,encoding='utf-8');print(s)
    elif action=='finalclose':
        assert 'current_status: Resolved' in cli('get','TESTEXEC-078','--author','qa-engineer')
        print(comment('Resolved DoD QA verification and closure 2026-11-17','QA verification confirms all approved tests executed in original November16 run;597 recorded checks PASS, individual outcomes and evidence present. No defects found; no BUG-SUB outstanding. QA acceptance based on original raw logs, exact command/timestamps, unchanged source/reader/case/harness hashes and fresh full CLI context exports. Actual executor identity preserved. Time field contains only measured subprocess elapsed; human effort unmeasured. Closure ends this execution subtask; story/release acceptance stays with responsible roles.'))
        print(cli('workflow','transitions','testexec','Resolved','--author','qa-engineer'))
        s=cli('update','TESTEXEC-078','--status','Closed','--author','qa-engineer');(OUT/'Closed-context.txt').write_text(s,encoding='utf-8');print(s)
        counts={t:export(t,'after') for t in TIDS};save(OUT/'after-export-counts.json',counts);print(counts)
    elif action=='package':
        v=verify();freeze=json.loads((B/'rest077_assets_freeze.json').read_text());cases=json.loads((B/'rest077_formal_cases.json').read_text())
        assert 'current_status: Closed' in (OUT/'after/TESTEXEC-078-get.txt').read_text()
        source=pathlib.Path(freeze['skill_root']).parents[2]
        commands={}
        for name,args in [('head',['git','-C',str(source),'rev-parse','HEAD']),('status',['git','-C',str(source),'status','--short'])]:
            p=subprocess.run(args,capture_output=True,text=True);assert p.returncode==0;commands[name]=dict(command=args,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
        assert commands['head']['stdout'].strip()=='77b101fb7c5e51fa5f785b2147d97cdfff703133' and commands['status']['stdout']==''
        save(OUT/'source-git-state.json',commands)
        counts=json.loads((OUT/'after-export-counts.json').read_text())
        payload={}
        def add(p,name=None):
            p=pathlib.Path(p)
            if p.is_file() and p.suffix!='.pyc':payload[name or p.relative_to(ROOT).as_posix()]=p
        for folder in [OLD,B,ROOT/'.ept/tmp/rest077_formal_20261116',ROOT/'.ept/tmp/rest077_formal_corrected_20261116',ROOT/'.ept/tmp/rest077_case_stage_20261116',OUT]:
            for p in folder.rglob('*'):add(p)
        for p in (ROOT/'.ept/tmp').glob('*rest077*'):
            if p.is_file() and p.suffix in ['.json','.py','.patch','.txt','.log']:add(p)
        for n,h in freeze['assets'].items():
            p=pathlib.Path(freeze['skill_root'])/n; assert sha(p)==h; add(p,'reader_assets/'+n.replace('\\','/'))
        for i,(n,h) in enumerate(freeze['primary_sources'].items()):
            p=pathlib.Path(n);assert sha(p)==h;add(p,f'primary_sources/{i:02d}-{p.name}')
        docs=['.ept/docs/document_index.md','.ept/docs/deliverables/development/FEATURE-015-rest-authoring-contract.md','.ept/docs/deliverables/development/FEATURE-015-rest-operation-partitions.json','.github/agents/qa-engineer.agent.md']
        docs += [f'.ept/resources/skills/{s}/SKILL.md' for s in ['caveman','humanizer','work-instructions','workflow','tracking-system']]
        docs+=['.ept/resources/skills/tracking-system/references/REFERENCE.md']
        for n in docs:add(ROOT/n)
        for n in ['maintainer/rest-domain-independent-review-077-current.json','maintainer/evidence/rest077-unit/rest077_unit_qa_20261116.json','maintainer/evidence/rest077-unit/terminal-newline-continuity.json','tests/test_offline_rest_077.py','maintainer/rest-contract-register.json']:add(source/n,'consulted_source/'+n)
        entries=[dict(member=n,source=str(p),size=p.stat().st_size,sha256=sha(p)) for n,p in sorted(payload.items())]
        inv=ROOT/'.ept/tmp/feature015_rest077_formal_qa_inventory.json'
        save(inv,dict(story='DEV-STORY-077',payload_members=len(entries),entries=entries,reader_assets=len(freeze['assets']),primary_sources=len(freeze['primary_sources']),source_map=freeze,comment_exports=counts,total_full_comment_bodies=sum(counts.values())))
        canonical=ROOT/'.ept/tmp/feature015_rest077_formal_qa.json'
        storytext=(OUT/'after/DEV-STORY-077-get.txt').read_text();story_status=re.search(r'current_status: (.+)',storytext).group(1)
        data=dict(story='DEV-STORY-077',testcase='TESTCASE-078',testexec='TESTEXEC-078',executor=v['executor_identity'],case_author=v['author_identity'],case_reviewer=v['reviewer_identity'],source_reviewer='/root/rest077_architect_source_close_20261116',workflow_recovery_agent=IDENTITY,execution='PASS',formal_execution='PASS',formal_workflow_acceptance='Closed',checks=597,operations_count=23,declared_error_count=0,sdk_release='1.101.0',source_commit=cases['source_commit'],cases_sha256=sha(B/'rest077_formal_cases.json'),harness_sha256=sha(B/'rest077_formal_execute.py'),feature_sha256=sha(B/'rest077_formal_cases.feature'),freeze_sha256=sha(B/'rest077_assets_freeze.json'),case_approval_sha256=sha(PEER),formal_run_sha256=sha(OLD/'formal-run.json'),source_asset_bindings_checked=855,primary_source_bindings_checked=42,all_bindings_current_and_unchanged=True,actual_results=json.loads((OLD/'formal-run.json').read_text())['checks'],operations=v['case_results'],global_checks=v['annex_results'],timing=v['command'],time_spent_hours=v['time_spent_hours'],cpu_time_seconds=None,unmeasured_contributor_effort_hours=None,frontmatter_time_basis=v['time_basis'],original_before_verification=v['before'],original_after_verification=v['after'],recovery_verification=str(OUT/'independent-verification.json'),evidence_inventory=dict(path=str(inv),sha256=sha(inv),payload_members=len(entries)),closure_exports=counts,full_comment_body_count=sum(counts.values()),story_status=story_status,publication='Not performed; REST093 acceptance and070 publication remain separate',source_git=commands,limits=['No new formal execution during recovery.','Socket connect/create_connection/getaddrinfo patched in original run; direct create_connection negative probe recorded. Separate native HTTP/DNS negative probes and OS-wide firewall verification not recorded.','Policy checks assert documentation only; no live Foundry server-policy execution.','CPU time and historical human effort unmeasured.','Original successful harness asserted installed distribution version1.101.0; current package metadata not inferred.','Approved immutable case JSON retains pending approval label; final independent peer report and separate executor attestation carry actual approval/prerequisites.'],rejected_bundle=dict(initial=str(ROOT/'.ept/tmp/rest077_formal_20261116'),initial_peer=str(ROOT/'.ept/tmp/feature015_rest077_case_peer_review_20261116.json'),first_corrected=str(ROOT/'.ept/tmp/rest077_formal_corrected_20261116'),first_corrected_peer=str(ROOT/'.ept/tmp/feature015_rest077_case_peer_retest_20261116b.json'),approved_v2=str(B),final_peer=str(PEER)),scope='All23 REST077 v1 Ontology operations; no shared register promotion or story/manual release transition.')
        data['source_reviewer']=json.loads((ROOT/'.ept/tmp/rest077_architect_probe_20261116.json').read_text())['reviewer']
        save(canonical,data)
        archive=ROOT/'.ept/tmp/feature015_rest077_formal_qa_archive_20261117.zip'
        add(inv);add(canonical)
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for n,p in sorted(payload.items()):z.write(p,n)
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None and len(z.namelist())==len(payload)
            for n,p in payload.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p),n
        receipt=dict(canonical=str(canonical),canonical_sha256=sha(canonical),inventory=str(inv),inventory_sha256=sha(inv),archive=str(archive),archive_sha256=sha(archive),zip_members=len(payload),payload_members=len(entries),comment_exports=counts,full_comment_bodies=sum(counts.values()),story_status=story_status,lease='RELEASED')
        save(OUT/'archive-receipt.json',receipt);print(json.dumps(receipt,indent=2))
