import ast
import copy
import hashlib
import json
import runpy
import socket
from pathlib import Path
from unittest.mock import patch

ROOT = Path.cwd()
BASE = ROOT / '.ept/tmp/rest077_formal_corrected_20261116'
ns = runpy.run_path(str(BASE / 'rest077_formal_execute.py'), run_name='peer_retest_only')
env = ns['run'].__globals__
data = json.loads((BASE / 'rest077_formal_cases.json').read_text())
freeze = json.loads((BASE / 'rest077_assets_freeze.json').read_text())
candidate = json.loads((BASE / 'corrected_case_candidate_evidence.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks = []
def checked(name, fn):
    fn()
    checks.append({'check': name, 'result': 'PASS'})
def require(value):
    assert value
def catches(name, change, fn):
    original = env[change[0]]
    env[change[0]] = change[1]
    try:
        try:
            fn()
        except AssertionError:
            checks.append({'check': name, 'result': 'PASS', 'mutation_detected': True})
        else:
            raise RuntimeError('Independent control not detected: ' + name)
    finally:
        env[change[0]] = original

checked('candidate_hashes_exact', lambda: require(all(sha(BASE / p) == h for p, h in candidate['artifacts_sha256'].items())))
checked('original_bundle_unchanged', lambda: require(all(sha(ROOT / '.ept/tmp/rest077_formal_20261116' / p) == h for p, h in candidate['original_bundle_sha256'].items())))
oldfreeze = json.loads((ROOT / '.ept/tmp/rest077_formal_20261116/rest077_assets_freeze.json').read_text())
checked('source_asset_register_maps_unchanged', lambda: require(all(freeze[k] == oldfreeze[k] for k in ['assets', 'primary_sources', 'register_bindings'])))
checked('all_actual_sources_and_assets_unchanged', lambda: env['freeze_check'](data, freeze))
partition = json.loads((ROOT / '.ept/docs/deliverables/development/FEATURE-015-rest-operation-partitions.json').read_text())['partitions']['DEV-STORY-077']['operation_ids']
checked('all23_exact_partition_ids', lambda: require(len(data['operations']) == len(set(c['operation'] for c in data['operations'])) == 23 and set(partition) == {c['operation'] for c in data['operations']}))
for c in data['operations']:
    resource = c['operation'].split('.')[2]
    binding = c['source']['methods'][resource + 'Client']
    response = binding['request']['response_type']
    expected = 'builtins.bytes' if response == 'bytes' else response.replace('ontologies_models.', 'foundry_sdk.v1.ontologies.models.')
    returned = binding['return']
    element = returned.split('[', 1)[1].rstrip(']').replace('ontologies_models.', 'foundry_sdk.v1.ontologies.models.') if 'Iterator[' in returned else None
    checked(c['case_id'] + '_runtime_types_match_primary_source', lambda c=c,expected=expected,element=element: require(c['runtime_types'] == {'response': expected, 'element': element}))

with patch.object(socket.socket, 'connect', ns['denied']), patch.object(socket, 'create_connection', ns['denied']), patch.object(socket, 'getaddrinfo', ns['denied']):
    checked('semantic_guard_positive_and_internal_bypass_controls', lambda: env['semantic_boundaries'](data))
    catches('independent_schema_guard_bypass_detected', ('schema_guard', lambda value, schema: {'decision': 'use', 'retained': value}), lambda: env['semantic_boundaries'](data))
    catches('independent_group_guard_bypass_detected', ('group_guard', lambda value, confirmed: {'decision': 'use', 'retained': value, 'derived': 7}), lambda: env['semantic_boundaries'](data))
    original_assert = env['assert_runtime']
    catches('independent_runtime_type_guard_bypass_detected', ('assert_runtime', lambda c, value, element=False: value), lambda: env['expect_guard_failure'](lambda: env['assert_runtime'](data['operations'][0], {})))
    checked('bounded_uncertain_mutation_baseline', lambda: env['uncertain_writes'](data))
    invoke = env['invoke']
    def replay(client, case, mode='ordinary', kwargs=None):
        if case['operation'] == 'v1.ontologies.Action.apply':
            try:
                invoke(client, case, mode, kwargs)
            except ns['ReadTimeout']:
                return invoke(client, case, mode, kwargs)
        return invoke(client, case, mode, kwargs)
    catches('independent_blind_mutation_replay_detected', ('invoke', replay), lambda: env['uncertain_writes'](data))
    checked('all23_distributed_examples_and_corruption_baseline', lambda: env['distributed_examples'](data, freeze))
    catches('independent_distributed_corruption_bypass_detected', ('corrupt_decoded', lambda value: value), lambda: env['distributed_examples'](data, freeze))

out = {'kind': 'CASE-REVIEW-INDEPENDENT-CONTROLS', 'formal_execution': False, 'checks': checks, 'count': len(checks), 'source_asset_freeze_sha256': sha(BASE / 'rest077_assets_freeze.json')}
(ROOT / '.ept/tmp/rest077_case_peer_retest_controls_20261116.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'result': 'PASS', 'checks': len(checks), 'formal_execution': False}))
