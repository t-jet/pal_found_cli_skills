import ast
import copy
import hashlib
import json
from pathlib import Path

root = Path.cwd()
prior_path = root / '.ept/tmp/feature015_rest077_case_peer_retest_20261116b.json'
prior_sha = hashlib.sha256(prior_path.read_bytes()).hexdigest()
assert prior_sha == 'd5ebe719cb58908d97673833b23fad83d46eb9bb09c4cafce4106bbb705342f0'
prior_report = json.loads(prior_path.read_text())
script = (root / '.ept/tmp/rest077_peer_retest_20261116b.py').read_text().split("mixed = {'group':")[0]
script = script.replace("BASE = ROOT / '.ept/tmp/rest077_formal_corrected_20261116'", "BASE = ROOT / '.ept/tmp/rest077_formal_corrected_v2_20261116'")
script = script.replace("candidate = json.loads((BASE / 'corrected_case_candidate_evidence.json').read_text())", "candidate = json.loads((BASE / 'v2_case_candidate_evidence.json').read_text())\ncandidate['original_bundle_sha256'] = json.loads((ROOT / '.ept/tmp/rest077_formal_corrected_20261116/corrected_case_candidate_evidence.json').read_text())['original_bundle_sha256']")
context = {}
exec(compile(script, '<fresh-final-full-source-and-controls>', 'exec'), context)
BASE, data, env, checks, sha = (context[k] for k in ['BASE', 'data', 'env', 'checks', 'sha'])
check = context['check']
earlier = root / '.ept/tmp/rest077_formal_corrected_20261116'
old_candidate = json.loads((earlier / 'corrected_case_candidate_evidence.json').read_text())
check('prior_review_preserved', sha(prior_path) == prior_sha)
check('prior_corrected_bundle_preserved', all(sha(earlier / p) == h for p, h in old_candidate['artifacts_sha256'].items()))
old_tree = ast.parse((earlier / 'rest077_formal_execute.py').read_text())
new_tree = ast.parse((BASE / 'rest077_formal_execute.py').read_text())
functions = lambda tree: {n.name: ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
old_fn, new_fn = functions(old_tree), functions(new_tree)
changed = [name for name in new_fn if old_fn.get(name) != new_fn[name]]
check('only_two_approved_functions_changed', set(changed) == {'group_guard', 'semantic_boundaries'} and old_fn.keys() == new_fn.keys())
old_data = json.loads((earlier / 'rest077_formal_cases.json').read_text())
check('all23_operation_records_unchanged', data['operations'] == old_data['operations'])
mixed = {'group': {'confirmedLabel': '2026-10-01', 'unconfirmed-server-label': {'raw': 7}}, 'metrics': [{'name': 'flightCount', 'value': 1.0}]}
guarded = env['group_guard'](mixed, {'confirmedLabel': str})
check('mixed_unknown_stops_and_retains', guarded == {'decision': 'stop', 'retained': mixed, 'derived': None})
check('original_input_untouched', mixed['group']['unconfirmed-server-label'] == {'raw': 7})
no_metrics = {'group': {'confirmedLabel': '2026-10-01', 'unconfirmed-server-label': {'raw': 7}}}
check('unknown_stops_before_metrics_access', env['group_guard'](no_metrics, {'confirmedLabel': str}) == {'decision': 'stop', 'retained': no_metrics, 'derived': None})
def presence_mutant(bucket, confirmed):
    valid = all(label in bucket['group'] and type(bucket['group'][label]) is typ for label, typ in confirmed.items())
    return {'decision': 'use' if valid else 'stop', 'retained': copy.deepcopy(bucket), 'derived': bucket['metrics'][0]['value'] if valid else None}
unsafe = presence_mutant(mixed, {'confirmedLabel': str})
check('old_presence_mutant_reproduces_original_bug', unsafe['decision'] == 'use' and unsafe['derived'] == 1.0)
context['mutation']('targeted_old_presence_mutant_detected_by_full_semantic_suite', 'group_guard', presence_mutant, lambda: env['semantic_boundaries'](data))
aggregate = next(c for c in data['operations'] if c['operation'] == 'v1.ontologies.OntologyObject.aggregate')
model = env['assert_runtime'](aggregate, __import__('foundry_sdk.v1.ontologies.models', fromlist=['AggregateObjectsResponse']).AggregateObjectsResponse.model_validate({'data': [mixed]}))
check('sdk_accepts_opaque_unknown_keys', model.model_dump(by_alias=True)['data'][0]['group'] == mixed['group'])
dry_path = root / '.ept/tmp/rest077_case_review_final_dryrun_20261116b.json'
dry = json.loads(dry_path.read_text())
check('independent597_dryrun_success', dry['outcome'] == 'AUTHOR_DRY_RUN_PASS' and len(dry['checks']) == 597 and not dry['formal_execution'])
feature = (BASE / 'rest077_formal_cases.feature').read_text()
check('gherkin_local_reader_sdk_boundary_explicit', 'mixed confirmed and unknown keys stop local reader calculation with raw group retained' in feature and 'SDK opaque group data is accepted without asserting a server rejection policy' in feature)
report = copy.deepcopy(prior_report)
report.update({
    'review_kind': 'FINAL_ALLOWED_INDEPENDENT_TESTCASE_CORRECTION_REVIEW',
    'disposition': 'APPROVED', 'findings': [],
    'cases_sha256': sha(BASE / 'rest077_formal_cases.json'),
    'harness_sha256': sha(BASE / 'rest077_formal_execute.py'),
    'feature_sha256': sha(BASE / 'rest077_formal_cases.feature'),
    'freeze_sha256': sha(BASE / 'rest077_assets_freeze.json'),
    'bundle': str(BASE.relative_to(root)),
    'previous_review': {'path': str(prior_path.relative_to(root)), 'sha256': prior_sha, 'immutable': True},
    'independent_controls': checks,
    'final_residual_proof': {'input': mixed, 'guarded': guarded, 'old_presence_mutant': unsafe, 'targeted_mutant_detected': True, 'unknown_before_metrics_access': True, 'sdk_accepts_opaque_group_keys': True},
    'changed_functions': changed,
    'dry_run': {'label': 'CASE-REVIEW-DRYRUN-ONLY', 'command': '.ept/tmp/feature015_shared_cli_qa_env/Scripts/python.exe .ept/tmp/rest077_formal_corrected_v2_20261116/rest077_formal_execute.py --author-check --output .ept/tmp/rest077_case_review_final_dryrun_20261116b.json', 'exit_code': 0, 'checks': len(dry['checks']), 'elapsed_seconds': dry['elapsed_seconds'], 'outcome': dry['outcome'], 'evidence': str(dry_path.relative_to(root)), 'sha256': sha(dry_path), 'formal_execution': False},
    'approval_scope': 'Exact frozen TESTCASE bundle only. Approval is independent case peer review. Workflow closure and TESTEXEC prerequisite attestation remain separate required actions.',
})
report['correction_judgment']['R077-01'] = 'PASS; mixed known/unknown labels stop before metrics access, preserve raw data, old presence-only mutant detected; SDK opaque group data accepted'
for case in report['per_case']:
    case['case_approval'] = 'APPROVED'
    case['findings'] = []
    case['dry_run_checks'] = [r['check'] for r in dry['checks'] if r.get('case_id') == case['case_id']]
    case['checks_count'] = len(case['dry_run_checks'])
out = root / '.ept/tmp/feature015_rest077_case_peer_final_20261116b.json'
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'disposition': report['disposition'], 'controls': len(checks), 'cases': len(report['per_case']), 'dryrun_checks': len(dry['checks']), 'report': str(out.relative_to(root)), 'sha256': sha(out)}))
