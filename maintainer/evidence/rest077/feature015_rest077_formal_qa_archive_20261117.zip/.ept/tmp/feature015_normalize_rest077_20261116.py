"""Preserve reviewed bytes and bind the approved terminal-newline cleanup."""
import ast
import hashlib
import json
from pathlib import Path

repo = Path(__file__).resolve().parent / 'feature015_integration'
path = repo / 'tests/test_offline_rest_077.py'
dest = repo / 'maintainer/evidence/rest077-unit'
original = path.read_bytes()
digest = lambda raw: hashlib.sha256(raw).hexdigest()
assert digest(original) == '9210d28d61695dc6dc4ebf6488d86690e4d3f9627b888381c70176d07e96b0f6'
clean = original.rstrip(b'\r\n') + (b'\r\n' if b'\r\n' in original else b'\n')
assert original.startswith(clean)
assert set(original[len(clean):]) <= {10, 13}
assert ast.dump(ast.parse(original)) == ast.dump(ast.parse(clean))
(dest / 'test_offline_rest_077.reviewed.py').write_bytes(original)
path.write_bytes(clean)
data = {
    'author_candidate_commit': '1d96e1b54854c19ca073235def594ba1e528d6a7',
    'integrated_reviewed_commit': '9c57704',
    'reviewed_sha256': digest(original),
    'product_sha256': digest(clean),
    'reviewed_archive': 'maintainer/evidence/rest077-unit/test_offline_rest_077.reviewed.py',
    'product_path': 'tests/test_offline_rest_077.py',
    'change': 'Remove only terminal blank line; preserve final line ending.',
    'removed_bytes': len(original) - len(clean),
    'exact_byte_prefix': True,
    'ast_identical': True,
    'authorization': 'Parent integration manager authorized terminal-blank-line normalization on 2026-11-16.',
    'scope': 'Independent QA verdict binds archived reviewed bytes; unchanged AST and byte-prefix continuity bind product cleanup. No new formal QA promotion.'
}
(dest / 'terminal-newline-continuity.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
manifest_path = dest / 'archive-manifest.json'
manifest = json.loads(manifest_path.read_bytes())
for name in ('test_offline_rest_077.reviewed.py', 'terminal-newline-continuity.json'):
    artifact = dest / name
    manifest['artifacts'].append({'archived_path': artifact.relative_to(repo).as_posix(), 'sha256': digest(artifact.read_bytes())})
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps(data))
