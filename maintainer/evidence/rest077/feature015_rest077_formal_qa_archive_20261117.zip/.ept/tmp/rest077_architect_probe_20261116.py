import ast
import hashlib
import importlib
import inspect
import json
import re
import runpy
import subprocess
import textwrap
import time
from pathlib import Path

START = time.perf_counter()
ROOT = Path(__file__).resolve().parents[2]
CANDIDATE = ROOT / '.ept/tmp/feature015_integration'
BASE = CANDIDATE / '.agents/skills/pal-found-dev'
SDK = ROOT / '.ept/docs/customer_input/foundry-platform-python'
PIN = '168d51910570b6966afa2320333ab36f6a3f7ccf'
RESULT = {'reviewer': '/root/rest077_architect_review_20261116', 'candidate': subprocess.check_output(['git', '-C', str(CANDIDATE), 'rev-parse', 'HEAD'], text=True).strip(), 'source_commit': PIN, 'operations': [], 'models': [], 'failures': []}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(node):
    return ast.dump(node, include_attributes=False)


def check(ok, message):
    if not ok:
        RESULT['failures'].append(message)


def blocks(text):
    return re.findall(r'```python\r?\n(.*?)```', text, re.S)


def source(module):
    obj = importlib.import_module(module)
    installed = Path(obj.__file__).read_bytes()
    frozen = subprocess.check_output(['git', '-C', str(SDK), 'show', PIN + ':' + module.replace('.', '/') + '.py'])
    check(dump(ast.parse(installed)) == dump(ast.parse(frozen)), module + ': installed/frozen AST mismatch')
    return obj, installed, ast.parse(installed)


SOURCES = {}


def cached_source(module):
    if module not in SOURCES:
        SOURCES[module] = source(module)
    return SOURCES[module]


def symbols(tree):
    result = {}
    for node in tree.body:
        if isinstance(node, (ast.ClassDef, ast.FunctionDef)):
            result[node.name] = node
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            result[node.target.id] = node
        elif isinstance(node, ast.Assign):
            for name in node.targets:
                if isinstance(name, ast.Name):
                    result[name.id] = node
    return result


model_docs = set()
for path in sorted((BASE / 'examples/rest/077/v1/ontologies').glob('*/*.py')):
    resource, method = path.parent.name, path.stem
    identity = f'v1.ontologies.{resource}.{method}'
    module = 'foundry_sdk.v1.ontologies.' + re.sub(r'(?<!^)(?=[A-Z])', '_', resource).lower()
    obj, source_bytes, tree = cached_source(module)
    client = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == resource + 'Client')
    fn = next(n for n in client.body if isinstance(n, ast.FunctionDef) and n.name == method)
    request = next(n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'RequestInfo')
    fields = {kw.arg: kw.value for kw in request.keywords}
    contract = BASE / f'references/rest/contracts/v1/ontologies/{resource}/{method}.md'
    text = contract.read_text()
    signature = ast.parse(blocks(text)[0]).body[0]
    check(dump(signature.args) == dump(fn.args) and dump(signature.returns) == dump(fn.returns), identity + ': signature mismatch')
    for key, node in fields.items():
        match = re.search(r'\*\*' + key + r'\*\*\s+```python\s+(.*?)```', text, re.S)
        check(match is not None and dump(ast.parse(match.group(1).strip(), mode='eval').body) == dump(node), identity + ': wire field ' + key)
    returns = []
    for cls in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
        methods = [n for n in ast.walk(cls) if isinstance(n, ast.FunctionDef) and n.name == method]
        if methods:
            if methods[0].returns is None:
                inner = ast.unparse(methods[0].args.args[0].annotation)
                factory = ('async_' if cls.name.startswith('_Async') else '') + ('with_raw_response' if cls.name.endswith('Raw') else 'with_streaming_response')
                core = importlib.import_module('foundry_sdk._core')
                factory_fn = getattr(core, factory)
                factory_node = ast.parse(textwrap.dedent(inspect.getsource(factory_fn))).body[0]
                cached_source(factory_fn.__module__)
                annotation = ast.unparse(factory_node.returns.slice.elts[-1])
                annotation = re.sub(r'\bR\b', inner, annotation)
            else:
                annotation = ast.unparse(methods[0].returns)
            check(annotation in text, identity + ': mode annotation absent ' + cls.name + ' ' + annotation)
            returns.append({'class': cls.name, 'return': annotation, 'line': methods[0].lineno})
    check(len(returns) == 6, identity + ': six exposed modes')
    ns = runpy.run_path(str(path))
    class Recorder:
        @property
        def with_raw_response(self):
            return self
        def __getattr__(self, name):
            return lambda **kwargs: kwargs
    arguments = ns['invoke'](Recorder())
    bound = inspect.signature(getattr(getattr(obj, resource+'Client'), method)).bind(None, **arguments)
    bound.apply_defaults()
    def value(node):
        return eval(compile(ast.Expression(node), '<independent frozen source expression>', 'eval'), vars(obj), bound.arguments)
    check(value(fields['method']) == ns['EXPECTED_METHOD'], identity + ': example verb')
    check('/api' + value(fields['resource_path']).format(**value(fields['path_params'])) == ns['EXPECTED_PATH'], identity + ': example route')
    check(value(fields['header_params']) == ns['EXPECTED_HEADERS'], identity + ': example headers')
    check(value(fields['query_params']) == ns['EXPECTED_QUERY'], identity + ': example query')
    body = value(fields['body'])
    if hasattr(body, 'model_dump'):
        body = body.model_dump(mode='json', by_alias=True, exclude_none=True)
    check(body == ns['EXPECTED_BODY'], identity + ': example body')
    check(value(fields['throwable_errors']) == {} and ns['ERRORS'] == [], identity + ': named-error source silence')
    ns['verify']()
    guide = BASE / f'references/rest/v1/ontologies/{resource}.md'
    guide_text = guide.read_text()
    guide_line = next(i for i, line in enumerate(guide_text.splitlines(), 1) if line == '### ' + method)
    for target in re.findall(r'\]\(([^)]+)\)', text):
        dest = (contract.parent / target.split('#')[0]).resolve()
        if '/models/' in dest.as_posix() and dest.suffix == '.md':
            model_docs.add(dest)
    example_tree = ast.parse(path.read_bytes())
    invoke_line = next(n.lineno for n in example_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'invoke')
    RESULT['operations'].append({'id': identity, 'disposition': 'PASS' , 'source_path': module.replace('.', '/')+'.py', 'source_sha256': sha(source_bytes), 'source_method_line': fn.lineno, 'example': str(path.relative_to(CANDIDATE)), 'example_sha256': sha(path.read_bytes()), 'invoke_line': invoke_line, 'guide': str(guide.relative_to(CANDIDATE)), 'guide_sha256': sha(guide.read_bytes()), 'guide_operation_line': guide_line, 'contract_sha256': sha(contract.read_bytes()), 'return_modes': returns, 'request_fields_checked': sorted(fields)})

seen = set()
while model_docs - seen:
    path = sorted(model_docs - seen)[0]
    seen.add(path)
    text = path.read_text()
    identity = text.splitlines()[0].removeprefix('# ')
    module, name = identity.rsplit('.', 1)
    obj, source_bytes, tree = cached_source(module)
    node = symbols(tree)[name]
    parsed = [n for block in blocks(text) for n in ast.parse(block).body]
    check(any(dump(n) == dump(node) for n in parsed), identity + ': complete model definition AST')
    linked = set()
    for label, target in re.findall(r'\[([^]]+)\]\(([^)]+)\)', text):
        if label.startswith('foundry_sdk.'):
            linked.add(label)
            dest = (path.parent / target.split('#')[0]).resolve()
            check(dest.exists(), identity + ': missing dependency ' + label)
            model_docs.add(dest)
    local_symbols = symbols(tree)
    referenced = {n.id for n in ast.walk(node) if isinstance(n, ast.Name) and n.id in local_symbols and n.id != name}
    for n in ast.walk(node):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value in local_symbols and n.value != name:
            referenced.add(n.value)
    for dependency in referenced:
        check(module + '.' + dependency in linked, identity + ': omitted local dependency ' + dependency)
    RESULT['models'].append({'id': identity, 'document': str(path.relative_to(CANDIDATE)), 'sha256': sha(path.read_bytes()), 'source_sha256': sha(source_bytes), 'definition_ast_match': True, 'source_line': node.lineno, 'local_dependencies_checked': sorted(referenced)})

RESULT['test_sha256'] = sha((CANDIDATE / 'tests/test_offline_rest_077.py').read_bytes())
RESULT['machine_probe_seconds'] = time.perf_counter() - START
RESULT['scope'] = 'Independent frozen-source AST/signature/wire/model closure and actual SDK example verification; human semantic judgment recorded in tracker; no tenant execution, OS-wide isolation, formal QA or publication claim.'
out = ROOT / '.ept/tmp/rest077_architect_probe_20261116.json'
out.write_text(json.dumps(RESULT, indent=2) + '\n')
print(json.dumps({'operations': len(RESULT['operations']), 'models': len(RESULT['models']), 'failures': RESULT['failures'], 'machine_probe_seconds': RESULT['machine_probe_seconds']}))
raise SystemExit(bool(RESULT['failures']))
