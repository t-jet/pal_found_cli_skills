import subprocess
import sys

CLI = [sys.executable, '.ept/tools/tracker/tracker_cli.py']


def run(*args):
    print('CLI:', ' '.join(args[:4]), flush=True)
    result = subprocess.run(CLI + list(args), capture_output=True, text=True)
    print(result.stdout, flush=True)
    if result.stderr:
        print(result.stderr, flush=True)
    print('EXIT:', result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


dev = '''Validated 2026-11-16 against local integration HEAD 58117ef. DEV-STORY-077 remains Development; DESIGN-078 is Closed. Read all current DEV/UNITTEST/story/design comments and links, document index, REST authoring contract and verification design. No linked unanswered Question remains. Existing Contains and bidirectional RelatesTo links to CODEREVIEW-079 remain registered; independent architect review and subsequent QA stay separate.

Implementation is committed: corrected reader content 97174f0, accepted source baseline 3d5536c, dedicated unit commit 9c57704 and terminal-newline cleanup 7dd39c8. No push or new source edit in this readiness pass. Independent maintainer/rest-domain-independent-review-077-current.json reports PASS for every one of 23 operations, zero FAIL/UNCERTAIN. Source identity remains SDK 1.101.0, commit 168d51910570b6966afa2320333ab36f6a3f7ccf, OpenAPI 1.1697.0. Exact signatures, source-specific async iterator versus awaited wrappers, typed model constraints, v1/v2 applicability and explicit source silence are retained. This is developer readiness, not formal reader QA or live Foundry acceptance.

Files physically verified: all 23 Python reader examples under .agents/skills/pal-found-dev/examples/rest/077/v1/ontologies/ and eight resource guides under .agents/skills/pal-found-dev/references/rest/v1/ontologies/ match committed 3d5536c bytes. Shared index.md also matches, giving 32 continuity assets; shared index is not owned or edited by this developer task. Maximum Markdown length is 252 lines. In-memory compile of 23 examples and tests/test_offline_rest_077.py passed without errors; source-model hashes match independent review. No deliverable was added or renamed, so existing document-index and REST authoring links remain applicable; reader guide changes are listed below. Shared structural/models/index ownership remains core069.

Fresh commands from .ept/tmp/feature015_integration: python -m pytest -p no:cacheprovider tests/test_offline_rest_077.py -q --basetemp=<parent .ept/tmp/rest077_workflow_pytest_20261116>: exit 0, 553 passed in 2.01s. Selected shared tests: python -m pytest -p no:cacheprovider tests/test_offline_rest_wave1.py -q -k "v1.ontologies or network or external" --basetemp=<parent .ept/tmp/rest077_workflow_wave1_20261116>: exit 0, 73 passed, 445 deselected in 1.86s. Existing requests dependency and pytest-asyncio default-scope warnings did not fail tests.

Independent unit evidence at maintainer/evidence/rest077-unit/rest077_unit_qa_20261116.json covers all 23 operations in six sync/async native/raw/stream forms, generic 403 denial, configurable request_timeout and one-request ReadTimeout with preserved cause, interruption/cancellation cleanup and seven finite two-page cases. Frozen v1 source declares no named error classes for these operations; generic errors are exercised explicitly. Fifty-six baseline semantic cases remain. MockTransport and in-process DNS/socket/native HTTP denial establish unit isolation; shared guards additionally exercise requests/urllib/subprocess denial. No OS-wide or live effect claim. Coverage follows operation/behavior gates in approved design; no line-coverage percentage measured or claimed. Full shared REST acceptance remains093; publication remains070.

time_spent_hours=0.00018294575 records only measured current machine validation runtime: perf_counter 0.65860469999825 seconds for compile, source/model/hash, asset and document continuity checks. This is a bounded known contribution and lower bound, not human labor hours or total author effort. Historical author/contributor hours and first-three historical checkpoint duration are UNMEASURED. Estimate32h is unchanged and is not reported as actual. No aggregate historical-total requirement appears in current type DoD.''' 

files = '''Committed owned reader file inventory, relative to .agents/skills/pal-found-dev/:

- examples/rest/077/v1/ontologies/Action/: apply.py, apply_batch.py, validate.py
- examples/rest/077/v1/ontologies/ActionType/: get.py, list.py
- examples/rest/077/v1/ontologies/Attachment/: get.py, read.py, upload.py
- examples/rest/077/v1/ontologies/ObjectType/: get.py, get_outgoing_link_type.py, list.py, list_outgoing_link_types.py
- examples/rest/077/v1/ontologies/Ontology/: get.py, list.py
- examples/rest/077/v1/ontologies/OntologyObject/: aggregate.py, get.py, get_linked_object.py, list.py, list_linked_objects.py, search.py
- examples/rest/077/v1/ontologies/Query/: execute.py
- examples/rest/077/v1/ontologies/QueryType/: get.py, list.py
- references/rest/v1/ontologies/: Action.md, ActionType.md, Attachment.md, ObjectType.md, Ontology.md, OntologyObject.md, Query.md, QueryType.md

Corrective commit97174f0 modified Attachment get/read/upload, ObjectType get/get_outgoing_link_type/list/list_outgoing_link_types, OntologyObject aggregate/get/get_linked_object/list/list_linked_objects/search, QueryType get/list and Attachment.md, ObjectType.md, Ontology.md, OntologyObject.md, QueryType.md. It added tests/test_offline_rest_077.py; subsequent unit changes are recorded on UNITTEST-078. No deleted reader files. No reader/source files created, modified or deleted by this readiness pass.'''

unit = '''Validated 2026-11-16 against integrated HEAD58117ef. Dedicated tests/test_offline_rest_077.py is committed in9c57704;7dd39c8 removes only four terminal newline bytes. Current SHA256 01e180383eaa903bb5f75510ff5a50145d179f3a2405b411f67f0645ea1b8930; original independently reviewed SHA256 9210d28d61695dc6dc4ebf6488d86690e4d3f9627b888381c70176d07e96b0f6 remains archived at maintainer/evidence/rest077-unit/test_offline_rest_077.reviewed.py. terminal-newline-continuity.json proves exact byte prefix and identical AST. Independent review and executable probe are archived alongside it. Fresh full rerun after cleanup passed.

Fresh python -m pytest -p no:cacheprovider tests/test_offline_rest_077.py -q with --basetemp under parent .ept/tmp/rest077_workflow_pytest_20261116: exit0,553 passed in2.01s. Fresh shared wave1 selection -k "v1.ontologies or network or external" with separate .ept/tmp basetemp: exit0,73 passed,445 deselected in1.86s. In-memory compile of unit module passed. All executed unit cases passed; this pass rate is not a line-coverage claim. Existing requests and pytest-asyncio warnings remain non-failing.

All23 exact owned operations exercise actual prepared SDK1.101.0 MockTransport serialization and typed response behavior in sync/native, sync/raw, sync/stream, async/native, async/raw, async/stream forms. Cases assert generic403, configurable timeout/one-request ReadTimeout with preserved cause, stream interruption/cancellation cleanup, seven finite two-page cases, and uncertain-write synthetic-ledger behavior. Frozen v1 source has zero named error classes for these methods; empty union is checked, not replaced by invented errors. AsyncApiResponse.decode remains synchronous and aclose asynchronous. Fifty-six baseline semantic cases and ten baseline test functions remain preserved. Main and edge-case coverage follows exact source-derived behavior gates, with no numeric line-coverage requirement found in project config/design and no unmeasured coverage percentage claimed.

In-process DNS/socket/native HTTP dispatch denial plus shared requests/urllib/subprocess guards establish fixture-only unit isolation. Author-selected expected payloads retain independent source/hash/type checks and semantic mutation guards. No OS-wide disconnection, live tenant effects, formal TESTEXEC-078, source-blind reader QA, REST093 acceptance or release claim. Source/reader content32assets matches3d5536c. Current document index, approved REST authoring/verification design, all relevant ticket comments and links reviewed; no unanswered linked Question. Contains link to DEV-STORY-077 exists. Modified file: tests/test_offline_rest_077.py only for dedicated unit work; no deletion. Shared wave1 file was executed, not modified.

time_spent_hours=0.001075 records only measured current pytest execution runtime,2.01s+1.86s=3.87s/3600. This is bounded machine-runtime evidence and a lower bound for current validation, not human labor hours or full author effort. Historical author/contributor hours are UNMEASURED;8h estimate is unchanged and is not actual. Developer resolution leaves independent architect review and QA closure to their own actors.'''

run('comment', 'create', 'DEV-078', '--subject', 'Developer readiness and bounded validation evidence 2026-11-16', '--text', dev, '--author', 'python-developer')
run('comment', 'create', 'DEV-078', '--subject', 'Committed REST077 reader file inventory', '--text', files, '--author', 'python-developer')
run('update', 'DEV-078', '--field', 'time_spent_hours=0.00018294575', '--author', 'python-developer')
run('workflow', 'transitions', 'development', 'In Progress', '--author', 'python-developer')
run('update', 'DEV-078', '--status', 'Resolved', '--author', 'python-developer')
run('comment', 'create', 'UNITTEST-078', '--subject', 'Dedicated unit readiness and measured validation evidence 2026-11-16', '--text', unit, '--author', 'python-developer')
run('update', 'UNITTEST-078', '--field', 'time_spent_hours=0.001075', '--author', 'python-developer')
run('workflow', 'transitions', 'unittest', 'In Progress', '--author', 'python-developer')
run('update', 'UNITTEST-078', '--status', 'Resolved', '--author', 'python-developer')
run('get', 'DEV-078', '--author', 'python-developer')
run('get', 'UNITTEST-078', '--author', 'python-developer')
