import sys, pathlib, subprocess, json, datetime, time, re, hashlib
ROOT=pathlib.Path.cwd(); OUT=ROOT/'.ept/tmp/rest077_executor_20261116'; OUT.mkdir(exist_ok=True)
B=ROOT/'.ept/tmp/rest077_formal_corrected_v2_20261116'
PEER=ROOT/'.ept/tmp/feature015_rest077_case_peer_final_20261116b.json'
ENV=ROOT/'.ept/tmp/feature015_shared_cli_qa_env/Scripts/python.exe'
IDENTITY='/root/rest077_distinct_formal_executor_20261116'
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def cli(*args):
    cmd=[sys.executable,'.ept/tools/tracker/tracker_cli.py',*args]; start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.perf_counter()
    p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8'); elapsed=time.perf_counter()-t
    with (OUT/'transcript.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(command=cmd,started_utc=start,elapsed_seconds=elapsed,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
    if p.returncode: raise RuntimeError((cmd,p.returncode,p.stderr,p.stdout))
    return p.stdout
def export(tid,suffix=''):
    for name,args in [('get',('get',tid)),('links',('link','list',tid)),('comments',('comment','list',tid))]:
        s=cli(*args,'--author','qa-engineer');(OUT/f'{tid}-{name}{suffix}.txt').write_text(s,encoding='utf-8')
        if name=='comments':
            ids=re.findall(r'^(\d{8}-\d{6}-\S+)',s,re.M)
            for cid in ids:(OUT/f'{tid}-{cid}.txt').write_text(cli('comment','get',tid,cid,'--author','qa-engineer'),encoding='utf-8')
    return (OUT/f'{tid}-get{suffix}.txt').read_text(encoding='utf-8')
def comment(subject,text,tid='TESTEXEC-078'):
    out=cli('comment','create',tid,'--subject',subject,'--text',text,'--author','qa-engineer')
    cid=re.search(r'\d{8}-\d{6}-\S+',out).group();body=cli('comment','get',tid,cid,'--author','qa-engineer');(OUT/f'{tid}-{cid}.txt').write_text(body,encoding='utf-8');return cid
def verify(label):
    peer=json.loads(PEER.read_text()); freeze=json.loads((B/'rest077_assets_freeze.json').read_text());cases=json.loads((B/'rest077_formal_cases.json').read_text())
    assert peer['disposition']=='APPROVED' and len(peer['per_case'])==23
    for name,key in [('rest077_formal_cases.json','cases_sha256'),('rest077_formal_execute.py','harness_sha256'),('rest077_formal_cases.feature','feature_sha256'),('rest077_assets_freeze.json','freeze_sha256')]:assert sha(B/name)==peer[key]
    for name,digest in freeze['assets'].items():assert sha(pathlib.Path(freeze['skill_root'])/name)==digest,name
    for name,digest in freeze['primary_sources'].items():assert sha(name)==digest,name
    p=subprocess.run([str(ENV),'-c','import foundry_sdk, httpx, pydantic; print(foundry_sdk.__version__); print(foundry_sdk.__file__)'],capture_output=True,text=True);assert p.returncode==0 and p.stdout.startswith('1.101.0')
    report=dict(checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),assets=len(freeze['assets']),primary_sources=len(freeze['primary_sources']),operations=len(cases['operations']),runtime=p.stdout,environment=str(ENV),bundle_hashes={n:sha(B/n) for n in ['rest077_formal_cases.json','rest077_formal_execute.py','rest077_formal_cases.feature','rest077_assets_freeze.json']},peer_sha256=sha(PEER))
    (OUT/f'{label}-verification.json').write_text(json.dumps(report,indent=2));return report
if __name__=='__main__':
    if sys.argv[1]=='prepare':
        print(cli('search','DEV-STORY-077','--author','qa-engineer'))
        for tid in ['TESTEXEC-078','TESTCASE-078','DEV-078','UNITTEST-078','CODEREVIEW-079','DESIGN-078','DEV-STORY-077']: print(tid,export(tid).split('current_status: ')[1].splitlines()[0])
        for typ in ['testexec','codereview']:(OUT/f'{typ}-type-info.txt').write_text(cli('type-info',typ,'--author','qa-engineer'))
        for status in ['Open','In Progress','Resolved']:(OUT/f'transitions-{status}.txt').write_text(cli('workflow','transitions','testexec',status,'--author','qa-engineer'))
        print(json.dumps(verify('before'),indent=2))
    elif sys.argv[1]=='start':
        for tid in ['TESTCASE-078','DEV-078','UNITTEST-078','CODEREVIEW-079','DESIGN-078']:
            assert 'current_status: Closed' in cli('get',tid,'--author','qa-engineer')
        assert 'current_status: Open' in cli('get','TESTEXEC-078','--author','qa-engineer')
        assert 'Blocks' not in cli('link','list','TESTEXEC-078','--author','qa-engineer')
        report=verify('before')
        comment('Formal execution plan and environment verified 2026-11-16',f"Executor {IDENTITY}; case original author /root/rest077_formal_case_author_20261116, corrector /root/rest077_case_correct_20261116; independent reviewer /root/rest077_corrected_cases_fresh_peer_20261116b. Exact identities retained in original candidate and peer records. Plan: execute immutable approved all23 harness once in prepared SDK1.101.0 environment, preserve stdout/stderr/timestamps and every check, verify855 reader assets/42 primary source hashes before and after, record each operation result then resolve/close only after actual DoD. No live Foundry access. Socket connect, create_connection and DNS deny patches surround mocked SDK transport; independent negative probes will verify native HTTP/DNS denial.\n\nFresh CLI exports all7 tickets and every comment body in .ept/tmp/rest077_executor_20261116/transcript.jsonl. CASE078 Closed Approved, DEV078/UNIT078/CR079/DESIGN078 Closed and parent QA. CodeReview type has no Resolved stage; closed implementation/review is completed later-stage proof satisfying prerequisite completed/resolved intent; no ticket is falsely described as currently Resolved. No QUESTION or Blocks link on execution ticket. Required fields, assignment, Contains link and estimate10h present. Indexed authoring contract and exact partitions govern23 v1 Ontology operations. Physical implementation in prepared standalone .ept/tmp/feature015_integration, runnable distributed examples and SDK clients exist. Environment imports runtime SDK1.101.0; distribution version also returns1.101.0 in fresh check. No metadata inferred. Exact source42 hashes bind runtime/source proof.\n\nReadiness: {json.dumps(report,sort_keys=True)}. Author/reviewer dry runs are readiness only. Formal execution output new .ept/tmp/rest077_executor_20261116/formal-run.json; no source, case, harness or assertion edits authorized. Real failure stops for ticketed correction. Evidence archive will retain initial rejected cases, repair histories, peer findings and final approval; machine elapsed time only, human effort unmeasured. No shared register promotion, final REST acceptance or publication claim.")
        print(cli('workflow','transitions','testexec','Open','--author','qa-engineer'))
        context=cli('update','TESTEXEC-078','--status','In Progress','--author','qa-engineer');assert 'current_status: In Progress' in context
        (OUT/'In Progress-context.txt').write_text(context)
        approval=json.loads(PEER.read_text());approval.update(testcase_closed=True,testexec_prerequisites_verified=True,executor_prerequisite_attestation=dict(executor_identity=IDENTITY,peer_original_sha256=sha(PEER),workflow_state='In Progress',evidence='transcript.jsonl'))
        (OUT/'execution-approval.json').write_text(json.dumps(approval,indent=2))
        print('FORMAL READY')
    elif sys.argv[1]=='run':
        assert 'current_status: In Progress' in cli('get','TESTEXEC-078','--author','qa-engineer')
        cmd=[str(ENV),str(B/'rest077_formal_execute.py'),'--executor-identity',IDENTITY,'--approval',str(OUT/'execution-approval.json'),'--output',str(OUT/'formal-run.json')]
        start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();p=subprocess.run(cmd,capture_output=True,text=True);elapsed=time.perf_counter()-t
        (OUT/'formal-stdout.txt').write_text(p.stdout);(OUT/'formal-stderr.txt').write_text(p.stderr)
        (OUT/'formal-command.json').write_text(json.dumps(dict(command=cmd,started_utc=start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),process_elapsed_seconds=elapsed,exit_code=p.returncode),indent=2))
        print(p.stdout,p.stderr,'exit',p.returncode);assert p.returncode==0
        print(json.dumps(verify('after'),indent=2))
