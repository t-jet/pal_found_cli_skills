from pathlib import Path
import hashlib,json
p=Path('.ept/tmp/rest077_formal_corrected_v2_20261116')
previous=Path('.ept/tmp/rest077_formal_corrected_20261116')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
prior={str(q.relative_to(previous)):sha(q) for q in previous.rglob('*') if q.is_file()}
original=Path('.ept/tmp/rest077_formal_20261116')
prior_original={str(q.relative_to(original)):sha(q) for q in original.rglob('*') if q.is_file()}
review=Path('.ept/tmp/feature015_rest077_case_peer_retest_20261116b.json')
assert sha(review)=='d5ebe719cb58908d97673833b23fad83d46eb9bb09c4cafce4106bbb705342f0'
(p/'earlier_bundle_immutable_snapshot.json').write_text(json.dumps({'previous':prior,'original':prior_original,'review_sha256':sha(review)},indent=2)+'\n')
h=p/'rest077_formal_execute.py';s=h.read_text()
old="""def group_guard(bucket,confirmed):
    # This is an application-approved mapping. SDK Dict[str, Any] defines no mapping.
    valid=all(label in bucket['group'] and type(bucket['group'][label]) is typ for label,typ in confirmed.items())
    return {'decision':'use' if valid else 'stop','retained':copy.deepcopy(bucket),'derived':bucket['metrics'][0]['value'] if valid else None}
"""
new="""def group_guard(bucket,confirmed):
    # Local reader decision only. SDK Dict[str, Any] still accepts opaque group data.
    retained=copy.deepcopy(bucket)
    if set(bucket['group'])-set(confirmed):
        return {'decision':'stop','retained':retained,'derived':None}
    valid=all(label in bucket['group'] and type(bucket['group'][label]) is typ for label,typ in confirmed.items())
    return {'decision':'use' if valid else 'stop','retained':retained,'derived':bucket['metrics'][0]['value'] if valid else None}
"""
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("    def group_contract(guard):\n", "    mixed=copy.deepcopy(data['aggregation_guard_cases']['mixed_confirmed_unknown'])\n    def group_contract(guard):\n",1)
s=s.replace('        for value in [unknown,malformed]:','        for value in [unknown,malformed,mixed]:',1)
needle="    group_contract(group_guard)\n"
addition="""    group_contract(group_guard)
    def presence_only_mutant(bucket,confirmed):
        valid=all(label in bucket['group'] and type(bucket['group'][label]) is typ for label,typ in confirmed.items())
        return {'decision':'use' if valid else 'stop','retained':copy.deepcopy(bucket),'derived':bucket['metrics'][0]['value'] if valid else None}
    def mixed_contract(guard):
        result=guard(mixed,approved)
        assert result['decision']=='stop' and result['derived'] is None and result['retained']==mixed, 'Unconfirmed extra label permits unsafe derived computation'
    mixed_contract(group_guard)
    unsafe=presence_only_mutant(mixed,approved)
    assert unsafe['decision']=='use' and unsafe['derived']==1.0 and unsafe['retained']==mixed
    expect_guard_failure(lambda:mixed_contract(presence_only_mutant))
    record('F077-AGGREGATION','mixed_confirmed_unknown_label_and_presence_only_mutant',
           input=mixed,confirmed_mapping={'confirmedLabel':'builtins.str'},
           guarded=group_guard(mixed,approved),mutant=unsafe,mutant_detected=True,
           boundary='Local reader stops calculation; SDK/server group data remains opaque and retained')
"""
assert s.count(needle)==1;s=s.replace(needle,addition)
h.write_text(s)
c=p/'rest077_formal_cases.json';data=json.loads(c.read_text());original_operations=data['operations']
data['aggregation_guard_cases']={'mixed_confirmed_unknown':{'group':{'confirmedLabel':'2026-10-01','unconfirmed-server-label':{'raw':7}},'metrics':[{'name':'flightCount','value':1.0}]},'confirmed_mapping':{'confirmedLabel':'builtins.str'},'expected_decision':'stop','expected_derived':None,'scope':'Local reader calculation guard only. SDK group Dict[str, Any] accepts opaque values; no SDK/server rejection policy is asserted.'}
data['review_corrections']['R077-01']='Final correction: guard stops before metric computation if any group key lacks operator-confirmed mapping. Mixed confirmed plus unknown payload retains full raw data and yields derived=None. Targeted old presence/type-only mutant yields use/1.0 and must fail mixed-label contract. Existing schema and full bypass controls retained. This is a local reader decision; SDK/server opaque group data remains allowed.'
c.write_text(json.dumps(data,indent=2)+'\n')
assert json.loads((previous/'rest077_formal_cases.json').read_text())['operations']==original_operations
f=p/'rest077_formal_cases.feature';s=f.read_text();needle='    Then unknown labels stop derived computation\n';assert s.count(needle)==1
s=s.replace(needle,needle+'    And mixed confirmed and unknown keys stop local reader calculation with raw group retained\n    And old presence/type-only guard fails the mixed-label contract\n    And SDK opaque group data is accepted without asserting a server rejection policy\n');f.write_text(s)
for folder,snapshot in [(previous,prior),(original,prior_original)]:
    assert snapshot=={str(q.relative_to(folder)):sha(q) for q in folder.rglob('*') if q.is_file()},str(folder)
print('Narrow mixed-label correction written; all previous files and all23 operation records unchanged')
