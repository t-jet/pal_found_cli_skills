from pathlib import Path
import ast,json,hashlib
p=Path('.ept/tmp/rest077_formal_corrected_v2_20261116');previous=Path('.ept/tmp/rest077_formal_corrected_20261116');original=Path('.ept/tmp/rest077_formal_20261116')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
snapshot=json.loads((p/'earlier_bundle_immutable_snapshot.json').read_text())
for folder,key in [(previous,'previous'),(original,'original')]: assert snapshot[key]=={str(q.relative_to(folder)):sha(q) for q in folder.rglob('*') if q.is_file()}
functions=lambda q:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(q.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
old,new=functions(previous/'rest077_formal_execute.py'),functions(p/'rest077_formal_execute.py')
changed=[name for name in old if old[name]!=new[name]]
assert set(changed)=={'group_guard','semantic_boundaries'} and set(old)==set(new)
freeze=json.loads((p/'rest077_assets_freeze.json').read_text());prior=json.loads((previous/'rest077_assets_freeze.json').read_text())
assert freeze==prior and sha(p/'rest077_assets_freeze.json')==sha(previous/'rest077_assets_freeze.json')
for file,digest in freeze['primary_sources'].items(): assert sha(Path(file))==digest
root=Path(freeze['skill_root'])
for file,digest in freeze['assets'].items(): assert sha(root/file)==digest
cases=json.loads((p/'rest077_formal_cases.json').read_text());oldcases=json.loads((previous/'rest077_formal_cases.json').read_text())
assert cases['operations']==oldcases['operations'] and len(cases['operations'])==23
for finding in ['R077-02','R077-03','R077-04','R077-05','R077-06']: assert cases['review_corrections'][finding]==oldcases['review_corrections'][finding]
dry=json.loads((p/'corrected_v2_author_dry_run.json').read_text());control=next(row for row in dry['checks'] if row['check']=='mixed_confirmed_unknown_label_and_presence_only_mutant')
assert control['guarded']['decision']=='stop' and control['guarded']['derived'] is None and control['guarded']['retained']==control['input']
assert control['mutant']['decision']=='use' and control['mutant']['derived']==1.0 and control['mutant_detected'] is True
artifacts={name:sha(p/name) for name in ['rest077_formal_cases.json','rest077_formal_execute.py','rest077_formal_cases.feature','rest077_assets_freeze.json','corrected_v2_author_dry_run.json']}
report={'author_identity':'/root/rest077_case_correct_20261116','kind':'FINAL_ALLOWED_CORRECTION_CANDIDATE','formal_execution':False,'testcase_closed':False,'tracker_mutations':[], 'disposition':'PENDING_FRESH_INDEPENDENT_REVIEW','prior_review':{'file':'.ept/tmp/feature015_rest077_case_peer_retest_20261116b.json','sha256':snapshot['review_sha256']},'artifacts_sha256':artifacts,'earlier_bundle_files_and_reports_immutable':True,'changed_top_level_harness_functions':changed,'operation_records_unchanged':23,'prior_five_fixes_unchanged':True,'reader_assets':len(freeze['assets']),'primary_sources':len(freeze['primary_sources']),'source_asset_register_maps_unchanged':True,'source_commit':cases['source_commit'],'negative_control_proof':control,'per_finding_disposition':{key:('Residual mixed-label gap corrected; targeted unsafe mutant caught. Fresh review pending.' if key=='R077-01' else 'Prior fresh peer PASS preserved; corresponding implementation and case declarations unchanged.') for key in cases['review_corrections']},'author_dry_run':{'command':'.ept/tmp/feature015_shared_cli_qa_env/Scripts/python.exe .ept/tmp/rest077_formal_corrected_v2_20261116/rest077_formal_execute.py --author-check --output .ept/tmp/rest077_formal_corrected_v2_20261116/corrected_v2_author_dry_run.json','exit_code':0,'outcome':dry['outcome'],'checks':len(dry['checks']),'elapsed_seconds':dry['elapsed_seconds'],'formal_execution':False},'boundaries':['Application reader calculation stops; SDK and server accept opaque group data without invented key constraints.','No formal execution, workflow promotion, live service requests, commits or push.']}
(p/'v2_case_candidate_evidence.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'sha256':artifacts,'checks':len(dry['checks']),'elapsed_seconds':dry['elapsed_seconds'],'negative_control_proof':control},indent=2))
