"""Rerun all-operation review after the isolated aggregation clarification."""
from pathlib import Path

parent = Path(__file__).resolve().parent
source = (parent / 'rest077_retest_probe_20261029.py').read_text(encoding='utf-8')
source = source.replace("OUT = TMP / 'feature015_rest077_semantic_retest_20261029.json'", "OUT = TMP / 'feature015_rest077_semantic_final_retest_20261029.json'")
source = source.replace("status = 'UNCERTAIN' if short == 'OntologyObject.aggregate' else 'PASS'", "status = 'PASS'")
source = source.replace("OUT.write_text(json.dumps(report,indent=2)+'\\n',encoding='utf-8')", '''
first_path = TMP / 'feature015_rest077_semantic_retest_20261029.json'
assert sha(first_path) == '2ad0924a0aba4aff4a90fe5766aea6f490be6e734439e74bcfc8a0d067836e9f'
first = json.loads(first_path.read_text())
freeze_path = TMP / 'rest077_aggregate_clarify_freeze_20261029.json'
assert sha(freeze_path) == '87cc7e278dacdf8f8a4b0c628b36c2e578203d10382461e8e837b7b6d7ece2e1'
freeze = json.loads(freeze_path.read_text())
assert dict((x['path'], x['sha256']) for x in before) == freeze['after']
assert dict((x['path'], x['sha256']) for x in first['owned_manifest_after']) == freeze['before']
assert len(freeze['changed']) == 3 and freeze['unchanged_count'] == 18
reason = ('Request and declared date schema, P1D duration, prefixed fields and named numeric metric remain coherent. '
          'Guide and example now explicitly identify response group Dict[str,Any], opaque labels/values and absent '
          'source conventions or bucket boundaries. No longer indexes using requested field or parses mock value '
          'as universal date. Real response labels must be confirmed from approved enrollment documentation/schema; '
          'missing labels or invalid values stop derived calculation and retain request/response for recovery. '
          'Synthetic exact roundtrip remains bounded decoding evidence. Explicit source silence and bounded '
          'interpretation meet this source-informed review scope; live label mapping and boundary calculations remain unverified.')
for row, preceding in zip(rows, first['rows']):
    row['preceding_retest_status'] = preceding['status']
    row['preceding_retest_reason'] = preceding['reason']
    if row['operation_id'] == 'v1.ontologies.OntologyObject.aggregate':
        row['reason'] = reason
        aggregate = cases['OntologyObject.aggregate']
        import copy
        for grouping in ({'inspectionDate':'2026-10-01'}, {'opaque':17}, {'opaque':None}, {'opaque':{'nested':[False,1]}}, {}, {'one':'first','two':False}):
            fixture = copy.deepcopy(aggregate['SUCCESS'])
            fixture['data'][0]['group'] = grouping
            request = httpx.Request('POST','https://offline.example.invalid',json=aggregate['EXPECTED_BODY'])
            aggregate['check_result'](fixture, request)
            original = aggregate['SUCCESS']
            aggregate['SUCCESS'] = fixture
            try:
                aggregate['verify']()
            finally:
                aggregate['SUCCESS'] = original
report['cross_cutting_findings'][1] = {'status':'PASS', 'reason':reason}
report['preceding_retest'] = {'path':str(first_path), 'sha256':sha(first_path), 'summary':first['summary'], 'cross_cutting_findings':first['cross_cutting_findings']}
report['clarification_freeze'] = {'path':str(freeze_path), 'sha256':sha(freeze_path), 'changed':freeze['changed'], 'unchanged_count':18, 'preimage_and_current_manifest_match':True}
report['independent_checks'].append({'name':'six opaque group label/value variations pass direct checker and actual SDK HTTP roundtrip', 'status':'PASS'})
report['lint_diff_checks'] = 'Independent D:/app/Python/Scripts/ruff.exe check --no-cache on aggregate example and tests passed; git diff --check passed.'
report['owned_manifest_after_independent_opaque_variants'] = [asset(path) for path in owned]
assert report['owned_manifest_after_independent_opaque_variants'] == before
OUT.write_text(json.dumps(report,indent=2)+'\\n',encoding='utf-8')
''')
exec(compile(source, str(parent / 'rest077_retest_probe_20261029.py'), 'exec'))
