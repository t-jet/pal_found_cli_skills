import sys, pathlib, json, hashlib, re, time, subprocess
sys.path.insert(0,str(pathlib.Path('.ept/tmp').resolve()))
from rest077_case_stage_20261116 import cli,OUT
B=pathlib.Path('.ept/tmp/rest077_formal_corrected_v2_20261116')
P=pathlib.Path('.ept/tmp/feature015_rest077_case_peer_final_20261116b.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
peer=json.loads(P.read_text()); cases=json.loads((B/'rest077_formal_cases.json').read_text()); freeze=json.loads((B/'rest077_assets_freeze.json').read_text())
def comment(subject,text):
    result=cli('comment','create','TESTCASE-078','--subject',subject,'--text',text,'--author','qa-engineer')
    cid=re.search(r'(\d{8}-\d{6}-\S+)',result).group(1)
    body=cli('comment','get','TESTCASE-078',cid,'--author','qa-engineer')
    (OUT/(cid+'.txt')).write_text(body,encoding='utf-8')
    return cid
if sys.argv[1]=='prepare':
    assert peer['disposition']=='APPROVED' and len(peer['per_case'])==23
    assert sha(P)=='b7f2aff835e3f61a06fb45a4bec61721ddc11de455613f8da87a4beb94b5b21f'
    for name,key in [('rest077_formal_cases.json','cases_sha256'),('rest077_formal_execute.py','harness_sha256'),('rest077_formal_cases.feature','feature_sha256'),('rest077_assets_freeze.json','freeze_sha256')]:assert sha(B/name)==peer[key],name
    checked=[]
    for section,base in [('assets',pathlib.Path(freeze['skill_root'])),('primary_sources',None)]:
        for name,digest in freeze[section].items():
            p=base/name if base else pathlib.Path(name)
            assert p.is_file() and sha(p)==digest,str(p)
            checked.append(str(p))
    assert len(freeze['register_bindings'])==23 and len(freeze['assets'])==855 and len(freeze['primary_sources'])==42
    env=pathlib.Path('.ept/tmp/feature015_shared_cli_qa_env/Scripts/python.exe')
    cmd=[str(env),'-c',"import foundry_sdk; print(foundry_sdk.__version__)"]
    p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0 and p.stdout.strip()=='1.101.0'
    result={'checked_assets':855,'checked_sources':42,'bundle_hashes':{n:sha(B/n) for n in ['rest077_formal_cases.json','rest077_formal_execute.py','rest077_formal_cases.feature','rest077_assets_freeze.json']},'peer_sha256':sha(P),'sdk_version':p.stdout.strip(),'environment':str(env),'formal_execution':False}
    (OUT/'readiness.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    comment('Open readiness verified and approved bundle frozen 2026-11-16',f"Plan 20261116-095144-@qa-engineer applies. Current CLI confirms DEV-STORY-077 QA; DEV-078, UNITTEST-078, CODEREVIEW-079 and DESIGN-078 Closed, review resolution Approved. DEV closure 20261116-224234-@qa-engineer and UNIT closure 20261116-150428-@qa-engineer ground actual implementation: 553 dedicated plus 73 selected shared passes, 23 compiled examples, real SDK-backed source/behavior checks. No linked QUESTION or active incoming blocker exists on CASE078; CASE/EXEC links each contain only parent Contains. Related indexed document_index.md, FEATURE-015-rest-authoring-contract.md, exact partitions, BA-DES-015 revision2 and SA-DES-014 revision2 govern scope. Partition b8ddbb4c6908ef43e93f756cf69029b52beda5b486f5ec0131b1c5d66ae50a0e remains exact 23 IDs.\n\nFresh physical validation: all 855 reader assets and 42 primary source files match frozen manifest; all23 register bindings present. Prepared environment {env} imports SDK1.101.0. Runnable/network-denied basis: independent peer dry run597 and115 controls, all23 approved; case execution still pending distinct executor. Evidence .ept/tmp/rest077_case_stage_20261116/readiness.json and CLI transcript.jsonl.\n\nApproved bundle {B}; exact hashes: {json.dumps(result['bundle_hashes'],sort_keys=True)}. Independent author /root/rest077_case_correct_20261116; reviewer /root/rest077_corrected_cases_fresh_peer_20261116b; staging /root/rest077_case_workflow_finalize_20261116. Peer {P}, SHA256 {sha(P)}, disposition APPROVED. Earlier rejection347/six findings and first repair596/residual mixed-label finding remain immutable in original and corrected bundles and previous peer reports. Final second correction597 stops local calculation on mixed unknown labels while SDK accepts opaque group data. Design stable, runnable assets physically present; Open DoD met. This stages approved cases only; no formal TESTEXEC or publication claim.")
    print(json.dumps(result,indent=2))
elif sys.argv[1]=='cases':
    feature=(B/'rest077_formal_cases.feature').read_text()
    header=feature[:feature.index('  Scenario Outline:')]
    ids=[]
    for i,op in enumerate(cases['operations']):
        start=feature.index('  Scenario Outline: '+op['case_id']+' ')
        end=feature.index('  Scenario Outline: '+cases['operations'][i+1]['case_id']+' ') if i<22 else feature.index('  Scenario: Mutation and validation lifecycle boundaries')
        source=op['source']
        oracle={k:op[k] for k in ['operation','kwargs','wire','response','runtime_types','paged','modes','adverse']}
        text=header+feature[start:end]
        text+='\nLiteral inputs and expected results (approved JSON, exact operation ID):\n```json\n'+json.dumps(oracle,ensure_ascii=False,indent=2)+'\n```\n'
        text+='\nSource: '+source['path']+' SHA256 '+source['sha256']+'. Bindings: '+json.dumps({k:{x:v[x] for x in ['line','ast_sha256','return','named_errors']} for k,v in source['methods'].items()},sort_keys=True)+'.\nReader assets: '+json.dumps(op['assets'])+'. Complete source request AST, docs and model bindings remain in approved JSON/freeze. This comment specifies expectations; no actual execution result is asserted.'
        ids.append({'case_id':op['case_id'],'operation':op['operation'],'comment_id':comment(op['case_id']+' '+op['operation']+' approved BDD case',text)})
    tail=feature[feature.index('  Scenario: Mutation and validation lifecycle boundaries'):]
    ids.append({'annex':'lifecycle-guards','comment_id':comment('Approved BDD annex: lifecycle guards paging and model decisions',tail+'\n\nApproved semantic schema, INVALID validation payload, group guard inputs and policy attribution:\n```json\n'+json.dumps({k:cases[k] for k in ['semantic_schema','invalid_action_result','review_corrections','policy_attribution','aggregation_guard_cases']},indent=2)+'\n```\nSix automatic iterators plus explicit search make seven pagers. Unknown labels stop reader computation; opaque SDK/server values stay allowed. These are expected outcomes and source-document checks; no live retention or visibility timer was executed.')})
    ids.append({'annex':'provenance','comment_id':comment('Approved coverage provenance and formal execution handoff boundaries',f"All23 qualified operation IDs and literal payloads are recorded in preceding Gherkin comments, with exact source bindings and runtime model/element/bytes identities. Every operation has six available modes, empty source-named throwable union, generic403, timeout and zero-timeout cases. Cleanup expectations distinguish raw decode/consumer failures, streaming consumer exceptions and async cancellation. Seven explicit sync/async response pagers cover bounds and repeated tokens; six automatic iterators cover early stop. No extra autoiterator is claimed.\n\nFull transitive model/error closure and local reader paths: {B}/rest077_assets_freeze.json SHA256 {sha(B/'rest077_assets_freeze.json')}, preserving855 asset and42 source hashes plus23 register bindings and complete qualified symbol references. Independent per-case approvals and115 controls: {P} SHA256 {sha(P)}. Review dry run597 is harness readiness only. Every distributed verify and actual invocation binding/wire/runtime type is covered, including corrupt decoded-result controls. Source oracle is independently derived; distributed expected constants do not supply oracle fixtures.\n\nAuthor/corrector and peer are separate identities recorded in readiness comment. Original initial rejection and first-repair residual remain immutable. Only final second-repair hashes are approved. Formal executor must be distinct from author, corrector and reviewer; fresh TESTEXEC prerequisites and actual run remain pending. No TESTEXEC transition, formal register promotion, REST093 final acceptance, story deployment or publication follows from this case staging.")})
    (OUT/'staged-comments.json').write_text(json.dumps(ids,indent=2),encoding='utf-8')
    print('Staged',len(ids),'comments;',len(cases['operations']),'operation cases')
