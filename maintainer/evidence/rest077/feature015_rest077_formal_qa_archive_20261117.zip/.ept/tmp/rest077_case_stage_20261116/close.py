import sys,pathlib,json,re,hashlib
sys.path.insert(0,str(pathlib.Path('.ept/tmp/rest077_case_stage_20261116').resolve()))
from stage import cli,OUT,comment,B,P,cases,peer,sha
action=sys.argv[1]
if action=='resolve':
    ids=json.loads((OUT/'staged-comments.json').read_text())
    assert len(ids)==25 and len([x for x in ids if 'case_id' in x])==23
    for item in ids:
        body=cli('comment','get','TESTCASE-078',item['comment_id'],'--author','qa-engineer')
        if 'case_id' in item:
            assert item['operation'] in body and 'Given ' in body and 'When ' in body and 'Then ' in body
            raw=body.split('```json\n',1)[1].split('\n```',1)[0]
            oracle=json.loads(raw,strict=False)
            try: json.loads(raw)
            except json.JSONDecodeError:
                fixed=json.dumps(oracle,ensure_ascii=False,indent=2).replace('\\n','\\u000a').replace('\\r','\\u000d').replace('\\t','\\u0009')
                text=body.split('text:\n',1)[1].rstrip().replace(raw,fixed)
                cli('comment','update','TESTCASE-078',item['comment_id'],'--text',text,'--author','qa-engineer')
                body=cli('comment','get','TESTCASE-078',item['comment_id'],'--author','qa-engineer')
                oracle=json.loads(body.split('```json\n',1)[1].split('\n```',1)[0])
            op=next(c for c in cases['operations'] if c['case_id']==item['case_id'])
            assert all(oracle[k]==op[k] for k in oracle)
        (OUT/(item['comment_id']+'.txt')).write_text(body,encoding='utf-8')
    hours=(0.40961869999591727+0.39735400000063237)/3600
    print(cli('update','TESTCASE-078','--field',f'time_spent_hours={hours:.15f}','--field','resolution=Approved','--author','qa-engineer'))
    comment('In Progress DoD complete: 23 approved cases read back 2026-11-16',f"Read back all23 source-bound operation comments and2 approved annexes through CLI. Parsed every literal oracle JSON and compared operation, kwargs, wire, payload, runtime types, modes, pagination and adverse expectations against immutable approved case JSON; exact equality. All23 Given/When/Then cases reference actual SDK functions and API paths. All23 independent case dispositions APPROVED;597 review-only dry checks and115 independent controls remain readiness evidence. Asset/model/source closure and lifecycle/decision/network/paging coverage are linked in annexes. No linked active QUESTION or blocker; Contains01829 retained, no CASE-to-EXEC Blocks link exists to remove.\n\nMandatory frontmatter validated from testcase type-info. resolution=Approved and time_spent_hours={hours:.15f}; estimate6h unchanged. Time is explicitly partial machine runtime only: final corrector dry run0.40961869999591727s plus independent peer dry run0.39735400000063237s, total0.8069726999965496s. Historical human author/review/staging labor is unmeasured and excluded; no human hours fabricated.\n\nCurrent QA ownership permits In Progress-to-Resolved and Resolved-to-Closed once no active incoming blocker is confirmed. This stages approved case definitions only. Formal execution remains pending distinct executor. Approved hashes and frozen assets remain unchanged. CLI evidence .ept/tmp/rest077_case_stage_20261116/transcript.jsonl; source case append map staged-comments.json.")
    print(cli('workflow','transitions','testcase','In Progress','--author','qa-engineer'))
    context=cli('update','TESTCASE-078','--status','Resolved','--author','qa-engineer');(OUT/'Resolved-context.txt').write_text(context,encoding='utf-8');print(context)
elif action=='close':
    current=cli('get','TESTCASE-078','--author','qa-engineer');assert 'current_status: Resolved' in current
    links=cli('link','list','TESTCASE-078','--author','qa-engineer');assert 'Blocks' not in links and 'Contains' in links
    exec_before=cli('get','TESTEXEC-078','--author','qa-engineer');assert 'current_status: Open' in exec_before
    comment('Resolved closure verification and distinct executor handoff 2026-11-16',"Coverage and independent approval confirmed for all23 cases at exact approved hashes. Fresh CLI CASE078 links show Contains01829 only, no active incoming block and no outgoing CASEBlocksEXEC078 link; no link cleanup needed. Preserve Contains and all unrelated links. Current testcase Resolved DoD requires no active blocker and lists QA Engineer, so staging QA can close directly without impersonating another reviewer. Resolution Approved and partial machine-only time already recorded.\n\nClose case-design work; hand off frozen bundle and23 source case comments plus2 annexes to distinct formal executor. TESTEXEC-078 remains Open with no added result or transition. Executor must independently check current prerequisites and execute approved harness against matching frozen assets under socket/DNS denial. Review/author dry runs remain nonformal. DEV-STORY-077 remains QA; no formal register promotion, Deployment, REST093 acceptance or publication claim. Terminal source comments will be archived with subsequent formal run by authorized owner.")
    print(cli('workflow','transitions','testcase','Resolved','--author','qa-engineer'))
    context=cli('update','TESTCASE-078','--status','Closed','--author','qa-engineer');(OUT/'Closed-context.txt').write_text(context,encoding='utf-8');print(context)
elif action=='export':
    exports={}
    for tid in ['TESTCASE-078','TESTEXEC-078','DEV-STORY-077']:
        exports[tid]=cli('get',tid,'--author','qa-engineer');(OUT/(tid+'-final.txt')).write_text(exports[tid],encoding='utf-8')
        (OUT/(tid+'-links-final.txt')).write_text(cli('link','list',tid,'--author','qa-engineer'),encoding='utf-8')
    assert 'current_status: Closed' in exports['TESTCASE-078'] and 'current_status: Open' in exports['TESTEXEC-078'] and 'current_status: QA' in exports['DEV-STORY-077']
    comments=cli('comment','list','TESTCASE-078','--author','qa-engineer');(OUT/'TESTCASE-078-comments-final.txt').write_text(comments,encoding='utf-8')
    ids=re.findall(r'^(\d{8}-\d{6}-\S+)',comments,re.M)
    for cid in ids:(OUT/('final-'+cid+'.txt')).write_text(cli('comment','get','TESTCASE-078',cid,'--author','qa-engineer'),encoding='utf-8')
    summary={'agent':'/root/rest077_case_workflow_finalize_20261116','lease':'RELEASED','case_status':'Closed','exec_status':'Open','story_status':'QA','formal_execution':False,'before_case_comments':4,'after_case_comments':len(ids),'appended_case_comments':len(ids)-4,'operation_cases':23,'bdd_annexes':2,'case_exec_blocks_removed':[],'case_link_state':'Contains01829 only; no blocker existed','approved_peer_sha256':sha(P),'bundle_hashes':{n:sha(B/n) for n in ['rest077_formal_cases.json','rest077_formal_execute.py','rest077_formal_cases.feature','rest077_assets_freeze.json']}}
    (OUT/'handoff.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    manifest={p.name:sha(p) for p in OUT.iterdir() if p.is_file() and p.name!='artifact-sha256.json'}
    (OUT/'artifact-sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2));print('Transcript SHA256',sha(OUT/'transcript.jsonl'));print('Manifest SHA256',sha(OUT/'artifact-sha256.json'))
