import ast
import copy
import hashlib
import json
import runpy
import socket
import subprocess
import sys
import time
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path.cwd()
BASE = ROOT / '.ept/tmp/rest077_formal_corrected_20261116'
OUT = ROOT / '.ept/tmp/feature015_rest077_case_peer_retest_20261116b.json'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
data = json.loads((BASE / 'rest077_formal_cases.json').read_text())
freeze = json.loads((BASE / 'rest077_assets_freeze.json').read_text())
old = json.loads((ROOT / '.ept/tmp/rest077_formal_20261116/rest077_assets_freeze.json').read_text())
candidate = json.loads((BASE / 'corrected_case_candidate_evidence.json').read_text())
ns = runpy.run_path(str(BASE / 'rest077_formal_execute.py'), run_name='fresh_peer_only')
env = ns['run'].__globals__
checks = []

def check(name, value):
    assert value, name
    checks.append({'check': name, 'result': 'PASS'})

def mutation(name, key, replacement, fn):
    original = env[key]
    env[key] = replacement
    try:
        try:
            fn()
        except AssertionError:
            checks.append({'check': name, 'result': 'PASS', 'mutation_detected': True})
        else:
            raise RuntimeError('Mutation not detected: ' + name)
    finally:
        env[key] = original

check('exact_candidate_hashes', all(sha(BASE / p) == h for p, h in candidate['artifacts_sha256'].items()))
check('original_bundle_immutable', all(sha(ROOT / '.ept/tmp/rest077_formal_20261116' / p) == h for p, h in candidate['original_bundle_sha256'].items()))
check('original_source_asset_register_maps_unchanged', all(freeze[k] == old[k] for k in ['assets', 'primary_sources', 'register_bindings']))
env['freeze_check'](data, freeze)
check('all855_assets_and42_primary_sources_match', True)
partition = json.loads((ROOT / '.ept/docs/deliverables/development/FEATURE-015-rest-operation-partitions.json').read_text())['partitions']['DEV-STORY-077']['operation_ids']
check('exact23_partition_ids', len(data['operations']) == 23 and set(partition) == {c['operation'] for c in data['operations']})
sdk = ROOT / '.ept/docs/customer_input/foundry-platform-python'
commit = subprocess.run(['git', '-C', str(sdk), 'rev-parse', '1.101.0^{}'], capture_output=True, text=True, check=True).stdout.strip()
check('immutable_tag_commit', commit == '168d51910570b6966afa2320333ab36f6a3f7ccf')
source_rows = []
for c in data['operations']:
    resource, method = c['operation'].split('.')[-2:]
    relative = c['source']['module'].replace('.', '/') + '.py'
    primary = subprocess.run(['git', '-C', str(sdk), 'show', commit + ':' + relative], capture_output=True, check=True).stdout.decode()
    tree = ast.parse(primary)
    check(c['case_id'] + '_installed_module_ast', ast.dump(tree) == ast.dump(ast.parse(Path(c['source']['path']).read_text())))
    rows = []
    for cls_name, binding in c['source']['methods'].items():
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls_name)
        fn = next(n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method)
        ri = next(n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ['RequestInfo', 'RequestInfoWithPagination'])
        req = {k.arg: ast.unparse(k.value) for k in ri.keywords}
        args = dict(zip([a.arg for a in fn.args.kwonlyargs], [ast.literal_eval(v) if isinstance(v, ast.Constant) else None for v in fn.args.kw_defaults]))
        args.update(c['kwargs'])
        evaluate = lambda expr: eval(compile(ast.parse(expr, mode='eval'), '<immutable-source>', 'eval'), {'__builtins__': {}}, args)
        result = {
            'class': cls_name,
            'method_ast_equal': hashlib.sha256(ast.dump(fn, include_attributes=False).encode()).hexdigest() == binding['ast_sha256'],
            'request_binding_equal': req == binding['request'],
            'method_equal': evaluate(req['method']) == c['wire']['method'],
            'path_equal': evaluate(req['resource_path']).format(**evaluate(req['path_params'])) == c['wire']['path'],
            'query_equal': {k: v for k, v in evaluate(req['query_params']).items() if v is not None} == c['wire']['query'],
            'headers_equal': {k: str(v) for k, v in evaluate(req['header_params']).items() if v is not None} == c['wire']['headers'],
            'return': ast.unparse(fn.returns), 'response_type': req['response_type'], 'named_errors': evaluate(req['throwable_errors'])
        }
        check(c['case_id'] + '_' + cls_name + '_immutable_source_bindings', all(v for k, v in result.items() if k.endswith('_equal')) and result['named_errors'] == {})
        rows.append(result)
    req = rows[0]['response_type']
    response_type = 'builtins.bytes' if req == 'bytes' else req.replace('ontologies_models.', 'foundry_sdk.v1.ontologies.models.')
    ret = rows[0]['return']
    element = ret.split('[', 1)[1].rstrip(']').replace('ontologies_models.', 'foundry_sdk.v1.ontologies.models.') if 'Iterator[' in ret else None
    check(c['case_id'] + '_runtime_type_source_binding', c['runtime_types'] == {'response': response_type, 'element': element})
    source_rows.append({'case_id': c['case_id'], 'operation': c['operation'], 'bindings': rows})

with patch.object(socket.socket, 'connect', ns['denied']), patch.object(socket, 'create_connection', ns['denied']), patch.object(socket, 'getaddrinfo', ns['denied']):
    env['semantic_boundaries'](data)
    mutation('schema_guard_bypass_detected', 'schema_guard', lambda value, schema: {'decision': 'use', 'retained': value}, lambda: env['semantic_boundaries'](data))
    mutation('group_guard_bypass_detected', 'group_guard', lambda value, schema: {'decision': 'use', 'retained': value, 'derived': 7}, lambda: env['semantic_boundaries'](data))
    mutation('runtime_identity_bypass_detected', 'assert_runtime', lambda c, value, element=False: value, lambda: env['expect_guard_failure'](lambda: env['assert_runtime'](data['operations'][0], {})))
    env['uncertain_writes'](data)
    invoke = env['invoke']
    def replay(client, case, mode='ordinary', kwargs=None):
        try:
            return invoke(client, case, mode, kwargs)
        except ns['ReadTimeout']:
            return invoke(client, case, mode, kwargs)
    mutation('mutation_replay_detected', 'invoke', replay, lambda: env['uncertain_writes'](data))
    env['distributed_examples'](data, freeze)
    mutation('distributed_corruption_bypass_detected', 'corrupt_decoded', lambda value: value, lambda: env['distributed_examples'](data, freeze))

mixed = {'group': {'confirmedLabel': '2026-10-01', 'unconfirmed-server-label': {'raw': 7}}, 'metrics': [{'name': 'flightCount', 'value': 1.0}]}
mixed_result = env['group_guard'](mixed, {'confirmedLabel': str})
assert mixed_result['decision'] == 'use' and mixed_result['derived'] == 1.0
finding = {
    'id': 'R077-01-RESIDUAL', 'severity': 'major', 'scope': ['F077-15', 'F077-AGGREGATION'],
    'location': 'rest077_formal_execute.py:389-392 group_guard; rest077_formal_cases.feature:740-743 unknown-label scenario',
    'finding': 'A valid confirmed group label plus an additional unknown server label is accepted and produces a derived metric. The guard checks only approved labels, while Gherkin promises that unknown labels stop derived computation. The negative case contains only the unknown label, so it cannot detect this partial bypass.',
    'reproduction_input': mixed, 'approved_mapping': {'confirmedLabel': 'builtins.str'}, 'actual': mixed_result,
    'expected': {'decision': 'stop', 'retained': mixed, 'derived': None},
    'required_fix': 'Reject group keys outside the confirmed mapping before deriving. Add valid-plus-unknown mutation and a control that skips unknown-key rejection while retaining presence/type checks; require that control to fail.'
}
dry = ROOT / '.ept/tmp/rest077_case_review_dryrun_20261116b.json'
dry_data = json.loads(dry.read_text())
per_case = []
for r in source_rows:
    rows = [v for v in dry_data['checks'] if v.get('case_id') == r['case_id']]
    per_case.append({**r, 'source_literal_contract_review': 'PASS', 'case_approval': 'CHANGES_REQUIRED' if r['case_id'] == 'F077-15' else 'APPROVED', 'findings': ['R077-01-RESIDUAL'] if r['case_id'] == 'F077-15' else [], 'dry_run_checks': [v['check'] for v in rows], 'checks_count': len(rows)})
report = {
    'reviewer_identity': '/root/rest077_corrected_cases_fresh_peer_20261116b', 'author_identity': candidate['author_identity'],
    'review_kind': 'FRESH_INDEPENDENT_TESTCASE_CORRECTION_REVIEW', 'disposition': 'CHANGES_REQUIRED',
    'formal_execution': False, 'testcase_closed': False, 'testexec_prerequisites_verified': False, 'tracker_mutations': [],
    'cases_sha256': sha(BASE / 'rest077_formal_cases.json'), 'harness_sha256': sha(BASE / 'rest077_formal_execute.py'),
    'feature_sha256': sha(BASE / 'rest077_formal_cases.feature'), 'freeze_sha256': sha(BASE / 'rest077_assets_freeze.json'),
    'source_commit': commit, 'source_sources_count': len(freeze['primary_sources']), 'reader_assets_count': len(freeze['assets']),
    'original_maps_preserved': True, 'actual_sources_and_assets_match': True,
    'dry_run': {'label': 'CASE-REVIEW-DRYRUN-ONLY', 'command': '.ept/tmp/feature015_shared_cli_qa_env/Scripts/python.exe .ept/tmp/rest077_formal_corrected_20261116/rest077_formal_execute.py --author-check --output .ept/tmp/rest077_case_review_dryrun_20261116b.json', 'exit_code': 0, 'checks': len(dry_data['checks']), 'elapsed_seconds': dry_data['elapsed_seconds'], 'outcome': dry_data['outcome'], 'evidence': str(dry.relative_to(ROOT)), 'sha256': sha(dry), 'formal_execution': False},
    'correction_judgment': {'R077-01': 'PARTIAL; mixed confirmed/unknown labels remain accepted', 'R077-02': 'PASS; actual lost response, bounded authorized observations, retained unknown outcome, no replay; upload no-RID escalation', 'R077-03': 'PASS; exact model/element/bytes identity with wrong-type controls', 'R077-04': 'PASS; seven sync/async explicit response pagers, item and page bounds, repeated-token retention, six sync/async automatic iterator early stops', 'R077-05': 'PASS; claims narrowed to executed cleanup modes, raw decode/consumer failures, streaming exceptions/cancellation, async403 closure and zero-timeout before HTTP', 'R077-06': 'PASS; all23 verify routines execute, invocation SDK binding/wire/runtime type checked, corrupt decoded results rejected'},
    'independent_controls': checks, 'findings': [finding], 'per_case': per_case,
    'workflow_snapshot': {'TESTCASE-078': 'Open', 'TESTEXEC-078': 'Open', 'DEV-STORY-077': 'Development'},
    'limits': ['Synthetic process-level socket/DNS denial only.', 'No live Foundry request, server retention timer, visibility guarantee, formal execution, final REST acceptance, or tracker transition.', 'Original bundle and previous reports remain unchanged.']
}
OUT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'disposition': report['disposition'], 'findings': len(report['findings']), 'independent_controls': len(checks), 'report': str(OUT.relative_to(ROOT)), 'sha256': sha(OUT)}))
