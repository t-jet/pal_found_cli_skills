import ast
import pprint
from pathlib import Path

root = Path('E:/learn/GenAI_Foundations_DA/git/foundry_cli/.ept/tmp/feature015_rest077_fixes')
base = root / '.agents/skills/pal-found-dev/examples/rest/077/v1/ontologies'
rid = 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001'
target_rid = 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000002'
asset = {'apiName': 'Asset', 'displayName': 'Asset', 'status': 'ACTIVE',
         'primaryKey': ['assetId'], 'properties': {'assetId': {'baseType': 'String'},
         'status': {'baseType': 'String'}, 'inspectionDate': {'baseType': 'LocalDate'}}, 'rid': rid}
facility = {'apiName': 'Facility', 'displayName': 'Facility', 'status': 'ACTIVE',
            'primaryKey': ['facilityId'], 'properties': {'facilityId': {'baseType': 'String'},
            'name': {'baseType': 'String'}}, 'rid': target_rid}
obj = {'properties': {'assetId': 'A-1', 'status': 'ready', 'inspectionDate': '2026-10-01'}, 'rid': rid}
linked = {'properties': {'facilityId': 'F-1', 'name': 'North depot'}, 'rid': target_rid}
link = {'apiName': 'facility', 'displayName': 'Facility', 'status': 'ACTIVE',
        'objectTypeApiName': 'Facility', 'cardinality': 'ONE'}
query = {'apiName': 'asset-status', 'parameters': {'assetId': {'baseType': 'String', 'required': True}},
         'output': {'type': 'struct', 'fields': [
             {'name': 'assetId', 'fieldType': {'type': 'string'}, 'required': True},
             {'name': 'status', 'fieldType': {'type': 'string'}, 'required': True}]},
         'rid': rid, 'version': '1.2.3'}

def edit(resource, operation, values, invoke=None, checker=None, replacements=()):
    path = base / resource / (operation + '.py')
    text = path.read_text()
    for old, new in replacements:
        text = text.replace(old, new)
    nodes = ast.parse(text).body
    lines = text.splitlines(keepends=True)
    changes = []
    for node in nodes:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
            key = node.targets[0].id
            if key in values:
                changes.append((node.lineno-1, node.end_lineno,
                    key + ' = ' + pprint.pformat(values[key], sort_dicts=False, width=90) + '\n'))
        if invoke and isinstance(node, ast.FunctionDef) and node.name == 'invoke':
            changes.append((node.lineno-1, node.end_lineno, 'def invoke(client):\n    return ' + invoke + '\n'))
    for start, end, replacement in sorted(changes, reverse=True):
        lines[start:end] = [replacement]
    text = ''.join(lines)
    if checker:
        text = text.replace('\ndef normalized(value):', '\n' + checker.strip() + '\n\n\ndef normalized(value):')
        text = text.replace('            assert normalized(raw.decode()) == SUCCESS',
            '            result = normalized(raw.decode())\n            check_result(result, raw.response.request)\n            assert result == SUCCESS')
    path.write_text(text, newline='\n')

metadata_check = '''
def check_result(result, request):
    from email.message import Message
    media = Message()
    media['content-type'] = result['mediaType']
    assert '/' in result['mediaType'] and '*' not in result['mediaType'], 'Expected concrete MIME type'
    assert media.get_content_type() == 'text/plain', 'Expected text attachment'
    assert result['filename'] == 'inspection.txt', 'Attachment filename differs from request'
    assert int(result['sizeBytes']) == len(b'Inspection evidence'), 'Attachment size differs from content'
'''
for op in ('get', 'upload'):
    content = {'rid': rid, 'filename': 'inspection.txt', 'sizeBytes': '19', 'mediaType': 'text/plain'}
    check = metadata_check
    if op == 'get':
        check += "    assert result['rid'] == request.url.path.rsplit('/', 1)[-1], 'Attachment RID differs from request'\n"
    else:
        check += "    assert result['filename'] == request.url.params['filename'], 'Attachment filename differs from request'\n    assert int(result['sizeBytes']) == len(request.content), 'Attachment size differs from content'\n"
    edit('Attachment', op, {'SUCCESS': content}, checker=check)
edit('Attachment', 'read', {'SUCCESS': b'Inspection evidence'})

schema_check = '''
def check_result(result, request):
    types = result.get('data', [result])
    for schema in types:
        assert schema['primaryKey'], 'Missing primary key'
        for key in schema['primaryKey']:
            assert key in schema['properties'], 'Primary key missing from properties'
            assert schema['properties'][key]['baseType'] == 'String', 'Expected string primary key'
        if schema['apiName'] == 'Asset':
            assert schema['properties']['status']['baseType'] == 'String'
            assert schema['properties']['inspectionDate']['baseType'] == 'LocalDate'
    if '/objectTypes/' in request.url.path:
        assert result['apiName'] == request.url.path.rsplit('/', 1)[-1], 'Object type differs from request'
'''
edit('ObjectType', 'get', {'SUCCESS': asset}, checker=schema_check)
edit('ObjectType', 'list', {'SUCCESS': {'data': [asset, facility]}}, checker=schema_check)
edit('ObjectType', 'get_outgoing_link_type', {'SUCCESS': link}, replacements=[('synthetic-value', 'facility')])
edit('ObjectType', 'list_outgoing_link_types', {'SUCCESS': {'data': [link]}})

for op in ('get', 'list'):
    check = '''
def check_result(result, request):
    objects = result.get('data', [result])
    for item in objects:
        props = item['properties']
        assert props['assetId'] == 'A-1', 'Missing or wrong Asset identity'
        assert props['status'] == 'ready'
        datetime.date.fromisoformat(props['inspectionDate'])
'''
    if op == 'get':
        check += "    assert result['properties']['assetId'] == request.url.path.rsplit('/', 1)[-1], 'Object key differs from request'\n"
    edit('OntologyObject', op, {'SUCCESS': obj if op == 'get' else {'data': [obj]}}, checker=check)
for op in ('get_linked_object', 'list_linked_objects'):
    check = '''
def check_result(result, request):
    for item in result.get('data', [result]):
        assert item['properties']['facilityId'] == 'F-1', 'Wrong linked target identity'
        assert item['properties']['name'] == 'North depot'
        assert 'assetId' not in item['properties'], 'Expected Facility target, not source Asset'
'''
    if op == 'get_linked_object':
        check += "    assert result['properties']['facilityId'] == request.url.path.rsplit('/', 1)[-1], 'Linked key differs from request'\n"
    replacements = [('link_type=\'synthetic-value\'', "link_type='facility'"),
                    ("/links/synthetic-value", "/links/facility"),
                    ("linked_object_primary_key='synthetic-value'", "linked_object_primary_key='F-1'"),
                    ("/facility/synthetic-value'", "/facility/F-1'")]
    edit('OntologyObject', op, {'SUCCESS': linked if op == 'get_linked_object' else {'data': [linked]}},
         checker=check, replacements=replacements)

body = {'query': {'field': 'properties.status', 'value': 'rea', 'type': 'prefix'},
        'fields': ['assetId', 'status']}
edit('OntologyObject', 'search', {'EXPECTED_BODY': body, 'SUCCESS': {'data': [
    {'properties': {'assetId': 'A-1', 'status': 'ready'}, 'rid': rid}], 'totalCount': '1'}},
    invoke=f"client.with_raw_response.search(ontology_rid={rid!r}, object_type='Asset', fields=['assetId', 'status'], query={body['query']!r}, request_timeout=30)",
    checker='''
def check_result(result, request):
    query = json.loads(request.content)['query']
    assert query['field'] == 'properties.status', 'Search field must resolve in Asset schema'
    for item in result['data']:
        assert item['properties']['assetId'], 'Missing result identity'
        assert item['properties']['status'].startswith(query['value']), 'Search result violates prefix'
''')
aggregation = [{'field': 'properties.assetId', 'name': 'distinctAssets', 'type': 'approximateDistinct'}]
groups = [{'field': 'properties.inspectionDate', 'duration': 'P1D', 'type': 'duration'}]
edit('OntologyObject', 'aggregate', {'EXPECTED_BODY': {'aggregation': aggregation, 'groupBy': groups},
    'SUCCESS': {'data': [{'group': {'properties.inspectionDate': '2026-10-01'},
                         'metrics': [{'name': 'distinctAssets', 'value': 1.0}]}]}},
    invoke=f"client.with_raw_response.aggregate(ontology_rid={rid!r}, object_type='Asset', aggregation={aggregation!r}, group_by={groups!r}, request_timeout=30)",
    checker='''
def check_result(result, request):
    body = json.loads(request.content)
    group = body['groupBy'][0]
    assert group['field'] == 'properties.inspectionDate', 'Duration grouping needs declared date field'
    assert group['duration'] == 'P1D', 'Expected ISO 8601 one-day duration'
    metric = body['aggregation'][0]
    assert metric['field'] == 'properties.assetId', 'Metric field missing from Asset schema'
    for bucket in result['data']:
        datetime.date.fromisoformat(bucket['group'][group['field']])
        assert bucket['metrics'][0]['name'] == metric['name'], 'Metric alias differs from request'
        value = bucket['metrics'][0]['value']
        assert isinstance(value, (int, float)) and value >= 0, 'Distinct count needs nonnegative numeric value'
''')
for op in ('get', 'list'):
    check = '''
def check_result(result, request):
    import re
    for schema in result.get('data', [result]):
        assert re.fullmatch(r'[0-9]+\\.[0-9]+\\.[0-9]+(?:-[A-Za-z0-9.-]+)?', schema['version']), 'Invalid FunctionVersion'
        assert schema['parameters']['assetId']['baseType'] == 'String'
        assert schema['parameters']['assetId']['required'] is True
        assert {field['name'] for field in schema['output']['fields']} == {'assetId', 'status'}
    if '/queryTypes/' in request.url.path:
        assert result['apiName'] == request.url.path.rsplit('/', 1)[-1], 'Query name differs from request'
'''
    edit('QueryType', op, {'SUCCESS': query if op == 'get' else {'data': [query]}},
         checker=check, replacements=[('synthetic-value', 'asset-status')])
