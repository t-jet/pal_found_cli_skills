import json
import pathlib
import subprocess

root = pathlib.Path(__file__).resolve().parents[2]
candidate = root / '.ept/tmp/feature015_integration'
proof = json.loads((root / '.ept/tmp/rest077_architect_probe_20261116.json').read_text())
lines = [
    'Independent architect approval, 2026-11-16. Reviewed implementation as architect, separate from its author. Decision: APPROVE CODEREVIEW-079 for candidate 693ce5f9bb48b42d9af6a515c4d9c4a49ba84bc4.',
    '',
    'Read current CLI Open instructions/DoD, all seven review comments, paired development readiness and QA dependency repair, UNITTEST-078 independent QA closure, document index, REST authoring contract, rest-and-sources and verification-and-delivery. No child Question or incoming Blocks link exists. DEV-078 previously reached Resolved and is now Blocked solely by this review, prior status Resolved. UNITTEST-078 is Closed.',
    '',
    'Freeze readback: clean candidate HEAD 693ce5f; all 23 example, eight guide, 23 structural-contract and 170 model-document hashes equal preserved independent architect probe. Test SHA256 remains 01e180383eaa903bb5f75510ff5a50145d179f3a2405b411f67f0645ea1b8930. Probe .ept/tmp/rest077_architect_probe_20261116.json has SHA256 b3a07bdb491f850fad3c223d5a31a79280d2371a0c32739f5e449187649d92b0. It records 23/23 signatures, RequestInfo wire expressions, six source-derived mode annotations, actual SDK example verify() passes, and 170 reachable model definitions with frozen-source AST equality and checked dependency links; failures=[]. Frozen SDK commit is 168d51910570b6966afa2320333ab36f6a3f7ccf (1.101.0/OpenAPI 1.1697.0). Durable semantic retest evidence is candidate maintainer/rest-domain-independent-review-077-current.json, including corrected-source findings and opaque aggregation variants. These checks support exact identities and behavior, rather than aggregate count alone.',
    '',
    'This completion pass independently read each operation purpose/recovery section and actual invocation below, plus important source/fixture/model interpretations. It reuses unchanged earlier independent review and unit evidence; it does not claim another full suite execution or new manual reading of every model definition. Paths below are relative to candidate .agents/skills/pal-found-dev/. SDK paths are relative to frozen release checkout.',
    '',
]
for row in proof['operations']:
    guide = row['guide'].replace('\\', '/').removeprefix('.agents/skills/pal-found-dev/')
    example = row['example'].replace('\\', '/').removeprefix('.agents/skills/pal-found-dev/')
    snippet = next(line.strip() for line in (candidate / row['example']).read_text().splitlines()[row['invoke_line']:] if 'return client.' in line)
    lines.append(f"- PASS {row['id']}: {guide}:{row['guide_operation_line']}; {example}:{row['invoke_line']}; source {row['source_path']}:{row['source_method_line']}. Actual snippet: `{snippet}`. Signature, wire fields, fixture and all six exposed return modes match independent source proof; semantic operation purpose and outcome guidance accepted.")
lines += [
    '',
    'Specific judgments: Action.md:44/72/101 distinguishes application, batch limits and validation. Source ActionClient.validate states existing-object checks are skipped; VALID therefore does not authorize assuming successful application. Attachment.md:81 preserves the frozen SDK limitation: upload header dictionary contains Content-Type twice and final value is */*. The example supplies content_type=application/octet-stream but checks actual */* serialization; mocked success cannot establish live endpoint acceptance. ObjectType.md:35 and Ontology.md:12 preserve v1 primaryKey list and absent titleProperty, separate v2 schema, and API-version versus storage-backend distinctions. OntologyObject.md:43 and aggregate.py:51 retain group Dict[str, Any] labels/values as opaque until tenant schema confirmation; the code iterates bucket["group"] without assuming request-field mapping or date boundary semantics. QueryType.md:26 defines asset-status, required assetId string, version 1.2.3 and struct result; Query/execute.py:31 supplies that parameter and checks matching synthetic result. Source silence about universal scopes, idempotency and named errors remains explicit.',
    '',
    'Mode judgment: contracts/v1/ontologies/OntologyObject/list.md response-mode table preserves ordinary async core.AsyncResourceIterator versus raw Awaitable[AsyncApiResponse[ListObjectsResponse]] and AsyncStreamingContextManager[Awaitable[ListObjectsResponse]]. tests/test_offline_rest_077.py:320 handles async context, raw await and direct async iteration separately. Lines 438/489/531 exercise one-request timeout with cause, interrupted stream cleanup and cancellation cleanup. Seven paged operations have finite cases; generic 403 remains exercised despite empty named-error unions. Accepted UNITTEST QA comment 20261116-150428-@qa-engineer records 553 dedicated and 73 selected shared passes at identical bytes. No line-coverage percentage or OS-wide isolation claim.',
    '',
    'Open-to-Closed DoD met: indexed documents consulted, independent source and semantic review complete with concrete paths/lines/snippets, questions clear, findings and approval recorded. Remove only verified LINK-02067 (CODEREVIEW-079 Blocks DEV-078), preserving Contains and RelatesTo links, then close using actual Open-to-Closed transition. Development prior-status restoration and formal QA remain with their responsible actors.',
    '',
    'time_spent_hours=0.000294817722222231 records only preserved measured independent machine probe runtime 1.0613438000000315 seconds / 3600. Human/contributor historical effort and this completion-pass labor are unmeasured; 12h estimate remains unchanged. Formal TESTCASE/TESTEXEC, REST093 acceptance, live Foundry verification and publication070 are separate.',
]
text = '\n\n'.join(lines).replace('\n', '\\n')
command = ['python', '.ept/tools/tracker/tracker_cli.py', 'comment', 'create', 'CODEREVIEW-079', '--subject', 'Independent architect approval with per-operation source evidence 2026-11-16', '--text', text, '--author', 'architect']
raise SystemExit(subprocess.run(command, cwd=root).returncode)
