from pathlib import Path
import json, hashlib
p=Path('.ept/tmp/rest077_formal_corrected_20261116');h=p/'rest077_formal_execute.py';s=h.read_text()
s=s.replace("def sha(p):", "def evidence_json(value):\n    if isinstance(value,bytes): return {'$bytes':value.decode()}\n    raise TypeError(type(value).__name__)\n\ndef sha(p):",1)
s=s.replace("args=parser.parse_args();data=", "started=time.perf_counter();args=parser.parse_args();data=",1)
s=s.replace("'freeze_sha256':sha(FREEZE)},indent=2)","'freeze_sha256':sha(FREEZE),'feature_sha256':sha(HERE/'rest077_formal_cases.feature'),'elapsed_seconds':time.perf_counter()-started},indent=2,default=evidence_json)")
s=s.replace("record(c,'finite_pages_'+status,pages=len(calls),retained_items=len(rows),continuation=tokens[-1] if tokens else None)","record(c,'finite_pages_'+status,pages=len(calls),retained_items=len(rows),retained_rows=rows,continuation=tokens[-1] if tokens else None)")
s=s.replace("    for c in data['operations']:\n        sync_modes", "    for c in data['operations']:\n        expect_guard_failure(lambda:assert_runtime(c,bytearray(b'wrong') if c['runtime_types']['response']=='builtins.bytes' else materialize(c['response'])))\n        if c['runtime_types']['element']: expect_guard_failure(lambda:assert_runtime(c,c['response']['data'][0],True))\n        record(c,'runtime_model_identity_negative_control')\n        sync_modes")
h.write_text(s)
f=p/'rest077_formal_cases.feature';s=f.read_text().replace('And raw sync/async consumer and malformed JSON decode failures close resources','And raw sync/async consumer failures and applicable malformed JSON decode failures close resources');f.write_text(s)
cases=p/'rest077_formal_cases.json';data=json.loads(cases.read_text());freeze=json.loads((p/'rest077_assets_freeze.json').read_text())
for resource,attr in data['policy_attribution'].items():
    attr['reader_sha256']=freeze['assets'][str(Path(attr['reader_asset']))]
    attr['primary_source_methods']=[{'operation':c['operation'],'path':c['source']['path'],'sha256':c['source']['sha256'],'line':c['source']['methods'][resource+'Client']['line'],'doc_sha256':hashlib.sha256(c['source']['methods'][resource+'Client']['doc'].encode()).hexdigest()} for c in data['operations'] if c['operation'].split('.')[2]==resource]
data['review_corrections']['R077-06']+=' Independent source-SDK request capture uses invocation literal inputs only, compares observed method/path/query/body/headers without loading distributed expected constants; corruption retains payload structure.'
cases.write_text(json.dumps(data,indent=2)+'\n')
