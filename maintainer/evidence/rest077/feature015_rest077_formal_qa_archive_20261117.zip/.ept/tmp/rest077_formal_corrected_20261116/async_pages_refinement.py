from pathlib import Path
import json
p=Path('.ept/tmp/rest077_formal_corrected_20261116');h=p/'rest077_formal_execute.py';s=h.read_text()
a=s.index('\ndef corrupt_decoded(value):')
s=s[:a]+'''
async def async_finite_pages(c,repeat=False,limit=3):
    calls=[];responses=[];tokens=[];rows=[];status='complete'
    def handler(req):
        index=len(calls);assert index<2,'Unbounded async pager'
        wire_check(req,c,'qa077-next' if index else None);calls.append(req)
        r=reply(page_payload(c,index,'qa077-next' if index==0 or repeat else None));responses.append(r);return r
    async with async_client(c,handler) as (client,transport):
        for page_no in range(limit):
            kwargs=copy.deepcopy(c['kwargs'])
            if tokens: kwargs['page_token']=tokens[-1]
            response=await invoke(client,c,'raw',kwargs)
            try: page=typed_normalize(c,response.decode())
            finally: await response.aclose()
            rows.extend(page['data']);nxt=page.get('nextPageToken')
            if not nxt: break
            if nxt in tokens: status='repeated-token';break
            tokens.append(nxt)
        else: status='page-limit'
    assert len(calls)==(1 if limit==1 else 2) and len(rows)==len(calls)
    assert status==('page-limit' if limit==1 else 'repeated-token' if repeat else 'complete')
    assert all(r.is_closed for r in responses) and transport.is_closed
    if status=='complete': assert rows[0]!=rows[1]
    record(c,'async_finite_pages_'+status,pages=len(calls),retained_rows=rows,continuation=tokens[-1] if tokens else None)
''' +s[a:]
s=s.replace("await async_pager(c);await bounded_items(c)","await async_pager(c);await bounded_items(c);await async_finite_pages(c);await async_finite_pages(c,repeat=True);await async_finite_pages(c,limit=1)")
h.write_text(s)
cases=p/'rest077_formal_cases.json';data=json.loads(cases.read_text())
data['oracle_method']='Independent literal Flight/Airport expectations derive from frozen SDK AST, model fields and documentation. Register supplies identities and asset locations. Distributed verify executes separately as acceptance coverage; its expected constants never supply source-oracle fixtures. Its invocation literal inputs are observed through a separate frozen-source SDK client to check actual wire behavior.'
data['review_corrections']['R077-04']+=' All seven explicit response pagers also execute async two-page, repeated-token and page-limit cases with preserved rows/token; search uses awaited response, never automatic iteration.'
cases.write_text(json.dumps(data,indent=2)+'\n')
