from pathlib import Path
import json
p=Path('.ept/tmp/rest077_formal_corrected_20261116');h=p/'rest077_formal_execute.py';s=h.read_text()
s=s.replace('import sys\n','import sys\nsys.dont_write_bytecode=True\n',1)
s=s.replace("if self.corrupt: return b'corrupted-by-independent-QA' if type(value) is bytes else {'independent_QA_corruption':True}","if self.corrupt: return corrupt_decoded(normalize(value))")
# Keep payload shape intact so assertion, not missing-key lookup, demonstrates detection.
a=s.index('\ndef distributed_examples(data,freeze):')
s=s[:a]+'''
def corrupt_decoded(value):
    value=copy.deepcopy(value)
    if type(value) is bytes: return value+b'QA-corruption'
    if isinstance(value,dict):
        if not value: return {'QA_corruption':True}
        key=next(iter(value));value[key]=corrupt_decoded(value[key]);return value
    if isinstance(value,list):
        if not value: return ['QA-corruption']
        value[0]=corrupt_decoded(value[0]);return value
    if isinstance(value,str): return value+'QA-corruption'
    if isinstance(value,(int,float)): return value+1
    return 'QA-corruption'
''' +s[a:]
needle="        assert kwargs.pop('request_timeout')==30\n"
replacement=needle+'''        baseline=[]
        def source_transport(req):
            baseline.append(req);return reply(c['response'])
        with sync_client(c,source_transport) as (client,_):
            raw=getattr(client.with_raw_response,method)(**kwargs,request_timeout=30)
            raw.close()
        assert len(baseline)==1
        source_request=baseline[0]
        actual_resource=module['mock_resource']
        @contextmanager
        def checked_resource(cls,handler):
            def independently_checked(req):
                assert req.method==source_request.method
                assert req.url.path==source_request.url.path
                assert req.url.params==source_request.url.params
                assert req.content==source_request.content
                for header in ['accept','content-type','content-length']:
                    assert req.headers.get(header)==source_request.headers.get(header)
                assert req.headers['authorization']=='Bearer offline-fixture-token'
                return handler(req)
            with actual_resource(cls,independently_checked) as client: yield client
        module['verify'].__globals__['mock_resource']=checked_resource
'''
s=s.replace(needle,replacement)
s=s.replace("assert approval['cases_sha256']==sha(CASES) and approval['harness_sha256']==sha(__file__)","assert approval['cases_sha256']==sha(CASES) and approval['harness_sha256']==sha(__file__)\n        assert approval['feature_sha256']==sha(HERE/'rest077_formal_cases.feature') and approval['freeze_sha256']==sha(FREEZE)")
h.write_text(s)
f=p/'rest077_formal_cases.feature';s=f.read_text().replace('    And OSv1 eventual visibility differs from OSv2 immediate visibility','    And frozen SDK documentation states OSv1 eventual visibility and OSv2 post-completion visibility\n    And no server visibility timing is executed').replace('    And new unattached upload expires after one hour','    And frozen SDK documentation states new unattached upload removal after one hour').replace('    And previously mapped disconnected attachment cleanup is biweekly','    And frozen SDK documentation states disconnected attachment cleanup is biweekly\n    And no server retention timer or cleanup is executed')
f.write_text(s)
print('Corrected negative payload preserves shape; independent source SDK wire observation added')
