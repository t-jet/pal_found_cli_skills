from pathlib import Path
import json
p=Path('.ept/tmp/rest077_formal_corrected_20261116')
h=p/'rest077_formal_execute.py'
s=h.read_text()
s=s.replace('import argparse','import ast\nimport runpy\nimport sys\nimport time\nimport argparse',1)
s=s.replace("AUTHOR='/root/rest077_formal_cases_prepare_20261116'","AUTHOR='/root/rest077_case_correct_20261116'")
# Preserve type identity before any value normalization.
point=s.index('\ndef semantic(c,value):')
s=s[:point]+'''
def assert_runtime(c,value,element=False):
    binding=c['runtime_types']['element' if element else 'response']
    cls=bytes if binding=='builtins.bytes' else getattr(importlib.import_module(binding.rsplit('.',1)[0]),binding.rsplit('.',1)[1])
    assert type(value) is cls, (c['operation'], 'runtime type',type(value),cls)
    return value

def typed_normalize(c,value,element=False):
    return normalize(assert_runtime(c,value,element))
''' +s[point:]
s=s.replace('value=normalize(result.decode())','value=typed_normalize(c,result.decode())')
s=s.replace('value=[normalize(v) for v in result]','value=[typed_normalize(c,v,True) for v in result]')
s=s.replace('else: value=normalize(result)','else: value=typed_normalize(c,result)')
s=s.replace('value=[normalize(v) async for v in result]','value=[typed_normalize(c,v,True) async for v in result]')
s=s.replace('else: value=normalize(await result)','else: value=typed_normalize(c,await result)')
# Retain async failure responses and test invalid timeout before any HTTP.
s=s.replace("calls=[]\n        def handler(req):\n            calls.append(req);wire_check(req,c)\n            if failure=='timeout': raise httpx.ReadTimeout('qa077 async timeout',request=req)\n            return httpx.Response(403,json=", "calls=[];responses=[]\n        def handler(req):\n            calls.append(req);wire_check(req,c)\n            if failure=='timeout': raise httpx.ReadTimeout('qa077 async timeout',request=req)\n            response=httpx.Response(403,json=")
s=s.replace("'errorInstanceId':'qa077-denied','parameters':{}})\n        async with async_client", "'errorInstanceId':'qa077-denied','parameters':{}})\n            responses.append(response);return response\n        async with async_client",1)
s=s.replace("assert len(calls)==1;record(c,'async_'+failure,requests=1)","assert len(calls)==1 and all(r.is_closed for r in responses);record(c,'async_'+failure,requests=1,response_closed=True)")
s=s.replace("    responses=[];entered=asyncio.Event()", """    calls=[]
    async with async_client(c,lambda req:calls.append(req)) as (client,_):
        try:
            value=getattr(client,c['operation'].split('.')[-1])(**materialize(c['kwargs']),request_timeout=0)
            if hasattr(value,'__aiter__'): value=[v async for v in value]
            else: await value
        except pydantic.ValidationError: pass
        else: raise AssertionError('Async zero timeout accepted')
    assert calls==[];record(c,'async_invalid_timeout_no_http')
    responses=[];entered=asyncio.Event()""")
# Replace tautological guards with reader-derived decision functions and independent controls.
a=s.index('    # Typed models permit arbitrary object maps;')
b=s.index('    calls=[]\n    def lifecycle_handler',a)
s=s[:a]+'''    schema=data['semantic_schema']['Flight']
    good=copy.deepcopy(lookup['v1.ontologies.OntologyObject.get']['response'])
    bad=copy.deepcopy(good);bad['properties']['flightId']=77
    def schema_contract(guard):
        assert guard(good,schema)['decision']=='use'
        rejected=guard(bad,schema)
        assert rejected['decision']=='stop' and rejected['retained']==bad
    schema_contract(schema_guard)
    expect_guard_failure(lambda: schema_contract(lambda value,schema: {'decision':'use','retained':value}))
    approved={'confirmedLabel':str}
    valid={'group':{'confirmedLabel':'2026-10-01'},'metrics':[{'name':'flightCount','value':1.0}]}
    unknown={'group':{'unconfirmed-server-label':{'raw':7}},'metrics':valid['metrics']}
    malformed={'group':{'confirmedLabel':{'raw':7}},'metrics':valid['metrics']}
    def group_contract(guard):
        assert guard(valid,approved)['decision']=='use'
        for value in [unknown,malformed]:
            decision=guard(value,approved)
            assert decision['decision']=='stop' and decision['retained']==value and decision['derived'] is None
    group_contract(group_guard)
    expect_guard_failure(lambda:group_contract(lambda value,schema:{'decision':'use','retained':value,'derived':7}))
    record('F077-SCHEMA','reader_metadata_guard_valid_reject_and_bypass_control')
    record('F077-AGGREGATION','confirmed_application_mapping_guard_and_bypass_control',server_group_values='opaque Any; no server policy invented')
''' +s[b:]
s=s.replace("record('F077-POLICY',resource+'_local_lifecycle_source_silence')", "record('F077-POLICY',resource+'_documentation_only',executed_server_policy=False,source=data['policy_attribution'][resource])")
a=s.index('\nasync def run(data):')
s=s[:a]+'''
def expect_guard_failure(check):
    try: check()
    except AssertionError: return
    raise AssertionError('Negative control failed to detect bypassed guard')

def schema_guard(value,schema):
    props=value.get('properties',{})
    valid=all(key in props and type(props[key]) is str for key in schema['primaryKey'])
    valid=valid and all(name not in props or definition['baseType']!='String' or type(props[name]) is str for name,definition in schema['properties'].items())
    return {'decision':'use' if valid else 'stop','retained':copy.deepcopy(value)}

def group_guard(bucket,confirmed):
    # This is an application-approved mapping. SDK Dict[str, Any] defines no mapping.
    valid=all(label in bucket['group'] and type(bucket['group'][label]) is typ for label,typ in confirmed.items())
    return {'decision':'use' if valid else 'stop','retained':copy.deepcopy(bucket),'derived':bucket['metrics'][0]['value'] if valid else None}

def uncertain_writes(data):
    lookup={c['operation']:c for c in data['operations']}
    for name in ['apply','apply_batch','upload']:
        c=lookup['v1.ontologies.'+('Attachment.' if name=='upload' else 'Action.')+name]
        calls=[];observations=[];server_effects=[]
        def lost_response(req):
            wire_check(req,c);calls.append(req)
            # Server accepted synthetic work before response was lost. Batch is partial.
            server_effects.append('QA-077')
            raise httpx.ReadTimeout('response lost after synthetic acceptance',request=req)
        state={'outcome':'unknown','request':copy.deepcopy(c['kwargs']),'partial':[], 'replay':False}
        with sync_client(c,lost_response) as (client,_):
            try: invoke(client,c)
            except ReadTimeout: pass
            else: raise AssertionError('Lost response must remain uncertain')
        if name=='upload':
            # Lost upload supplied no RID. This API has no lookup by upload attempt ID.
            state.update(decision='escalate-no-rid',reads=0)
        else:
            read=lookup['v1.ontologies.OntologyObject.get']
            # Independent authorized effect reads are observations, never proof of causality.
            keys=['QA-077','QA-078'] if name=='apply_batch' else ['QA-077']
            for key in keys:
                kwargs=copy.deepcopy(read['kwargs']);kwargs['primary_key']=key
                def observe(req):
                    assert req.method=='GET' and req.url.path.endswith('/'+key)
                    observations.append(req)
                    value=copy.deepcopy(read['response']);value['properties']['flightId']=key
                    value['properties']['status']='scheduled' if key in server_effects else 'pending'
                    return reply(value)
                with sync_client(read,observe) as (client,_):
                    item=normalize(invoke(client,read,kwargs=kwargs));state['partial'].append(item)
            state.update(decision='escalate-unresolved-causality',reads=len(observations))
            assert state['partial'][0]['properties']['status']=='scheduled'
            if name=='apply_batch': assert state['partial'][1]['properties']['status']=='pending'
        assert state['outcome']=='unknown' and state['replay'] is False
        assert len(calls)==1 and state['reads']<=2 and state['request']==c['kwargs']
        record(c,'lost_response_bounded_reconciliation_no_replay',state=state,synthetic_only=True)

async def extra_lifetimes(c):
    # Explicit checks complement six success modes. No synchronous cancellation claim.
    for asynchronous in [False,True]:
        for mode in ['raw','streaming']:
            responses=[]
            def handler(req):
                r=reply(c['response']);responses.append(r);return r
            if asynchronous:
                async with async_client(c,handler) as (client,transport):
                    try:
                        result=invoke(client,c,mode)
                        if mode=='raw':
                            raw=await result
                            try: assert_runtime(c,raw.decode());raise ValueError('consumer failed')
                            finally: await raw.aclose()
                        else:
                            async with result: raise ValueError('consumer failed')
                    except ValueError as exc: assert str(exc)=='consumer failed'
            else:
                with sync_client(c,handler) as (client,transport):
                    try:
                        raw=invoke(client,c,mode)
                        if mode=='raw':
                            try: assert_runtime(c,raw.decode());raise ValueError('consumer failed')
                            finally: raw.close()
                        else:
                            with raw: raise ValueError('consumer failed')
                    except ValueError as exc: assert str(exc)=='consumer failed'
            assert responses and all(r.is_closed for r in responses) and transport.is_closed
            record(c,('async_' if asynchronous else 'sync_')+mode+'_consumer_exception_cleanup')
    if c['operation'].endswith('Attachment.read'): return
    for asynchronous in [False,True]:
        responses=[]
        def broken(req):
            r=httpx.Response(200,stream=httpx.ByteStream(b'{invalid-json'),headers={'Content-Type':'application/json'});responses.append(r);return r
        failed=False
        if asynchronous:
            async with async_client(c,broken) as (client,transport):
                raw=await invoke(client,c,'raw')
                try: raw.decode()
                except Exception: failed=True
                finally: await raw.aclose()
        else:
            with sync_client(c,broken) as (client,transport):
                raw=invoke(client,c,'raw')
                try: raw.decode()
                except Exception: failed=True
                finally: raw.close()
        assert failed and responses[0].is_closed and transport.is_closed
        record(c,('async_' if asynchronous else 'sync_')+'raw_decode_failure_cleanup')

async def bounded_items(c):
    for asynchronous in [False,True]:
        calls=[];responses=[];rows=[];continuation=None
        def handler(req):
            assert not calls,'Item limit must prevent next request'
            wire_check(req,c);calls.append(req)
            payload=page_payload(c,0,'qa077-next')
            payload['data'].append(copy.deepcopy(payload['data'][0]))
            response=reply(payload);responses.append(response);return response
        if asynchronous:
            async with async_client(c,handler) as (client,transport):
                raw=await invoke(client,c,'raw')
                try: page=normalize(raw.decode())
                finally: await raw.aclose()
        else:
            with sync_client(c,handler) as (client,transport):
                raw=invoke(client,c,'raw')
                try: page=normalize(raw.decode())
                finally: raw.close()
        for item in page['data']:
            if len(rows)==1: break
            rows.append(item)
        continuation=page.get('nextPageToken')
        retained={'items':rows,'unconsumed':page['data'][len(rows):],'continuation':continuation,'status':'item-limit'}
        assert len(rows)==1 and len(retained['unconsumed'])==1 and continuation=='qa077-next'
        assert len(calls)==1 and responses[0].is_closed and transport.is_closed
        record(c,('async_' if asynchronous else 'sync_')+'explicit_item_bound_partial_retention',retained=retained)
    if c['runtime_types']['element'] is None: return
    calls=[];responses=[]
    def handler(req):
        assert not calls,'Async early stop fetched another page'
        calls.append(req);r=reply(page_payload(c,0,'qa077-next'));responses.append(r);return r
    async with async_client(c,handler) as (client,transport):
        iterator=invoke(client,c);rows=[]
        assert hasattr(iterator,'__aiter__') and not inspect.isawaitable(iterator)
        async for item in iterator:
            rows.append(typed_normalize(c,item,True));break
    assert len(calls)==len(rows)==1 and responses[0].is_closed and transport.is_closed
    record(c,'async_automatic_iterator_early_stop')

def distributed_examples(data,freeze):
    root=Path(freeze['skill_root'])
    for c in data['operations']:
        resource,method=c['operation'].split('.')[-2:]
        path=root/f'examples/rest/077/v1/ontologies/{resource}/{method}.py'
        module=runpy.run_path(str(path),run_name='rest077_case_example')
        fn=module['invoke'];tree=ast.parse(inspect.getsource(fn))
        call=next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr==method)
        assert isinstance(call.func.value,ast.Attribute) and call.func.value.attr=='with_raw_response'
        assert getattr(module[resource+'Client'],method)==getattr(client_class(c),method)
        kwargs={k.arg:ast.literal_eval(k.value) for k in call.keywords}
        assert kwargs.pop('request_timeout')==30
        # Invoke the unmodified distributed verify, but check runtime SDK identity before decode.
        original=fn;seen=[]
        class ObservedRaw:
            def __init__(self,raw,corrupt=False): self.raw=raw;self.corrupt=corrupt
            def decode(self):
                value=self.raw.decode();assert_runtime(c,value);seen.append(type(value).__name__)
                if self.corrupt: return b'corrupted-by-independent-QA' if type(value) is bytes else {'independent_QA_corruption':True}
                return value
            def close(self): self.raw.close()
        # Function globals returned by run_path are the shared execution dictionary.
        namespace=module['verify'].__globals__
        namespace['invoke']=lambda client:ObservedRaw(original(client))
        module['verify']()
        assert seen
        namespace['invoke']=lambda client:ObservedRaw(original(client),True)
        expect_guard_failure(module['verify'])
        record(c,'distributed_example_execute_and_corrupt_decode_control',asset=str(path.relative_to(root)),sha256=sha(path),runtime_types=seen,kwargs=kwargs)
''' +s[a:]
s=s.replace("sync_modes(c);await async_modes(c);sync_adverse(c);await async_adverse(c)","sync_modes(c);await async_modes(c);sync_adverse(c);await async_adverse(c);await extra_lifetimes(c)")
s=s.replace("finite_pages(c);finite_pages(c,repeat=True);finite_pages(c,limit=1);sync_pager(c);await async_pager(c)","finite_pages(c);finite_pages(c,repeat=True);finite_pages(c,limit=1);sync_pager(c);await async_pager(c);await bounded_items(c)")
s=s.replace('    semantic_boundaries(data)\n','    semantic_boundaries(data);uncertain_writes(data);distributed_examples(data,json.loads(FREEZE.read_text()))\n')
h.write_text(s)
# Freeze source-derived runtime names independently from existing source annotations.
data=json.loads((p/'rest077_formal_cases.json').read_text())
for c in data['operations']:
    resource=c['operation'].split('.')[2]
    binding=c['source']['methods'][resource+'Client']
    response=binding['request']['response_type']
    response='builtins.bytes' if response=='bytes' else response.replace('ontologies_models.','foundry_sdk.v1.ontologies.models.').replace('core_models.','foundry_sdk.v1.core.models.')
    element=None
    if 'ITERATOR' in binding['request']['response_mode']:
        element=binding['return'].split('[',1)[1].rstrip(']').replace('ontologies_models.','foundry_sdk.v1.ontologies.models.')
    c['runtime_types']={'response':response,'element':element}
data['author_identity']='/root/rest077_case_correct_20261116'
data['review_corrections']={
 'R077-01':'Executable reader-derived metadata and approved application mapping guards; valid, mutated, bypass controls. SDK group values stay opaque.',
 'R077-02':'Actual SDK lost-response mutation transport; bounded authorized object reads retain partial observations; no RID upload escalates; no mutation replay. Server retention/consistency is documentation only.',
 'R077-03':'Exact runtime ordinary/raw response and iterator element class before normalization; byte identity for attachment content.',
 'R077-04':'Seven explicit item-bound partial-retention tests in sync/async; six automatic iterator early stops in sync/async; search is explicit response pager.',
 'R077-05':'Six success modes close; ordinary generic403/timeout sync/async; sync/async raw consumer/decode failure; sync/async streaming exception; async streaming cancellation; sync/async zero-timeout. No all-mode cancellation claim.',
 'R077-06':'Execute each unmodified frozen distributed verify under denied sockets, independently inspect actual SDK invocation AST/runtime result type, and corrupt decoded result to prove example assertions fail.'}
data['policy_attribution']={r:{'reader_asset':f'references/rest/v1/ontologies/{r}.md','primary_sources':[c['source']['path'] for c in data['operations'] if c['operation'].split('.')[2]==r], 'scope':'Review frozen SDK method documentation and reader prose; no runtime retention/visibility claim'} for r in ['Action','Attachment','OntologyObject']}
(p/'rest077_formal_cases.json').write_text(json.dumps(data,indent=2)+'\n')
f=p/'rest077_formal_cases.feature';feature=f.read_text().replace('And response and client close on completion, exception and cancellation','And response and client close on successful completion\n    And ordinary sync/async 403 and timeout preserve failure identity\n    And raw sync/async consumer and malformed JSON decode failures close resources\n    And streaming sync/async consumer exceptions and async cancellation close resources\n    And sync/async zero timeout rejects before HTTP')
feature+='''
  Scenario: R077-01 application guards reject malformed tenant values
    Given independent Flight metadata and a separately confirmed application label mapping
    When valid and mutated object and group payloads enter reader-derived decision guards
    Then valid values permit use and mismatches stop with original response retained
    And bypassing either guard makes the corresponding check fail

  Scenario: R077-02 uncertain mutation recovery
    Given one synthetic accepted apply, partial apply_batch, or upload whose HTTP response is lost
    When actual SDK transport raises read timeout with retries disabled
    Then action effect observations use at most two authorized object reads
    And observations remain partial and causality uncertain with no mutation replay
    And lost upload with no RID escalates with zero unsupported lookup requests
    And retention and consistency claims are reviewed against frozen source documentation only

  Scenario: R077-04 finite items and response paging
    Given six automatic iterators and one explicit SearchObjectsResponse pager
    When each explicit response pager has item limit one and unread data plus continuation
    Then one item is returned and unread items plus token remain available
    And six async automatic iterators stop after one item without fetching next page

  Scenario: R077-06 runnable distributed examples
    When every frozen distributed verify executes with sockets denied
    Then actual invocation AST resolves to correct SDK resource and method
    And exact runtime decoded model or bytes identity matches source contract
    And independently corrupting each decoded result makes example assertion fail
'''
f.write_text(feature)
freeze=json.loads((p/'rest077_assets_freeze.json').read_text())
freeze['case_revision']='R077-01 through R077-06 correction candidate; fresh independent review required'
freeze['original_freeze_sha256']='dedb0fab0b3bc90ee0e67b41b14642af1220f21d8f561a119ac09858c2afe99a'
(p/'rest077_assets_freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print('Corrected candidate written; source and reader asset hash maps unchanged')
