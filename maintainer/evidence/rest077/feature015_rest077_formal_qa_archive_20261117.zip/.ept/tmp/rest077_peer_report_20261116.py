import json
import hashlib
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT / '.ept/tmp/rest077_formal_20261116'
data = json.loads((BASE / 'rest077_formal_cases.json').read_text())
audit = json.loads((ROOT / '.ept/tmp/rest077_peer_inspection_20261116.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
findings = [
    {'id': 'R077-01', 'severity': 'major', 'scope': 'F077-SCHEMA; F077-AGGREGATION', 'location': 'rest077_formal_execute.py:291-298', 'finding': 'The wrong-primary-key test only checks Python isinstance on a new literal. The unknown-label test only checks that a chosen string is absent. Neither invokes a validator or derived computation, so both still pass if reader logic accepts the bad input or guesses a group label.', 'required_fix': 'Run an actual schema/aggregation guard against valid and invalid payloads. Assert valid behavior and rejection/stop with retained uninterpreted data. Add a negative control that removes or bypasses each guard and makes the review check fail.'},
    {'id': 'R077-02', 'severity': 'major', 'scope': 'F077-LIFECYCLE; F077-01; F077-02; F077-08', 'location': 'rest077_formal_execute.py:281-321', 'finding': 'The lifecycle checks cover INVALID validate -> no apply and VALID validate -> 403. Uncertain-write reconciliation, retention cleanup and storage visibility are checked only by finding prose tokens. No uncertain-result state, bounded status/effect read, partial outcome, or explicit stop-before-replay is exercised. apply_batch and upload have no safe mutation recovery scenario.', 'required_fix': 'Add bounded fake-HTTP lifecycle cases for uncertain Action.apply/apply_batch and Attachment.upload outcomes. Preserve uncertainty and partial results, exercise supported reconciliation reads or explicit escalation when no supported read can resolve it, and assert no blind mutation replay. Keep retention/consistency statements as reviewed documentation assertions, with exact source attribution rather than claiming executable validation.'},
    {'id': 'R077-03', 'severity': 'major', 'scope': 'F077-01 through F077-23', 'location': 'rest077_formal_execute.py:37-39;113-165', 'finding': 'normalize() discards runtime model identity before assertions. A dict with the same fields can pass although the frozen SDK contract requires a specific response model or iterator element type. JSON records base return annotations but harness does not assert those types.', 'required_fix': 'Assert ordinary/raw decoded model classes against independently frozen expected classes before normalization; assert iterator element model class and bytes for Attachment.read. Preserve async iterator versus awaitable versus context-manager checks.'},
    {'id': 'R077-04', 'severity': 'major', 'scope': 'F077-05; F077-11; F077-12; F077-18; F077-19; F077-20; F077-23', 'location': 'rest077_formal_cases.feature finite paging scenarios; rest077_formal_execute.py:237-279', 'finding': 'Gherkin promises page/item bounds and one-item stop for every paged operation. finite_pages implements a page limit only. search has no one-item stop; async automatic iterators have no early-stop case. Source exposes six automatic iterators, while search returns an awaited SearchObjectsResponse and requires explicit page_token continuation.', 'required_fix': 'Implement meaningful independent item-limit and partial-result retention checks, async early stop for the six iterators, and explicit bounded search continuation/early-stop tests. Make Gherkin state the actual six-iterator plus one explicit-pager distinction.'},
    {'id': 'R077-05', 'severity': 'major', 'scope': 'F077-01 through F077-23', 'location': 'rest077_formal_cases.feature response/client close clause; rest077_formal_execute.py:168-221', 'finding': 'Each six-mode scenario claims response/client close on completion, exception and cancellation. Harness checks successful six-mode closure, sync streaming consumer exception, and async streaming cancellation. It does not check raw decode/consumer failure cleanup, async streaming consumer exception, sync raw decode failure, or async invalid_timeout before HTTP. async_adverse does not retain 403 responses to assert response closure.', 'required_fix': 'Add the promised adverse lifetime checks for applicable modes, or split Gherkin so each cleanup claim maps precisely to an implemented check. Assert async 403 response closure and zero-timeout rejection before HTTP.'},
    {'id': 'R077-06', 'severity': 'major', 'scope': 'formal execution acceptance boundary', 'location': 'rest077_formal_execute.py:338-348; all distributed example asset bindings', 'finding': 'The harness hashes distributed examples but never executes or semantically inspects their invocation/assertion logic. A broken distributed example can pass this harness after a new freeze even though reader-runnable examples are an explicit acceptance requirement. The successful 553-test unit review is separate evidence and cannot silently fill this formal case gap.', 'required_fix': 'Add formal cases that run every frozen distributed example under denied external transports and independent source/semantic expectations, or explicitly bind an independently reviewed executable example-check suite as a formal prerequisite with its immutable hashes and results. Keep source-oracle SDK tests as separate checks.'},
]
per_case = []
for c, a in zip(data['operations'], audit['per_case']):
    ids = ['R077-03', 'R077-05', 'R077-06']
    if c['paged']:
        ids.append('R077-04')
    if c['operation'] in ['v1.ontologies.Action.apply', 'v1.ontologies.Action.apply_batch', 'v1.ontologies.Attachment.upload']:
        ids.append('R077-02')
    if c['operation'] in ['v1.ontologies.OntologyObject.get', 'v1.ontologies.OntologyObject.aggregate']:
        ids.append('R077-01')
    per_case.append({'case_id': c['case_id'], 'operation': c['operation'], 'source_literal_contract_review': 'PASS', 'tag_installed_ast_equal': a['tag_installed_ast_equal'], 'source_bindings': a['bindings'], 'literal_body_verification': 'Actual SDK request matched independently authored literal body during CASE-REVIEW-DRYRUN; source RequestInfo body expression independently matched frozen tag.', 'mode_checks': c['modes'], 'generic_403_and_timeout': 'PASS in provisional dry run', 'declared_named_errors': [], 'case_approval': 'CHANGES_REQUIRED', 'findings': ids})
report = {
    'reviewer_identity': '/root/rest077_case_peer_review_20261116',
    'author_identity': data['author_identity'],
    'review_kind': 'INDEPENDENT_TESTCASE_PEER_REVIEW',
    'disposition': 'CHANGES_REQUIRED',
    'formal_execution': False,
    'testcase_closed': False,
    'testexec_prerequisites_verified': False,
    'tracker_mutations': [],
    'scope': {'story': 'DEV-STORY-077', 'testcase': 'TESTCASE-078', 'testexec': 'TESTEXEC-078', 'operations': 23, 'mode_success_checks': 138, 'paged_operations': 7, 'automatic_iterators': 6, 'explicit_paged_responses': ['v1.ontologies.OntologyObject.search'], 'named_error_unions': 'Zero named throwable_errors for all 23 sync and async source methods. Generic 403 is generic PalantirRPCException, not a declared named SDK error.'},
    'cases_sha256': sha(BASE / 'rest077_formal_cases.json'),
    'harness_sha256': sha(BASE / 'rest077_formal_execute.py'),
    'feature_sha256': sha(BASE / 'rest077_formal_cases.feature'),
    'freeze_sha256': sha(BASE / 'rest077_assets_freeze.json'),
    'source_commit': '168d51910570b6966afa2320333ab36f6a3f7ccf',
    'source_verification': {'tag': '1.101.0^{}', 'method': 'git show immutable commit for each resource, parse independently, compare full module AST with installed SDK and per-method AST/request bindings; derive method/path/query/headers directly from tag AST with literal kwargs', 'result': 'PASS all 23 operations and both base clients', 'primary_source_files': audit['sources_count'], 'changed_primary_sources': audit['sources_changed'], 'reader_assets': audit['assets_count'], 'changed_reader_assets': audit['assets_changed'], 'model_freeze': 'v1/ontologies/models.py and v1/core/models.py are monolithic definitions, both included; _core and _errors source trees included'},
    'source_ledger': '.ept/tmp/rest077_peer_inspection_20261116.json',
    'source_ledger_sha256': sha(ROOT / '.ept/tmp/rest077_peer_inspection_20261116.json'),
    'dry_run': {'label': 'CASE-REVIEW-DRYRUN', 'command': '.ept/tmp/feature015_shared_cli_qa_env/Scripts/python.exe .ept/tmp/rest077_formal_20261116/rest077_formal_execute.py --author-check --output .ept/tmp/rest077_case_review_dryrun_20261116.json', 'exit_code': 0, 'elapsed_seconds': 0.7169858, 'checks': 347, 'tool_output': 'AUTHOR_DRY_RUN_PASS', 'formal_execution': False, 'evidence': '.ept/tmp/rest077_case_review_dryrun_20261116.json', 'evidence_sha256': sha(ROOT / '.ept/tmp/rest077_case_review_dryrun_20261116.json')},
    'network_isolation_review': {'socket_connect': 'patched deny', 'socket_create_connection': 'patched deny', 'dns_getaddrinfo': 'patched deny', 'denial_probe': 'PASS: create_connection raises PUBLIC_SOCKET_DENIED', 'negative_semantic_controls': 'Missing; see R077-01', 'limits': 'No external network request executed. Harness uses httpx.MockTransport. No claim of OS firewall isolation.'},
    'workflow_snapshot': {'TESTCASE-078': 'Open', 'TESTEXEC-078': 'Open', 'DEV-STORY-077': 'Development', 'DESIGN-078': 'Closed', 'DEV-078': 'In Progress', 'UNITTEST-078': 'In Progress', 'CODEREVIEW-079': 'Blocked', 'prerequisites': 'Formal execution prohibited until case approval/closure and reviewed runnable implementation prerequisites are verified through tracker.'},
    'findings': findings,
    'per_case': per_case,
    'provenance_limits': 'Existing unit PASS and author dry run remain separate. Reviewer changed no case, harness, implementation or tracker. This report approves neither formal execution nor final REST acceptance.'
}
out = ROOT / '.ept/tmp/feature015_rest077_case_peer_review_20261116.json'
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(out), 'disposition': report['disposition'], 'findings': len(findings), 'per_case': len(per_case)}))
