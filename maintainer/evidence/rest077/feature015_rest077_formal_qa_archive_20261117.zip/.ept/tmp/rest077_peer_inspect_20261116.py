import ast
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path.cwd()
HERE = ROOT / '.ept/tmp/rest077_formal_20261116'
SDK = ROOT / '.ept/docs/customer_input/foundry-platform-python'
data = json.loads((HERE / 'rest077_formal_cases.json').read_text())
freeze = json.loads((HERE / 'rest077_assets_freeze.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows = []
for c in data['operations']:
    resource, method = c['operation'].split('.')[-2:]
    relative = c['source']['module'].replace('.', '/') + '.py'
    result = subprocess.run(['git', '-C', str(SDK), 'show', '168d51910570b6966afa2320333ab36f6a3f7ccf:' + relative], capture_output=True, check=True)
    tag = ast.parse(result.stdout.decode())
    installed = ast.parse(Path(c['source']['path']).read_text())
    source_equal = ast.dump(tag) == ast.dump(installed)
    checks = []
    for cls_name, binding in c['source']['methods'].items():
        cls = next(n for n in tag.body if isinstance(n, ast.ClassDef) and n.name == cls_name)
        fn = next(n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method)
        request = next(n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ('RequestInfo', 'RequestInfoWithPagination'))
        req = {k.arg: ast.unparse(k.value) for k in request.keywords}
        env = dict(zip([a.arg for a in fn.args.kwonlyargs], [ast.literal_eval(v) if isinstance(v, ast.Constant) else None for v in fn.args.kw_defaults]))
        env.update(c['kwargs'])
        # Request dictionaries contain only literals and bound SDK arguments.
        evaluate = lambda expression: eval(compile(ast.Expression(ast.parse(expression, mode='eval').body), '<frozen-source-expression>', 'eval'), {'__builtins__': {}}, env)
        path = evaluate(req['resource_path']).format(**evaluate(req['path_params']))
        query = {k: v for k, v in evaluate(req['query_params']).items() if v is not None}
        headers = {k: str(v) for k, v in evaluate(req['header_params']).items() if v is not None}
        checks.append({'class': cls_name, 'ast_binding_equal': hashlib.sha256(ast.dump(fn, include_attributes=False).encode()).hexdigest() == binding['ast_sha256'], 'request_binding_equal': req == binding['request'], 'method_equal': evaluate(req['method']) == c['wire']['method'], 'path_equal': path == c['wire']['path'], 'query_equal': query == c['wire']['query'], 'headers_equal': headers == c['wire']['headers'], 'return': ast.unparse(fn.returns), 'response_type': req['response_type'], 'named_errors': evaluate(req['throwable_errors']), 'automatic_iterator': 'ITERATOR' in req.get('response_mode', '')})
    rows.append({'case_id': c['case_id'], 'operation': c['operation'], 'tag_installed_ast_equal': source_equal, 'bindings': checks})
assets_changed = [p for p, h in freeze['assets'].items() if sha(Path(freeze['skill_root']) / p) != h]
sources_changed = [p for p, h in freeze['primary_sources'].items() if sha(p) != h]
out = {'case_count': len(rows), 'per_case': rows, 'assets_count': len(freeze['assets']), 'assets_changed': assets_changed, 'sources_count': len(freeze['primary_sources']), 'sources_changed': sources_changed, 'immutable_hashes': {p.name: sha(p) for p in HERE.iterdir() if p.is_file()}}
(ROOT / '.ept/tmp/rest077_peer_inspection_20261116.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'cases': len(rows), 'assets_changed': len(assets_changed), 'sources_changed': len(sources_changed), 'all_bindings_equal': all(r['tag_installed_ast_equal'] and all(all(v is True for k,v in b.items() if k.endswith('_equal')) for b in r['bindings']) for r in rows)}))
