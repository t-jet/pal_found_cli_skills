import ast, importlib, inspect, json, re
from pathlib import Path
import pydantic

ROOT = Path(__file__).resolve().parents[3]
ids = json.loads((ROOT/'.ept/docs/deliverables/development/FEATURE-015-rest-operation-partitions.json').read_text())['partitions']['DEV-STORY-077']['operation_ids']
out=[]
for op in ids:
    _,_,resource,method=op.split('.')
    module=importlib.import_module('foundry_sdk.v1.ontologies.'+re.sub(r'(?<!^)(?=[A-Z])','_',resource).lower())
    tree=ast.parse(Path(module.__file__).read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==resource+'Client')
    fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==method)
    ri=next(n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('RequestInfo','RequestInfoWithPagination'))
    ret=ast.unparse(fn.returns)
    response=eval(next(ast.unparse(k.value) for k in ri.keywords if k.arg=='response_type'),vars(module))
    schema=pydantic.TypeAdapter(response).json_schema()
    out.append(dict(operation=op,signature=str(inspect.signature(getattr(getattr(module,resource+'Client'),method))),request={k.arg:ast.unparse(k.value) for k in ri.keywords},schema=schema,doc=ast.get_docstring(fn)))
(Path(__file__).parent/'source_inspection.json').write_text(json.dumps(out,indent=2))
for c in out:
    s=c['schema']; defs=s.pop('$defs',{})
    print(c['operation'],c['signature'], '\n',c['request'],'\nRESPONSE',s)
    for k,v in defs.items(): print(' MODEL',k, str(v)[:1600])
