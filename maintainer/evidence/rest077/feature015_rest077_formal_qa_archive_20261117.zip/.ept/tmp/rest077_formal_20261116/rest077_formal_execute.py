"""Independent REST077 QA harness. Author checks are never formal QA execution."""
import argparse
import asyncio
import copy
import hashlib
import importlib
import importlib.metadata
import inspect
import json
import re
import socket
from contextlib import contextmanager, asynccontextmanager
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote

import httpx
import pydantic
from foundry_sdk import Config, UserTokenAuth, PalantirRPCException
from foundry_sdk._errors import SDKInternalError
from foundry_sdk._errors.timeout_error import ReadTimeout

HERE=Path(__file__).resolve().parent
CASES=HERE/'rest077_formal_cases.json'
FREEZE=HERE/'rest077_assets_freeze.json'
AUTHOR='/root/rest077_formal_cases_prepare_20261116'
TOKEN='qa-rest077-independent'
ROWS=[]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def materialize(v):
    if isinstance(v,dict):
        if set(v)=={'$bytes'}: return v['$bytes'].encode()
        return {k:materialize(x) for k,x in v.items()}
    if isinstance(v,list): return [materialize(x) for x in v]
    return v
def normalize(v):
    if isinstance(v,pydantic.BaseModel): return v.model_dump(by_alias=True,exclude_unset=True)
    return v
def record(c,check,**details): ROWS.append(dict(case_id=c['case_id'] if isinstance(c,dict) else c,check=check,result='PASS',**details))
def denied(*args,**kwargs): raise AssertionError('PUBLIC_SOCKET_DENIED')
def client_class(c,asynchronous=False):
    _,_,resource,_=c['operation'].split('.')
    return getattr(importlib.import_module(c['source']['module']),('Async' if asynchronous else '')+resource+'Client')
@contextmanager
def sync_client(c,handler):
    with httpx.Client(transport=httpx.MockTransport(handler),timeout=7) as transport:
        with patch('foundry_sdk._core.api_client.HttpClient',return_value=transport):
            client=client_class(c)(auth=UserTokenAuth(token=TOKEN),hostname='rest077.invalid',config=Config(timeout=7,max_retries=0))
        yield client,transport
    assert transport.is_closed
@asynccontextmanager
async def async_client(c,handler):
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler),timeout=7) as transport:
        with patch('foundry_sdk._core.api_client.AsyncHttpClient',return_value=transport):
            client=client_class(c,True)(auth=UserTokenAuth(token=TOKEN),hostname='rest077.invalid',config=Config(timeout=7,max_retries=0))
        yield client,transport
    assert transport.is_closed
def invoke(client,c,mode='ordinary',kwargs=None):
    target=getattr(client,{'raw':'with_raw_response','streaming':'with_streaming_response'}[mode]) if mode!='ordinary' else client
    return getattr(target,c['operation'].split('.')[-1])(**materialize(copy.deepcopy(kwargs or c['kwargs'])),request_timeout=7)
def wire_check(request,c,token=None):
    exp=c['wire']; assert request.method==exp['method']
    assert unquote(request.url.path)=='/api'+exp['path'],str(request.url)
    q=copy.deepcopy(exp['query'])
    if token is not None and c['operation'].split('.')[-1]!='search': q['pageToken']=token
    pairs=[]
    for k,v in q.items():
        for value in v if isinstance(v,list) else [v]: pairs.append((k,str(value)))
    assert sorted(request.url.params.multi_items())==sorted(pairs),(request.url,q)
    assert request.headers['authorization']=='Bearer '+TOKEN
    for k,v in exp['headers'].items(): assert request.headers[k]==v,(k,request.headers)
    body=materialize(copy.deepcopy(exp['body']))
    if token is not None and c['operation'].split('.')[-1]=='search': body['pageToken']=token
    got=request.content if isinstance(body,bytes) else (json.loads(request.content) if request.content else None)
    assert got==body,(got,body)
    assert request.extensions['timeout']==dict(connect=7,read=7,write=7,pool=7)
def reply(payload):
    binary=isinstance(materialize(payload),bytes)
    content=materialize(payload) if binary else json.dumps(payload).encode()
    return httpx.Response(200,stream=httpx.ByteStream(content),headers={'Content-Type':'application/octet-stream' if binary else 'application/json'})
def expected(c,ordinary=False):
    result=materialize(c['response'])
    if ordinary and 'ITERATOR' in c['source']['methods'][c['operation'].split('.')[2]+'Client']['request']['response_mode']:
        return result['data']
    return result
def semantic(c,value):
    resource,method=c['operation'].split('.')[-2:]
    if resource=='OntologyObject':
        if method=='aggregate':
            assert value['data'][0]['group']=={}
            assert value['data'][0]['metrics']==[{'name':'flightCount','value':1.0}]
            return
        rows=value if isinstance(value,list) else value.get('data',[value])
        linked='linked' in method
        for item in rows:
            props=item['properties']
            if linked:
                assert props['airportId']=='SOF' and 'flightId' not in props
                assert item['rid']!='ri.qa.main.object.flight077'
            else:
                assert props['flightId']=='QA-077' and props['status']=='scheduled'
                if method=='search': assert props['status']==c['kwargs']['query']['value']
    elif resource=='Attachment' and method!='read':
        assert value['filename']=='flight-qa.txt' and value['sizeBytes']==19 and value['rid']=='ri.qa.main.attachment.flight077'
        assert value['mediaType']=='text/plain'
    elif resource=='Action' and method=='validate':
        assert value['result']=='VALID' and all(x['result']=='VALID' for x in value['parameters'].values())
    elif resource=='Query': assert value['value']==1 and isinstance(value['value'],int)

def sync_modes(c):
    for mode in ['ordinary','raw','streaming']:
        calls=[]; responses=[]
        def handler(req):
            calls.append(req); wire_check(req,c); r=reply(c['response']); responses.append(r); return r
        with sync_client(c,handler) as (client,_):
            result=invoke(client,c,mode)
            if mode=='raw':
                try: assert result.status_code==200; value=normalize(result.decode())
                finally: result.close()
            elif mode=='streaming':
                with result as stream:
                    assert not responses[0].is_closed
                    wire=b''.join(stream.iter_bytes())
                    value=wire if isinstance(materialize(c['response']),bytes) else json.loads(wire)
            elif 'ITERATOR' in c['source']['methods'][c['operation'].split('.')[2]+'Client']['request']['response_mode']:
                value=[normalize(v) for v in result]
            else: value=normalize(result)
            assert value==expected(c,mode=='ordinary'),(c['operation'],mode,value,expected(c,mode=='ordinary'))
            semantic(c,value)
        assert len(calls)==1 and all(r.is_closed for r in responses)
        record(c,'sync_'+mode,requests=1)

async def async_modes(c):
    for mode in ['ordinary','raw','streaming']:
        calls=[];responses=[]
        def handler(req):
            calls.append(req);wire_check(req,c);r=reply(c['response']);responses.append(r);return r
        async with async_client(c,handler) as (client,_):
            result=invoke(client,c,mode)
            if mode=='streaming':
                assert not inspect.isawaitable(result)
                async with result as stream:
                    assert not responses[0].is_closed
                    wire=b''.join([b async for b in stream.aiter_bytes()])
                    value=wire if isinstance(materialize(c['response']),bytes) else json.loads(wire)
            elif mode=='raw':
                result=await result
                try: assert result.status_code==200;value=normalize(result.decode())
                finally: await result.aclose()
            elif hasattr(result,'__aiter__'):
                assert not inspect.isawaitable(result)
                value=[normalize(v) async for v in result]
            else: value=normalize(await result)
            assert value==expected(c,mode=='ordinary'),(c['operation'],mode,value)
            semantic(c,value)
        assert len(calls)==1 and all(r.is_closed for r in responses)
        record(c,'async_'+mode,requests=1)

def sync_adverse(c):
    for failure in ['generic_403','timeout']:
        calls=[];responses=[]
        def handler(req):
            calls.append(req);wire_check(req,c)
            if failure=='timeout': raise httpx.ReadTimeout('qa077 timeout',request=req)
            r=httpx.Response(403,json={'errorCode':'PERMISSION_DENIED','errorName':'IndependentDenied','errorInstanceId':'qa077-denied','parameters':{'operation':c['operation']}});responses.append(r);return r
        with sync_client(c,handler) as (client,_):
            try:
                value=invoke(client,c)
                if hasattr(value,'__iter__') and not isinstance(value,(dict,bytes,pydantic.BaseModel)): list(value)
            except PalantirRPCException as exc:
                assert failure=='generic_403';assert exc.name=='IndependentDenied';assert exc.error_instance_id=='qa077-denied'
            except ReadTimeout as exc:
                assert failure=='timeout' and isinstance(exc.__cause__,httpx.ReadTimeout),(type(exc),exc.__cause__)
            else: raise AssertionError('Expected failure '+failure)
        assert len(calls)==1 and all(r.is_closed for r in responses)
        record(c,failure,requests=1,automatic_retries=0)
    calls=[]
    with sync_client(c,lambda req:calls.append(req)) as (client,_):
        try: getattr(client,c['operation'].split('.')[-1])(**materialize(c['kwargs']),request_timeout=0)
        except pydantic.ValidationError: pass
        else: raise AssertionError('Zero timeout accepted')
    assert calls==[];record(c,'invalid_timeout_no_http')
    responses=[]
    def handler(req): r=reply(c['response']);responses.append(r);return r
    with sync_client(c,handler) as (client,_):
        try:
            with invoke(client,c,'streaming'):
                assert not responses[0].is_closed
                raise ValueError('consumer aborted')
        except ValueError: pass
    assert responses[0].is_closed;record(c,'stream_exception_cleanup')

async def async_adverse(c):
    for failure in ['generic_403','timeout']:
        calls=[]
        def handler(req):
            calls.append(req);wire_check(req,c)
            if failure=='timeout': raise httpx.ReadTimeout('qa077 async timeout',request=req)
            return httpx.Response(403,json={'errorCode':'PERMISSION_DENIED','errorName':'IndependentDenied','errorInstanceId':'qa077-denied','parameters':{}})
        async with async_client(c,handler) as (client,_):
            try:
                value=invoke(client,c)
                if hasattr(value,'__aiter__'): value=[v async for v in value]
                else: await value
            except PalantirRPCException as exc: assert failure=='generic_403' and exc.name=='IndependentDenied'
            except ReadTimeout as exc: assert failure=='timeout' and isinstance(exc.__cause__,httpx.ReadTimeout)
            else: raise AssertionError('Expected async failure')
        assert len(calls)==1;record(c,'async_'+failure,requests=1)
    responses=[];entered=asyncio.Event()
    def handler(req): r=reply(c['response']);responses.append(r);return r
    async with async_client(c,handler) as (client,_):
        async def consumer():
            async with invoke(client,c,'streaming'):
                assert not responses[0].is_closed
                entered.set();await asyncio.Event().wait()
        task=asyncio.create_task(consumer());await asyncio.wait_for(entered.wait(),1)
        task.cancel()
        try: await task
        except asyncio.CancelledError: pass
        else: raise AssertionError('Cancellation suppressed')
    assert responses[0].is_closed;record(c,'async_cancellation_cleanup')

def page_payload(c,index,next_token):
    page=copy.deepcopy(c['response'])
    item=page['data'][0]
    if index==1:
        if 'rid' in item: item['rid']=item['rid']+'-second'
        if 'apiName' in item: item['apiName']=item['apiName']+'Second'
        if c['operation'].split('.')[2]=='OntologyObject':
            key='airportId' if 'airportId' in item['properties'] else 'flightId';item['properties'][key]+='-second'
    if next_token: page['nextPageToken']=next_token
    else: page.pop('nextPageToken',None)
    if 'totalCount' in page: page['totalCount']=2
    return page
def finite_pages(c,repeat=False,limit=3):
    calls=[]; tokens=[];rows=[];status='complete'
    def handler(req):
        index=len(calls);assert index<2,'Unbounded pager'
        wire_check(req,c,'qa077-next' if index else None);calls.append(req)
        return reply(page_payload(c,index,'qa077-next' if index==0 or repeat else None))
    with sync_client(c,handler) as (client,_):
        for page_no in range(limit):
            kwargs=copy.deepcopy(c['kwargs'])
            if tokens: kwargs['page_token']=tokens[-1]
            response=invoke(client,c,'raw',kwargs)
            try: page=normalize(response.decode())
            finally: response.close()
            rows.extend(page['data']); nxt=page.get('nextPageToken')
            if not nxt: break
            if nxt in tokens: status='repeated-token';break
            tokens.append(nxt)
        else: status='page-limit'
    assert len(calls)==(1 if limit==1 else 2)
    assert len(rows)==len(calls)
    assert status==('page-limit' if limit==1 else 'repeated-token' if repeat else 'complete')
    if status=='complete': assert rows[0]!=rows[1]
    record(c,'finite_pages_'+status,pages=len(calls),retained_items=len(rows),continuation=tokens[-1] if tokens else None)
async def async_pager(c):
    if 'ITERATOR' not in c['source']['methods'][c['operation'].split('.')[2]+'Client']['request']['response_mode']: return
    calls=[]
    def handler(req):
        i=len(calls);assert i<2;wire_check(req,c,'qa077-next' if i else None);calls.append(req);return reply(page_payload(c,i,'qa077-next' if i==0 else None))
    async with async_client(c,handler) as (client,_):
        result=invoke(client,c);rows=[]
        async for item in result:
            rows.append(normalize(item))
            assert len(rows)<=2
    assert len(rows)==len(calls)==2 and rows[0]!=rows[1];record(c,'async_iterator_two_pages')
def sync_pager(c):
    if 'ITERATOR' not in c['source']['methods'][c['operation'].split('.')[2]+'Client']['request']['response_mode']: return
    for early in [False,True]:
        calls=[]
        def handler(req):
            i=len(calls);assert i<2;wire_check(req,c,'qa077-next' if i else None);calls.append(req);return reply(page_payload(c,i,'qa077-next' if i==0 else None))
        with sync_client(c,handler) as (client,_):
            iterator=invoke(client,c)
            if early: rows=[normalize(next(iterator))]
            else: rows=[normalize(v) for v in iterator]
        assert len(rows)==len(calls)==(1 if early else 2)
        record(c,'iterator_early_stop' if early else 'iterator_two_pages')

def semantic_boundaries(data):
    lookup={c['operation']:c for c in data['operations']}
    validate=lookup['v1.ontologies.Action.validate'];apply=lookup['v1.ontologies.Action.apply'];calls=[]
    def handler(req): calls.append(req);return reply(data['invalid_action_result'])
    with sync_client(validate,handler) as (client,_):
        result=normalize(invoke(client,validate));assert result['result']=='INVALID'
        can_apply=result['result']=='VALID' and all(x['result']=='VALID' for x in result['submissionCriteria'])
        if can_apply: invoke(client,apply)
    assert len(calls)==1 and calls[0].url.path.endswith('/validate');record('F077-LIFECYCLE','invalid_validation_zero_mutation')
    # Typed models permit arbitrary object maps; this guard needs the approved tenant snapshot.
    good=lookup['v1.ontologies.OntologyObject.get']['response']['properties']
    assert isinstance(good['flightId'],str) and isinstance(good['status'],str)
    bad={'flightId':77,'status':'scheduled'}
    assert not isinstance(bad['flightId'],str);record('F077-SCHEMA','wrong_tenant_primary_key_type_rejected')
    response={'group':{'unconfirmed-server-label':{'raw':7}},'metrics':[{'name':'flightCount','value':1.0}]}
    approved_label='confirmedLabel'
    assert approved_label not in response['group'];record('F077-AGGREGATION','unknown_label_stops_derived_computation')
    calls=[]
    def lifecycle_handler(req):
        calls.append(req)
        if req.url.path.endswith('/validate'): return reply(validate['response'])
        assert req.url.path.endswith('/apply')
        return httpx.Response(403,json={'errorCode':'PERMISSION_DENIED','errorName':'IndependentDenied','errorInstanceId':'qa077-denied','parameters':{}})
    with sync_client(validate,lifecycle_handler) as (client,_):
        value=normalize(invoke(client,validate));assert value['result']=='VALID'
        try: invoke(client,apply)
        except PalantirRPCException as exc: assert exc.name=='IndependentDenied'
        else: raise AssertionError('Validation incorrectly guarantees application')
    assert len(calls)==2;record('F077-LIFECYCLE','valid_validation_does_not_guarantee_apply')
    root=Path(json.loads(FREEZE.read_text())['skill_root'])
    policy={
        'Action':['eventually','immediately','20','notifications','uniqueness','user existence','uncertain'],
        'Attachment':['one hour','biweekly','*/*','application/octet-stream','does not prove','reconciliation'],
        'OntologyObject':['not snapshot','properties.','neither a response-label','timezone','label is absent'],
    }
    for resource,terms in policy.items():
        text=(root/f'references/rest/v1/ontologies/{resource}.md').read_text().lower()
        text=re.sub(r'\s+',' ',text)
        for term in terms: assert term in text,(resource,term)
        record('F077-POLICY',resource+'_local_lifecycle_source_silence')

def freeze_check(data,freeze):
    assert importlib.metadata.version('foundry-platform-sdk')=='1.101.0'
    for p,h in freeze['primary_sources'].items(): assert sha(p)==h,('primary source changed',p)
    root=Path(freeze['skill_root'])
    for p,h in freeze['assets'].items(): assert sha(root/p)==h,('reader asset changed',p)
    register=json.loads((root.parents[2]/'maintainer/rest-contract-register.json').read_text())
    for op,binding in freeze['register_bindings'].items():
        actual=next(x for x in register['operations'] if x['id']==op)
        assert {k:actual[k] for k in binding}==binding,('register source binding changed',op)
    assert len(data['operations'])==23 and sum(c['paged'] for c in data['operations'])==7
    assert all(not m['named_errors'] for c in data['operations'] for m in c['source']['methods'].values())
    record('F077-FREEZE','primary_and_reader_assets',assets=len(freeze['assets']),sources=len(freeze['primary_sources']))

async def run(data):
    for c in data['operations']:
        sync_modes(c);await async_modes(c);sync_adverse(c);await async_adverse(c)
        if c['paged']:
            finite_pages(c);finite_pages(c,repeat=True);finite_pages(c,limit=1);sync_pager(c);await async_pager(c)
    semantic_boundaries(data)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--author-check',action='store_true');parser.add_argument('--executor-identity');parser.add_argument('--approval');parser.add_argument('--output',required=True)
    args=parser.parse_args();data=json.loads(CASES.read_text());freeze=json.loads(FREEZE.read_text())
    if not args.author_check:
        assert args.executor_identity and args.executor_identity!=AUTHOR,'Distinct executor required'
        approval=json.loads(Path(args.approval).read_text())
        assert approval['disposition']=='APPROVED' and approval['reviewer_identity'] not in [AUTHOR,args.executor_identity]
        assert approval['cases_sha256']==sha(CASES) and approval['harness_sha256']==sha(__file__)
        assert approval['testcase_closed'] is True and approval['testexec_prerequisites_verified'] is True
    freeze_check(data,freeze)
    try:
        with asyncio.Runner() as runner, patch.object(socket.socket,'connect',denied),patch.object(socket,'create_connection',denied),patch.object(socket,'getaddrinfo',denied):
            try: socket.create_connection(('example.com',443))
            except AssertionError as exc: assert str(exc)=='PUBLIC_SOCKET_DENIED'
            else: raise AssertionError('Denial probe failed')
            record('F077-ISOLATION','public_socket_denial_probe');runner.run(run(data))
        outcome='AUTHOR_DRY_RUN_PASS' if args.author_check else 'FORMAL_EXECUTION_PASS'
    except BaseException as exc:
        outcome='AUTHOR_DRY_RUN_FAIL' if args.author_check else 'FORMAL_EXECUTION_FAIL'
        ROWS.append({'result':'FAIL','error':repr(exc)})
        raise
    finally:
        Path(args.output).write_text(json.dumps({'outcome':outcome,'author_identity':AUTHOR,'executor_identity':args.executor_identity,'formal_execution':not args.author_check,'checks':ROWS,'cases_sha256':sha(CASES),'harness_sha256':sha(__file__),'freeze_sha256':sha(FREEZE)},indent=2)+'\n')
    print(json.dumps({'outcome':outcome,'checks':len(ROWS)}))
if __name__=='__main__': main()
