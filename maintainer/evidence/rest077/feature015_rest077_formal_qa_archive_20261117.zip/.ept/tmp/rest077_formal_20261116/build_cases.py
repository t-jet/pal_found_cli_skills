"""Author REST077 cases from SDK source; distributed examples supply no oracle values."""
import ast
import hashlib
import importlib
import inspect
import json
import re
from pathlib import Path
from urllib.parse import unquote

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SKILL = ROOT/'.ept/tmp/feature015_integration/.agents/skills/pal-found-dev'
AUTHOR = '/root/rest077_formal_cases_prepare_20261116'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def snake(n): return re.sub(r'(?<!^)(?=[A-Z])','_',n).lower()
def rid(kind, key): return f'ri.qa.main.{kind}.{key}'
ONT = rid('ontology','flight077')
ATT = rid('attachment','flight077')
CONTENT = 'Flight QA evidence\n'
PARAMS = {'flightId':'QA-077','status':'scheduled'}
FLIGHT = {'rid':rid('object','flight077'), 'properties':{'flightId':'QA-077','status':'scheduled'}}
AIRPORT = {'rid':rid('object','airport077'), 'properties':{'airportId':'SOF','name':'Sofia'}}
TYPE = {'apiName':'Flight','status':'ACTIVE','rid':rid('object-type','flight077'), 'primaryKey':['flightId'], 'properties':{'flightId':{'baseType':'String','required':True},'status':{'baseType':'String','required':True}}}
for value in TYPE['properties'].values(): value.pop('required')
ACTION = {'apiName':'schedule-flight','status':'ACTIVE','rid':rid('action-type','flight077'), 'parameters':{'flightId':{'baseType':'String','required':True},'status':{'baseType':'String','required':True}},'operations':[{'type':'modifyObject','objectTypeApiName':'Flight'}]}
QUERY = {'apiName':'countScheduledFlights','rid':rid('query-type','flight077'),'version':'1.0.0','parameters':{'status':{'baseType':'String','required':True}},'output':{'type':'integer'}}
LINK = {'apiName':'destination','displayName':'Destination','status':'ACTIVE','objectTypeApiName':'Airport','cardinality':'ONE','foreignKeyPropertyApiName':'destinationId'}
META = {'rid':ATT,'filename':'flight-qa.txt','sizeBytes':len(CONTENT.encode()),'mediaType':'text/plain'}
ONTOLOGY = {'apiName':'FlightQA','displayName':'Flight QA','description':'Synthetic QA ontology','rid':ONT}
VALID = {'result':'VALID','submissionCriteria':[{'result':'VALID'}],'parameters':{k:{'result':'VALID','required':True,'evaluatedConstraints':[]} for k in PARAMS}}
INVALID = {'result':'INVALID','submissionCriteria':[{'result':'INVALID','configuredFailureMessage':'Flight locked'}],'parameters':{'status':{'result':'INVALID','required':True,'evaluatedConstraints':[{'type':'oneOf','options':[{'value':'scheduled'}],'otherValuesAllowed':False}]}}}
OPS = []
def add(resource, method, suffix, *, kwargs=None, body=None, response=None, query=None, headers=None, path=None, page=False):
    kw={'ontology_rid':ONT} if resource!='Attachment' and not (resource=='Ontology' and method=='list') else {}
    kw.update(kwargs or {})
    url=path or '/v1/ontologies/'+ONT+suffix
    OPS.append({'operation':f'v1.ontologies.{resource}.{method}','kwargs':kw,'wire':{'method':'POST' if body is not None else 'GET','path':url,'query':query or {},'headers':headers or {'Accept':'application/json'},'body':body},'response':response,'paged':page})
for method,end in [('apply','apply'),('apply_batch','applyBatch'),('validate','validate')]:
    k={'action_type':'schedule-flight'}
    if method=='apply_batch': k['requests']=[{'parameters':PARAMS},{'parameters':{'flightId':'QA-078','status':'scheduled'}}]; b={'requests':k['requests']}
    else: k['parameters']=PARAMS; b={'parameters':PARAMS}
    add('Action',method,'/actions/schedule-flight/'+end,kwargs=k,body=b,response=VALID if method=='validate' else {},headers={'Accept':'application/json','Content-Type':'application/json'})
for r,kind,item,identity in [('ActionType','actionTypes',ACTION,{'action_type_api_name':'schedule-flight'}),('ObjectType','objectTypes',TYPE,{'object_type':'Flight'}),('QueryType','queryTypes',QUERY,{'query_api_name':'countScheduledFlights'})]:
    add(r,'get','/'+kind+'/'+item['apiName'],kwargs=identity,response=item)
    add(r,'list','/'+kind,kwargs={'page_size':1},query={'pageSize':1},response={'data':[item]},page=True)
add('Attachment','get','',kwargs={'attachment_rid':ATT},path='/v1/attachments/'+ATT,response=META)
add('Attachment','read','',kwargs={'attachment_rid':ATT},path='/v1/attachments/'+ATT+'/content',response={'$bytes':CONTENT},headers={'Accept':'*/*'})
add('Attachment','upload','',kwargs={'body':{'$bytes':CONTENT},'content_length':len(CONTENT.encode()),'content_type':'application/octet-stream','filename':'flight-qa.txt'},path='/v1/attachments/upload',query={'filename':'flight-qa.txt'},headers={'Accept':'application/json','Content-Type':'*/*','Content-Length':str(len(CONTENT.encode()))},body={'$bytes':CONTENT},response=META)
add('ObjectType','get_outgoing_link_type','/objectTypes/Flight/outgoingLinkTypes/destination',kwargs={'object_type':'Flight','link_type':'destination'},response=LINK)
add('ObjectType','list_outgoing_link_types','/objectTypes/Flight/outgoingLinkTypes',kwargs={'object_type':'Flight','page_size':1},query={'pageSize':1},response={'data':[LINK]},page=True)
add('Ontology','get','',response=ONTOLOGY)
add('Ontology','list','',path='/v1/ontologies',response={'data':[ONTOLOGY]})
add('OntologyObject','get','/objects/Flight/QA-077',kwargs={'object_type':'Flight','primary_key':'QA-077','properties':['flightId','status']},query={'properties':['flightId','status']},response=FLIGHT)
add('OntologyObject','get_linked_object','/objects/Flight/QA-077/links/destination/SOF',kwargs={'object_type':'Flight','primary_key':'QA-077','link_type':'destination','linked_object_primary_key':'SOF','properties':['airportId','name']},query={'properties':['airportId','name']},response=AIRPORT)
for method,suffix,item in [('list','/objects/Flight',FLIGHT),('list_linked_objects','/objects/Flight/QA-077/links/destination',AIRPORT)]:
    k={'object_type':'Flight','page_size':1,'properties':['airportId','name'] if method=='list_linked_objects' else ['flightId','status']}
    if method=='list_linked_objects': k.update(primary_key='QA-077',link_type='destination')
    result={'data':[item]}
    if method=='list': result['totalCount']=1
    add('OntologyObject',method,suffix,kwargs=k,query={'pageSize':1,'properties':k['properties']},response=result,page=True)
search={'type':'eq','field':'properties.status','value':'scheduled'}
add('OntologyObject','search','/objects/Flight/search',kwargs={'object_type':'Flight','query':search,'fields':['flightId','status'],'page_size':1},body={'query':search,'fields':['flightId','status'],'pageSize':1},headers={'Accept':'application/json','Content-Type':'application/json'},response={'data':[FLIGHT],'totalCount':1},page=True)
add('OntologyObject','aggregate','/objects/Flight/aggregate',kwargs={'object_type':'Flight','aggregation':[{'type':'count','name':'flightCount'}],'group_by':[]},body={'aggregation':[{'type':'count','name':'flightCount'}],'groupBy':[]},headers={'Accept':'application/json','Content-Type':'application/json'},response={'data':[{'group':{},'metrics':[{'name':'flightCount','value':1.0}]}],'excludedItems':0})
add('Query','execute','/queries/countScheduledFlights/execute',kwargs={'query_api_name':'countScheduledFlights','parameters':{'status':'scheduled'}},body={'parameters':{'status':'scheduled'}},headers={'Accept':'application/json','Content-Type':'application/json'},response={'value':1})

partition=json.loads((ROOT/'.ept/docs/deliverables/development/FEATURE-015-rest-operation-partitions.json').read_text())['partitions']['DEV-STORY-077']['operation_ids']
assert {c['operation'] for c in OPS}==set(partition) and len(OPS)==23
register=json.loads((SKILL.parents[2]/'maintainer/rest-contract-register.json').read_text())
assets={}; sources={}; bindings={}
def freeze(path, base, target):
    path=Path(path).resolve(); target[str(path.relative_to(base))]=sha(path)
for i,c in enumerate(sorted(OPS,key=lambda c:partition.index(c['operation'])),1):
    _,_,r,m=c['operation'].split('.')
    module=importlib.import_module('foundry_sdk.v1.ontologies.'+snake(r))
    src=Path(module.__file__); tree=ast.parse(src.read_text())
    c['case_id']=f'F077-{i:02}'
    c['source']={'module':module.__name__,'path':str(src),'sha256':sha(src),'methods':{}}
    for clsname in [r+'Client','Async'+r+'Client']:
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==clsname)
        fn=next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==m)
        request=next(n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('RequestInfo','RequestInfoWithPagination'))
        errors=next(k.value for k in request.keywords if k.arg=='throwable_errors')
        assert ast.literal_eval(errors)=={}
        c['source']['methods'][clsname]={'line':fn.lineno,'ast_sha256':hashlib.sha256(ast.dump(fn,include_attributes=False).encode()).hexdigest(),'return':ast.unparse(fn.returns),'doc':ast.get_docstring(fn),'request':{k.arg:ast.unparse(k.value) for k in request.keywords},'named_errors':[]}
    entry=next(x for x in register['operations'] if x['id']==c['operation'])
    bindings[c['operation']]={k:entry[k] for k in ['id','source_sha256','symbols','contract','parts','behavior']}
    c['assets']=[entry['behavior'],*entry['parts'],f'examples/rest/077/v1/ontologies/{r}/{m}.py']
    for rel in c['assets']: freeze(SKILL/rel,SKILL,assets)
    sources[str(src)]=sha(src)
    c['modes']=['sync_ordinary','sync_raw','sync_streaming','async_ordinary','async_raw','async_streaming']
    c['adverse']=['generic_403','timeout','invalid_timeout','stream_exception_cleanup','async_cancellation_cleanup']

# Freeze reader dependencies transitively, following only local Markdown links.
queue=[SKILL/p for p in assets]; seen=set()
while queue:
    p=queue.pop().resolve()
    if p in seen: continue
    seen.add(p)
    if p.suffix!='.md' or p.name in ['catalog.md','index.md','authentication.md','client-behavior.md']: continue
    for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if '://' in link: continue
        dest=(p.parent/unquote(link.split('#')[0])).resolve()
        if dest.is_file() and dest.is_relative_to(SKILL.resolve()):
            freeze(dest,SKILL,assets); queue.append(dest)
for module_name in ['foundry_sdk.v1.ontologies.models','foundry_sdk.v1.core.models','foundry_sdk._core.api_client','foundry_sdk._core.resource_iterator','foundry_sdk._core.model_base','foundry_sdk._errors']:
    p=Path(importlib.import_module(module_name).__file__); sources[str(p)]=sha(p)
for package in ['foundry_sdk._core','foundry_sdk._errors']:
    for p in Path(importlib.import_module(package).__file__).parent.rglob('*.py'): sources[str(p)]=sha(p)
data={'story':'DEV-STORY-077','testcase':'TESTCASE-078','testexec':'TESTEXEC-078','author_identity':AUTHOR,'sdk_release':'1.101.0','source_commit':'168d51910570b6966afa2320333ab36f6a3f7ccf','approval':'PENDING_INDEPENDENT_REVIEW','execution':'NOT_FORMAL_EXECUTION','oracle_method':'Literal synthetic Flight/Airport schema and payloads authored from installed primary SDK AST, model fields and method documentation. No generator or distributed example expectations executed or copied. Register supplies only identities and asset locations.','semantic_schema':{'Flight':TYPE,'Airport':{'primaryKey':['airportId'],'properties':{'airportId':{'baseType':'String','required':True},'name':{'baseType':'String','required':True}}},'ActionType':ACTION,'QueryType':QUERY},'invalid_action_result':INVALID,'operations':sorted(OPS,key=lambda c:partition.index(c['operation']))}
(HERE/'rest077_formal_cases.json').write_text(json.dumps(data,indent=2)+'\n')
(HERE/'rest077_assets_freeze.json').write_text(json.dumps({'skill_root':str(SKILL),'assets':assets,'primary_sources':sources,'register_bindings':bindings},indent=2)+'\n')
feature=['Feature: Frozen SDK v1 Ontology operations in an isolated fake-HTTP enrollment','  Background:','    Given prepared SDK 1.101.0 and public sockets denied','    And synthetic Flight and Airport metadata with distinct primary keys','    And frozen local contracts, behavior, examples and transitive models','']
for c in data['operations']:
    feature += [f"  Scenario Outline: {c['case_id']} {c['operation']} complete wire and result",f"    Given source bindings and frozen assets for {c['operation']}",f"    When SDK runs <mode> with case JSON literal kwargs",f"    Then request equals {c['wire']['method']} {c['wire']['path']}",'    And query, headers, body and seven-second timeout equal literal wire oracle','    And response equals case JSON literal payload with tenant-schema meaning preserved','    And response and client close on completion, exception and cancellation','    Examples:','      | mode |']+[f'      | {mode} |' for mode in c['modes']]+['',f"  Scenario: {c['case_id']} generic failures and validation",'    Given source declares zero named throwable errors','    When fake HTTP denies permission with generic 403 envelope','    Then SDK preserves error identity and makes one request','    When fake HTTP raises timeout','    Then SDK reports transport failure without replay','    When request_timeout is zero','    Then SDK rejects input before HTTP','']
    if c['paged']: feature += [f"  Scenario: {c['case_id']} finite paging",'    Given two pages with distinct objects or schema identities','    When ordinary iterator or explicit search continuation advances','    Then exactly two requests retain initial filters and token placement','    And repeated token and page/item bounds preserve partial results','    And stopping after one item causes no next request','']
feature += ['  Scenario: Mutation and validation lifecycle boundaries','    Given INVALID action validation with failed submission criteria','    Then safe application makes zero apply calls','    Given VALID validation and generic 403 apply denial','    Then validation does not prove existing-object constraints or mutation success','    And uncertain mutation timeout is retained without automatic retry','    And OSv1 eventual visibility differs from OSv2 immediate visibility','', '  Scenario: Attachment upload source defect and retention','    Given binary content and supplied application/octet-stream','    Then frozen SDK sends */* and exact byte length','    And fixture success makes no live MIME acceptance claim','    And new unattached upload expires after one hour','    And previously mapped disconnected attachment cleanup is biweekly','', '  Scenario: Unknown aggregation labels remain uninterpreted','    Given group labels and values are arbitrary server response data','    Then unknown labels stop derived computation','    And request field paths establish no response label or timezone guarantee','']
(HERE/'rest077_formal_cases.feature').write_text('\n'.join(feature))
print(json.dumps({'cases':23,'modes':138,'paged':sum(c['paged'] for c in OPS),'assets':len(assets),'sources':len(sources)}))
