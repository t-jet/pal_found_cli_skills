import subprocess, sys, json, pathlib, hashlib, re, time
ROOT=pathlib.Path.cwd()
OUT=ROOT/'.ept/tmp/rest077_case_stage_20261116'
OUT.mkdir(exist_ok=True)
def cli(*args):
    cmd=[sys.executable,'.ept/tools/tracker/tracker_cli.py',*args]
    started=time.monotonic()
    p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8-sig')
    rec={'argv':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'elapsed_seconds':time.monotonic()-started}
    with (OUT/'transcript.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
    if p.returncode: raise RuntimeError(rec)
    return p.stdout
if __name__=='__main__':
    for tid in ['TESTCASE-078','DEV-STORY-077','TESTEXEC-078','DEV-078','UNITTEST-078','CODEREVIEW-079','DESIGN-078']:
        text=cli('get',tid,'--author','qa-engineer');(OUT/(tid+'.txt')).write_text(text,encoding='utf-8')
        comments=cli('comment','list',tid,'--author','qa-engineer');(OUT/(tid+'-comment-list.txt')).write_text(comments,encoding='utf-8')
        ids=re.findall(r'^(\d{8}-\d{6}-\S+)',comments,re.M)
        for cid in ids:
            (OUT/(tid+'-'+cid+'.txt')).write_text(cli('comment','get',tid,cid,'--author','qa-engineer'),encoding='utf-8')
        (OUT/(tid+'-links.txt')).write_text(cli('link','list',tid,'--author','qa-engineer'),encoding='utf-8')
        print(tid,re.search(r'current_status: (.*)',text).group(1),len(ids),'comments')
    (OUT/'type-info.txt').write_text(cli('type-info','testcase','--author','qa-engineer'),encoding='utf-8')
    (OUT/'transitions-Open.txt').write_text(cli('workflow','transitions','testcase','Open','--author','qa-engineer'),encoding='utf-8')
