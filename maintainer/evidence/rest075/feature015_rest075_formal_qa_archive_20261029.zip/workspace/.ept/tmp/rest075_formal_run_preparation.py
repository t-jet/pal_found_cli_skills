"""Run preparation commands and retain their raw output and measured duration."""
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

tmp = Path(__file__).resolve().parent
target = tmp / sys.argv[1]
label = sys.argv[2]
start = time.perf_counter()
result = subprocess.run([sys.executable, str(target), *sys.argv[3:]], capture_output=True)
elapsed = time.perf_counter() - start
out, err = tmp / (label + '_stdout.log'), tmp / (label + '_stderr.log')
out.write_bytes(result.stdout)
err.write_bytes(result.stderr)
record = {'command': [sys.executable, str(target), *sys.argv[3:]], 'exit_code': result.returncode,
          'elapsed_seconds': elapsed, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
          'stdout': str(out), 'stderr': str(err),
          'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
          'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
(tmp / (label + '_result.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
sys.exit(result.returncode)
