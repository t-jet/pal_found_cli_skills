import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path.cwd()
TMP = ROOT / '.ept/tmp'
LOG = TMP / 'rest075_stage_workflow_transcript_20261029.json'
records = json.loads(LOG.read_text())['commands'] if LOG.exists() else []
previous_machine_seconds = sum(r['elapsed_seconds'] for r in records)
started = time.perf_counter()


def cli(*args):
    tick = time.perf_counter()
    p = subprocess.run([sys.executable, '.ept/tools/tracker/tracker_cli.py', *args], capture_output=True)
    result = {'args': list(args), 'exit_code': p.returncode, 'elapsed_seconds': time.perf_counter() - tick,
              'stdout': p.stdout.decode('utf-8'), 'stderr': p.stderr.decode('utf-8'),
              'stdout_sha256': hashlib.sha256(p.stdout).hexdigest()}
    records.append(result)
    LOG.write_text(json.dumps({'commands': records}, indent=2), encoding='utf-8')
    if p.returncode:
        raise RuntimeError(result)
    return result['stdout']


def comment(ticket, subject, body):
    existing = {r['args'][5] for r in records if r['args'][:3] == ['comment', 'create', ticket]}
    if subject in existing:
        return
    if len(body) > 7000:
        chunks = [body[i:i + 6000] for i in range(0, len(body), 6000)]
        for i, chunk in enumerate(chunks, 1):
            title = subject + ' annex part ' + str(i) + '/' + str(len(chunks))
            if title not in existing:
                cli('comment', 'create', ticket, '--subject', title, '--text',
                    'Literal continuation, concatenate parts in order.\n\n````text\n' + chunk + '\n````', '--author', 'qa-engineer')
        return
    return cli('comment', 'create', ticket, '--subject', subject, '--text', body, '--author', 'qa-engineer')


def transition(ticket, kind, current, target, *fields):
    exits = cli('workflow', 'transitions', kind, current, '--author', 'qa-engineer')
    assert '-> ' + target in exits
    return cli('update', ticket, '--status', target, *fields, '--author', 'qa-engineer')


def compact(value):
    if isinstance(value, dict):
        return {k: compact(v) for k, v in value.items() if k not in ('schema', 'parameter_schema', 'argument_schemas')}
    if isinstance(value, list):
        return [compact(v) for v in value]
    return value


def fenced(value):
    return '```json\n' + json.dumps(value, indent=2, ensure_ascii=True) + '\n```'


approval = json.loads((TMP / 'rest075_case_approval_20261029.json').read_text())
assert approval['verdict'] == 'APPROVED_CASES_AND_HARNESS'
for name, digest in approval['approved_immutable_artifacts'].items():
    assert hashlib.sha256((TMP / name).read_bytes()).hexdigest() == digest, name
cases = json.loads((TMP / 'rest075_formal_cases.json').read_text())
ready = json.loads((TMP / 'rest075_formal_readiness.json').read_text())
for filename, digest in ready['source_asset_bindings'].items():
    assert hashlib.sha256(pathlib.Path(filename).read_bytes()).hexdigest() == digest, filename
assert len(cases['operations']) == 29
assert sum(len(c['errors']) for c in cases['operations']) == 44
for ticket, status in [('DEV-077', 'Resolved'), ('UNITTEST-077', 'Resolved'), ('CODEREVIEW-078', 'Closed')]:
    assert 'current_status: ' + status in cli('get', ticket, '--author', 'qa-engineer')
links = cli('link', 'list', 'DEV-077', '--author', 'qa-engineer')
assert 'LINK-02042' not in links and 'LINK-01822' in links and 'LINK-01823' in links
for ticket in ['TESTCASE-077', 'TESTEXEC-077']:
    output = cli('get', ticket, '--author', 'qa-engineer')
    assert ('current_status: Open' in output or (ticket == 'TESTCASE-077' and 'current_status: In Progress' in output))
    cli('link', 'list', ticket, '--author', 'qa-engineer')
    cli('comment', 'list', ticket, '--author', 'qa-engineer')

comment('TESTCASE-077', 'Approved source-derived case staging plan',
        '## Plan\nPost all 29 independently authored and approved Gherkin cases with literal request/result/error annexes from immutable rest075_formal_cases.json. Include source-mode availability and absence, finite recovery and synthetic lifecycle. Verify implementation exists, compiled and runnable in prepared offline SDK1.101.0 environment. DEV077 and UNITTEST077 are Resolved; independent CODEREVIEW078 is Closed (approved). No codereview Resolved state exists; completed terminal approval satisfies review completion.\n'
        'Scope: indexed BA-DES015/SA-DES014 revision2 and FEATURE-015-rest-authoring-contract.md. Source-authored cases and harness independently approved by /root/rest075_cases_review_20261029 in .ept/tmp/rest075_case_approval_20261029.json. Sidecar supersedes pending-review placeholder inside immutable cases. Cases SHA256 ' + approval['cases_sha256'] + '; harness SHA256 ' + approval['harness_sha256'] + '. All83 source/asset hashes match. No linked unresolved questions. Authoring contributor effort unmeasured; report measured validation/posting command time only. Formal execution remains NOT_RUN and belongs to separate executor.')
if not any(r['args'][:4] == ['update', 'TESTCASE-077', '--status', 'In Progress'] for r in records):
    transition('TESTCASE-077', 'testcase', 'Open', 'In Progress')
for case in cases['operations']:
    g = case['gherkin']
    lines = ['Feature: ' + g['feature']]
    for scenario in g['scenarios']:
        lines += ['', '  Scenario: ' + scenario['name']]
        for key in ['given', 'when', 'then']:
            for i, step in enumerate(scenario[key]):
                lines.append('    ' + (key.capitalize() if i == 0 else 'And') + ' ' + step)
    annex = {'operation': case['operation'], 'case_sha256': case['case_sha256'],
             'source': {k: v for k, v in case['source'].items() if k not in ['docstring']},
             'assets': case['assets'], 'available_modes': case['available_modes'],
             'request': case['request'], 'success': case['success'], 'errors': case['errors'],
             'additional_cases': case['additional_cases'], 'semantic_expectation': case['semantic_expectation'],
             'source_silence': case['source_silence']}
    body = '```gherkin\n' + '\n'.join(lines) + '\n```\n\n## Literal annex\n' + fenced(compact(annex))
    body += '\n\nExecute available modes only. For absent sync/async streaming methods assert method absence and zero requests on success and error paths. Compare exact typed/raw normalized result; assert named errors and typed parameters, denied paths return no success. Schemas remain in approved immutable JSON with matching case hash.'
    comment('TESTCASE-077', case['case_id'] + ' ' + case['operation'], body)

absent = [c['operation'] for c in cases['operations'] if not c['available_modes']['sync_stream']]
journey = cases['journeys'][0]
steps = journey['steps']
assert len(absent) == 5 and len(steps) == 12
lines = ['Feature: J12-REST075 synthetic lifecycle', '', '  Scenario: Preserve schedule/build/checkpoint/health identities and pause state',
         '    Given frozen source and all83 bound source/assets match',
         '    And sockets/DNS are denied and prepared SDK1.101.0 uses synthetic transport']
lines += ['    When step ' + str(i) + ' calls ' + s['operation'] + ' for ' + s['name'] for i, s in enumerate(steps, 1)]
lines += ['    Then exact literals, relationships and final pause state match lifecycle annex',
          '    And STARTED_TIME uses separate synthetic server metadata',
          '    And fixture results establish no actual service filtering, enrollment permissions or persisted state']
comment('TESTCASE-077', 'J12 synthetic lifecycle and source-mode availability',
        '```gherkin\n' + '\n'.join(lines) + '\n```\n\n' + fenced(compact(journey)) +
        '\n\n## Mode expectations\nAll29 typed/raw sync/async; exactly24 sync/async streams. Five absent stream methods: ' + ', '.join(absent) +
        '. Assert zero requests for absent paths. No source-exposed SSE. Finite two-page pagination uses terminal tokens, timeout7 and zero retry; malformed response rejection, response/transport closure and stream byte/chunk budgets remain required. Probe all seven socket/DNS traps before SDK calls.')

elapsed = previous_machine_seconds + time.perf_counter() - started
comment('TESTCASE-077', 'Case DoD and independent approval evidence',
        '## Completion\nAll29 Gherkin cases with exact API/functions and request/result/error literal annexes are now tracker comments; all44 declared errors, source-backed24 available streams/five absent methods, and12-step synthetic lifecycle included. Existing real implementation verified by DEV077/UNIT077 Resolved, independent CODEREVIEW078 Closed and matching83 source/asset hashes. Approved immutable case/harness sidecar .ept/tmp/rest075_case_approval_20261029.json records APPROVED_CASES_AND_HARNESS; original rejected bundle preserved. No formal SDK execution performed during staging.\n'
        'Measured validation and posting elapsed ' + str(elapsed) + ' seconds (' + str(elapsed / 3600) + ' hours), machine workflow time only. Contributor authoring/review effort remains unmeasured. Existing indexed design scope unchanged, required links remain; no unresolved linked QUESTION. All current-state DoD met for case resolution and closure.')
transition('TESTCASE-077', 'testcase', 'In Progress', 'Resolved', '--field', 'time_spent_hours=' + str(elapsed / 3600))
transition('TESTCASE-077', 'testcase', 'Resolved', 'Closed')
for ticket, status in [('TESTCASE-077', 'Closed'), ('DEV-077', 'Resolved'), ('UNITTEST-077', 'Resolved'), ('CODEREVIEW-078', 'Closed')]:
    assert 'current_status: ' + status in cli('get', ticket, '--author', 'qa-engineer')
for filename, digest in ready['source_asset_bindings'].items():
    assert hashlib.sha256(pathlib.Path(filename).read_bytes()).hexdigest() == digest, filename
comment('TESTEXEC-077', 'Independent formal execution plan and fresh gates',
        '## Plan\nSeparate executor runs only approved .ept/tmp/rest075_formal_execute.py (SHA256 ' + approval['harness_sha256'] + ') against approved cases SHA256 ' + approval['cases_sha256'] + '. Readiness SHA256 5e8d619a789e5adafc405f5bc5abe9b072f3a35d2ce82abfc28dad35d5008e6e and all83 source/asset bindings freshly match. Actual TESTCASE077 Closed, DEV077 and UNITTEST077 Resolved; CODEREVIEW078 Closed is terminal independent approval because codereview has no Resolved state. No artificial review state or terminal edits.\n'
        'Prepared local SDK1.101.0/httpx and compiled real examples provide runnable fixture environment; existing independent214-pass guarded unit proof establishes accessibility. Execute29 operations/all44 named errors in source-exposed sync/async typed/raw and24 stream modes; assert five absences without requests, finite two-page iteration, timeout7/zero retry, malformed decode, closure/budgets, all seven denial probes and12 synthetic lifecycle steps. Record exact results, failures and bounds; synthetic outcomes establish no live deployment, permissions or server effects. Preserve prior rejected bundle. Do not run until actual In Progress readback. This staging performed no formal execution. Executor records its own measured runtime and evidence; authoring effort remains unmeasured. Indexed approved BA-DES015/SA-DES014 and REST authoring contract reviewed; no linked unresolved QUESTION.')
transition('TESTEXEC-077', 'testexec', 'Open', 'In Progress')
for ticket in ['TESTCASE-077', 'TESTEXEC-077']:
    cli('get', ticket, '--author', 'qa-engineer')
    cli('comment', 'list', ticket, '--author', 'qa-engineer')
print(json.dumps({'transcript': str(LOG), 'sha256': hashlib.sha256(LOG.read_bytes()).hexdigest(),
                  'case_status': 'Closed', 'execution_status': 'In Progress', 'formal_run': False,
                  'commands': len(records), 'posting_validation_seconds': elapsed}, indent=2))
