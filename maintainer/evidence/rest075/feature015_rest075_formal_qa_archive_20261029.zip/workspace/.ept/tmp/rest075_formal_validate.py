"""Validate prepared literals, lifecycle links, and local document bindings without transport calls."""
import ast
import copy
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import time
import typing

import pydantic

tmp = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rest075_formal_harness', tmp / 'rest075_formal_execute.py')
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
manifest = json.loads((tmp / 'rest075_formal_cases.json').read_bytes())
started = time.perf_counter()
harness.preflight(manifest)
checks = []
by_id = {row['operation']: row for row in manifest['operations']}
assert len(by_id) == 29
assert sum(len(row['errors']) for row in manifest['operations']) == 44
absent = [row['operation'] for row in manifest['operations'] if not row['available_modes']['sync_stream']]
assert absent == ['v2.data_health.Check.delete', 'v2.orchestration.Build.cancel',
                  'v2.orchestration.Schedule.delete', 'v2.orchestration.Schedule.pause',
                  'v2.orchestration.Schedule.unpause']
oracle_path = tmp / 'feature015_integration/tests/fixtures/offline/rest-acceptance/source-oracle.json'
oracle = json.loads(oracle_path.read_bytes())
for row in manifest['operations']:
    assert row['source']['sha256'] == oracle['operations'][row['operation']]['source_sha256']
    module = importlib.import_module(row['source']['module'])
    name, method = row['operation'].split('.')[-2:]
    cls = getattr(module, name + 'Client')
    tree = ast.parse(Path(module.__file__).read_text())
    for prefix, label in (('_', 'sync'), ('_Async', 'async')):
        for suffix, mode in (('Raw', 'raw'), ('Streaming', 'stream')):
            wrapper = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == prefix + name + 'Client' + suffix)
            exists = any(isinstance(node, ast.Assign) and any(isinstance(target, ast.Attribute) and target.attr == method
                         and isinstance(target.value, ast.Name) and target.value.id == 'self' for target in node.targets)
                         for node in ast.walk(wrapper))
            assert exists == row['available_modes'][label + '_' + mode]
    hints = typing.get_type_hints(getattr(cls, method), include_extras=True)
    source_errors = eval(row['source']['request_expressions']['throwable_errors'], vars(module))
    assert set(source_errors) == {error['name'] for error in row['errors']}
    for asset in row['assets'].values():
        path = harness.SKILL / asset['path']
        if path.suffix == '.py':
            ast.parse(path.read_text(encoding='utf-8'))
        else:
            assert method in path.read_text(encoding='utf-8'), str(path)
    for error in row['errors']:
        schema = error['parameter_schema']
        assert all(key in error['parameters'] for key in schema.get('required', []))
        if error['name'] == 'CheckAlreadyExists':
            assert error['parameters']['conflictingCheck']['config'] == error['request']['config']
        if error['name'].startswith('Invalid'):
            assert 'config' in error['request']
    for extra in row['additional_cases']:
        if 'expected_exception' not in extra:
            continue
        if extra['name'] == 'required argument omitted':
            assert extra['omitted_parameter'] not in extra['request']
            continue
        rejected = False
        for key, value in extra['request'].items():
            try:
                pydantic.TypeAdapter(hints[key]).validate_python(value)
            except pydantic.ValidationError:
                rejected = True
        assert rejected, (row['operation'], extra['name'])
    for extra in row.get('execution_error_variants', []):
        for key, value in extra['kwargs'].items():
            pydantic.TypeAdapter(hints[key]).validate_python(value)
        assert extra['name'] not in source_errors
    checks.append({'operation': row['operation'], 'declared_errors': len(row['errors']),
                   'literal_shapes': 'PASS', 'source_oracle_binding': 'PASS'})
for journey in manifest['journeys']:
    assert len(journey['steps']) <= journey['max_requests_per_mode']
    for step in journey['steps']:
        row = by_id[step['operation']]
        module = importlib.import_module(row['source']['module'])
        declared = eval(row['source']['request_expressions']['response_type'], vars(module))
        pydantic.TypeAdapter(declared).validate_python(step['success']['json'])
        harness.semantic_check(row, row['request']['kwargs'], step['success']['json'], step['name'])
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = {'execution': 'NOT_RUN', 'approval': 'PENDING_INDEPENDENT_REVIEW', 'static_preflight': 'PASS',
          'operations': checks, 'declared_errors': 44, 'elapsed_seconds': time.perf_counter() - started,
          'cases_sha256': sha(tmp / 'rest075_formal_cases.json'),
          'harness_sha256': sha(tmp / 'rest075_formal_execute.py'),
          'checks': ['Pinned SDK source hashes and source-declared error equality',
                     'Every request/result/error literal and valid additional case validates',
                     'Invalid batch lengths rejected by source annotations',
                     'Lifecycle response literals validate without invoking SDK operations',
                     'Candidate assets hash and parse; local method references exist'],
          'scope': 'Static shape and binding checks only. Independent semantic review and execution remain pending.'}
(tmp / 'rest075_formal_static_validation.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: report[key] for key in ('static_preflight', 'declared_errors', 'elapsed_seconds', 'cases_sha256', 'harness_sha256')}))
