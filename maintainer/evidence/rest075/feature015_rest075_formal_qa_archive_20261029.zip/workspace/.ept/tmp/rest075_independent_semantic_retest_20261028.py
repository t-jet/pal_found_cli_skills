"""Independent source and semantic retest for the current 29 REST075 examples."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib
import inspect
import json
from pathlib import Path
import re
import runpy
import socket
import subprocess
import sys
import textwrap
import time

import httpx

TMP = Path(__file__).resolve().parent
ROOT = TMP.parents[1]
REPO = TMP / 'feature015_integration'
OWNER = REPO / '.agents/skills/pal-found-dev'
OUT = TMP / 'feature015_rest075_semantic_retest_20261028.json'
REGISTER = json.loads((REPO / 'maintainer/rest-domain-authoring-register.json').read_bytes())
CONTRACTS = {row['id']: row for row in json.loads(
    (REPO / 'maintainer/rest-contract-register.json').read_bytes())['operations']}
ORACLE = json.loads((REPO / 'tests/fixtures/offline/rest-acceptance/source-oracle.json').read_bytes())
INITIAL_PATH = TMP / 'feature015_rest075_j12_readiness_20261027.json'
INITIAL = json.loads(INITIAL_PATH.read_bytes())
OLD = {row['id']: row for row in INITIAL['operations']}
AUTHOR_PATH = TMP / 'rest075_author_validation_20261028.json'
ROWS = [row for row in REGISTER['operations'] if row['story'] == 'DEV-STORY-075']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert len(ROWS) == 29
assert sha(AUTHOR_PATH) == '0129d47e92d5e42b391b844fcec16b16684ce8b75f2ddd2e51df81c7c5200273'
report = {
    'story': 'DEV-STORY-075', 'reviewer_agent': '/root/rest075_qa_20261028',
    'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'review_date': '2026-10-28 Europe/Sofia', 'sdk_release': '1.101.0',
    'initial_review': {'path': str(INITIAL_PATH), 'sha256': sha(INITIAL_PATH)},
    'author_evidence': {'path': str(AUTHOR_PATH), 'sha256': sha(AUTHOR_PATH)},
    'operations': [], 'commands': [],
    'formal_qa_status': 'pending',
    'scope': 'Independent manual semantic review and current source/contract/asset binding for all29 operations; actual mocked HTTP success/error fixtures and dedicated sync-raw unit tests. No shared files or tracker changed.',
    'limits': [
        'Synthetic SDK HTTP fixtures are not live enrollment or actual server effects.',
        'Build search STARTED_TIME has Any type in frozen SDK. UTC value is meaningful example input, not proof of server acceptance or filtering; no returned startedTime field exists to prove filtering.',
        'Four batch responses demonstrate source-valid requested/found/omitted identity maps; synthetic omission is not proof of the service reason or current authorization.',
        'Declared error fixtures verify typed envelopes and self-consistent error parameters, not a complete adverse-input reproduction for each service error.',
        'The dedicated86 tests cover sync-raw successes/errors and semantic mutations. Actual async/stream lifetime and finite-page runtime coverage still need applicable UNIT/TESTEXEC readiness evidence; no full UNIT077 lifecycle closure is approved here.',
        'J12 source-blind reader acceptance, formal source-authored case/execution approval and publication remain separate gates.',
    ],
}

def save():
    OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def denied(*args, **kwargs):
    raise AssertionError('Independent REST075 probe denied public network')

for attr in ('connect', 'connect_ex'):
    setattr(socket.socket, attr, denied)
for attr in ('create_connection', 'getaddrinfo', 'gethostbyname', 'gethostbyname_ex'):
    setattr(socket, attr, denied)
httpx.HTTPTransport.handle_request = denied
httpx.AsyncHTTPTransport.handle_async_request = denied
try:
    socket.getaddrinfo('offline.invalid', 443)
except AssertionError:
    report['network_guard_self_test'] = True
else:
    raise AssertionError('Network denial guard failed')

manual_notes = {
    'Record': 'Checkpoint record identity/justification and returned processing context do not establish downstream success. Batch demonstrates found+omitted IDs; checkpoint search text matches synthetic justification.',
    'Check': 'Configuration and report lifecycles remain distinct. NumericColumnRange request/success discriminators agree. Empty bounds are permitted by frozen shape, without asserting tenant validity. Type-change error now has distinct valid columnType→numericColumnRange tags matching submitted new type.',
    'CheckReport': 'Read report identity and PASSED evaluation payload separately from check configuration. get_latest returns a bounded synthetic response, not live ordering or historical completeness.',
    'Build': 'RUNNING submission differs from completion and cancellation acknowledgment. Job association and batch identities are retained. STARTED_TIME uses an illustrative timezone-aware UTC gte value with explicit source-Any/server-validation boundary.',
    'Job': 'Returned job metadata/status is observational and does not launch or retry work. Found+omitted batch correlates requested map key and inner RID.',
    'Schedule': 'User/project scope and recurring configuration are separate from run completion. Create/replace preserve submitted upstream target and empty ignored set; pause/delete/unpause responses acknowledge only. Batch returns requested found RID and omits separate requested RID.',
    'ScheduleVersion': 'Version identity and associated current Schedule are separate reads. Caller compares current schedule with intended resource rather than treating version record as a submission.',
}

before_hashes = {}
for row in ROWS:
    identity = row['id']
    _, service, resource, method = identity.split('.')
    module = importlib.import_module('foundry_sdk.v2.' + service + '.' + re.sub(r'(?<!^)(?=[A-Z])', '_', resource).lower())
    source = Path(module.__file__)
    client = getattr(module, resource + 'Client')
    method_text = textwrap.dedent(inspect.getsource(getattr(client, method)))
    fn = ast.parse(method_text).body[0]
    c = CONTRACTS[identity]
    source_hash = sha(source)
    assert source_hash == row['source_sha256'] == ORACLE['operations'][identity]['source_sha256'] == OLD[identity]['source_sha256']
    assert ast.dump(fn.args) == ast.dump(ast.parse('def f(' + c['signature'] + '): pass').body[0].args)
    info = next(node for node in ast.walk(fn) if isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute) and node.func.attr == 'RequestInfo')
    wire = {item.arg: item.value for item in info.keywords}
    assert all(ast.dump(wire[name]) == ast.dump(ast.parse(value, mode='eval').body) for name, value in c['wire'].items())
    behavior = OWNER / row['behavior']
    example = OWNER / row['example']
    contract = OWNER / c['contract']
    assert sha(behavior) == OLD[identity]['behavior_sha256']
    assert sha(contract) == OLD[identity]['contract_sha256']
    namespace = runpy.run_path(str(example))
    error_names = {error['name'] for error in namespace['ERRORS']}
    throwable = next(kw.value for kw in info.keywords if kw.arg == 'throwable_errors')
    source_error_names = set(ast.literal_eval(key) for key in throwable.keys)
    assert error_names == source_error_names
    start = time.perf_counter()
    namespace['verify']()
    item = {
        'id': identity, 'verdict': 'PASS', 'prior_verdict': OLD[identity]['verdict'],
        'source_module': str(source), 'source_sha256': source_hash,
        'source_method_sha256': hashlib.sha256(method_text.encode()).hexdigest(),
        'source_doc_sha256': row['doc_sha256'], 'stage': c['stage'],
        'behavior_path': row['behavior'], 'behavior_sha256': sha(behavior),
        'example_path': row['example'], 'example_sha256': sha(example),
        'contract_path': c['contract'], 'contract_sha256': sha(contract),
        'declared_errors': sorted(error_names), 'declared_error_count': len(error_names),
        'actual_sdk_http_fixture': 'PASS', 'elapsed_seconds': time.perf_counter() - start,
        'manual_semantic_review': manual_notes[resource],
        'source_signature_and_all_wire_expressions': 'PASS',
    }
    for path in (source, behavior, example, contract):
        before_hashes[str(path)] = sha(path)
    report['operations'].append(item)
    save()

test = REPO / 'tests/test_offline_rest_075.py'
test_hash = sha(test)
for command in (
    [sys.executable, '-m', 'pytest', str(test), '-q', '--basetemp=' + str(TMP / 'rest075_independent_basetemp_20261028'), '-o', 'cache_dir=' + str(TMP / 'rest075_independent_pytest_cache_20261028')],
    ['ruff', 'check', str(test)],
):
    start = time.perf_counter()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
    report['commands'].append({'command': command, 'exit_code': result.returncode,
                               'elapsed_seconds': time.perf_counter() - start,
                               'stdout': result.stdout, 'stderr': result.stderr})
    save()
    assert result.returncode == 0, result.stdout + result.stderr
assert sha(test) == test_hash
assert all(sha(Path(path)) == expected for path, expected in before_hashes.items())
report['asset_stability_after_execution'] = True
report['unit_test_path'] = str(test)
report['unit_test_sha256'] = test_hash
report['unit_review'] = {
    'verdict': 'PASS_WITH_SCOPE_LIMITS',
    'meaningful_guards': ['16 batch map/RID mutations', '4 schedule target mutations',
                          '2 unsupported type-change mutations', '1 invalid timestamp mutation',
                          '4 invalid batch element pre-HTTP failures'],
    'frozen_source_binding': True,
    'not_entire_unit_ticket_acceptance': True,
}
report['counts'] = dict(Counter(row['verdict'] for row in report['operations']))
report['source_declared_error_count'] = sum(row['declared_error_count'] for row in report['operations'])
report['completed_at_utc'] = datetime.now(timezone.utc).isoformat()
save()
print(json.dumps({'semantic': report['counts'], 'declared_errors': report['source_declared_error_count'],
                  'report': str(OUT), 'sha256': sha(OUT)}))
