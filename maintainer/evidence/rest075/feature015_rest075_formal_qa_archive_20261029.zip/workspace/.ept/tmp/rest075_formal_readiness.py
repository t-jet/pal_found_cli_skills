"""Bind REST075 preparation to current source, candidate assets, and live CLI ticket state."""
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

tmp = Path(__file__).resolve().parent
workspace = tmp.parents[1]
repo = tmp / 'feature015_integration'
owner = repo / '.agents/skills/pal-found-dev'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
manifest_path = tmp / 'rest075_formal_cases.json'
manifest = json.loads(manifest_path.read_bytes())
bindings = {}
for row in manifest['operations']:
    bindings[row['source']['path']] = row['source']['sha256']
    for asset in row['assets'].values():
        bindings[str(owner / asset['path'])] = asset['sha256']
    for error in row['errors']:
        bindings[error['error_source']] = error['error_source_sha256']
for name in ('foundry_sdk.v2.checkpoints.models', 'foundry_sdk.v2.data_health.models',
             'foundry_sdk.v2.orchestration.models', 'foundry_sdk.v2.core.models',
             'foundry_sdk._core.api_client', 'foundry_sdk._core.model_base',
             'foundry_sdk._core.resource_iterator'):
    path = Path(importlib.import_module(name).__file__)
    bindings[str(path)] = sha(path)
for path, expected in bindings.items():
    assert sha(path) == expected, path
commands = []
for ticket in ('DEV-STORY-075', 'DESIGN-077', 'DEV-077', 'UNITTEST-077', 'CODEREVIEW-078',
               'TESTCASE-077', 'TESTEXEC-077', 'BUG-SUB-025'):
    args = [sys.executable, str(workspace / '.ept/tools/tracker/tracker_cli.py'), 'get', ticket, '--author', 'qa-engineer']
    start = time.perf_counter()
    result = subprocess.run(args, cwd=workspace, capture_output=True, encoding='utf-8',
                            env=dict(os.environ, PYTHONIOENCODING='utf-8'))
    commands.append({'command': args, 'exit_code': result.returncode,
                     'elapsed_seconds': time.perf_counter() - start,
                     'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0, result.stderr
artifacts = {str(path): sha(path) for name in ('cases.json', 'execute.py', 'build_cases.py', 'prepare.py',
             'semantics.py', 'prepare_harness.py', 'harness_extra.py', 'validate.py', 'static_validation.json',
             'execution.json') for path in [tmp / ('rest075_formal_' + name)]}
prior_evidence = {}
for name in ('maintainer/rest-domain-independent-review-075-current.json',
             'maintainer/rest-domain-unit-review-075.json', 'tests/test_offline_rest_075.py',
             'tests/fixtures/offline/rest-acceptance/source-oracle.json'):
    path = repo / name
    prior_evidence[str(path)] = sha(path)
attempts = []
for path in sorted(tmp.glob('rest075_formal_*attempt*_result.json')):
    record = json.loads(path.read_bytes())
    attempts.append({'path': str(path), 'sha256': sha(path), **record})
report = {'story': 'DEV-STORY-075', 'testcase': 'TESTCASE-077', 'testexec': 'TESTEXEC-077',
          'author_identity': manifest['author_identity'], 'created_at_utc': datetime.now(timezone.utc).isoformat(),
          'operations': len(manifest['operations']), 'declared_errors': sum(len(row['errors']) for row in manifest['operations']),
          'source_commit': manifest['source_commit'], 'sdk_release': manifest['sdk_release'],
          'candidate_head_at_binding': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
          'cases_sha256': sha(manifest_path), 'harness_sha256': sha(tmp / 'rest075_formal_execute.py'),
          'artifacts': artifacts, 'source_asset_bindings': bindings, 'prior_evidence_bindings': prior_evidence,
          'preparation_attempts': attempts, 'live_ticket_commands': commands,
          'first_three_measured_preparation_seconds': [row['preparation_elapsed_seconds'] for row in manifest['operations'][:3]],
          'execution': 'NOT_RUN', 'approval': 'PENDING_INDEPENDENT_REVIEW',
          'available_modes': {row['operation']: row['available_modes'] for row in manifest['operations']},
          'streaming_absent_operations': [row['operation'] for row in manifest['operations'] if not row['available_modes']['sync_stream']],
          'workflow_gaps': ['DEV-077 and UNITTEST-077 remain In Progress; CODEREVIEW-078 remains Blocked in observed CLI state.',
                            'Fresh independent reviewer must review exact cases and harness, then TESTCASE-077 may progress under its actual DoD.',
                            'TESTEXEC-077 requires closed TESTCASE and reviewed runnable implementation plus separate fresh executor.',
                            'BUG-SUB-025 closure and prior J12 evidence do not waive all29 formal operation assertions.'],
          'required_execution': {'command': 'python .ept/tmp/rest075_formal_execute.py --execute --executor-identity <fresh-executor> --reviewer-identity <fresh-reviewer> --testcase-closed TESTCASE-077 --approved-cases-sha256 <cases-hash> --approved-harness-sha256 <harness-hash> --readiness-confirmed',
                                 'network': 'Deny socket connect/connect_ex/create_connection and all DNS entry points; seven active denial probes.',
                                 'modes': 'Every operation sync/async typed/raw success and named errors. Streaming success/errors apply to24 operations with source-exposed wrappers; five void methods assert and record streaming absence with zero requests. Source-declared iterators finite sync/async; timeout no retry, malformed JSON, optional omissions, required arguments and batch bounds.',
                                 'journey': 'Twelve bounded synthetic schedule/build/job/checkpoint/health/pause/unpause steps, denied preflight stops mutation. Separate integrated J12 evidence owns file transaction verification.'},
          'limits': ['Static preparation validates schema shapes, hashes and semantic links only. No SDK operation or example invoke/verify executed by case author.',
                     'Synthetic enrollment metadata interprets STARTED_TIME separately from Build.createdTime. Any filter values require authorized server verification.',
                     'Fixture transport does not prove real scheduling, permissions, persisted lifecycle state, health execution, transaction commits or idempotency.']}
out = tmp / 'rest075_formal_readiness.json'
out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'operations': report['operations'], 'errors': report['declared_errors'],
                  'cases_sha256': report['cases_sha256'], 'harness_sha256': report['harness_sha256'],
                  'readiness_sha256': sha(out), 'bindings': len(bindings)}))
