import ast,importlib,json,re,inspect,typing,pydantic
from pathlib import Path
repo=Path('.ept/tmp/feature015_integration')
reg=json.loads((repo/'maintainer/rest-domain-authoring-register.json').read_bytes())
for a in reg['operations']:
 if a['story']!='DEV-STORY-075':continue
 v,s,r,m=a['id'].split('.')
 mod=importlib.import_module('foundry_sdk.'+v+'.'+s+'.'+re.sub(r'(?<!^)(?=[A-Z])','_',r).lower())
 t=ast.parse(Path(mod.__file__).read_text()); c=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name==r+'Client'); f=next(n for n in c.body if isinstance(n,ast.FunctionDef) and n.name==m)
 call=next(n for n in ast.walk(f) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='RequestInfo'); ex={k.arg:ast.unparse(k.value) for k in call.keywords}
 print(a['id'],inspect.signature(getattr(getattr(mod,r+'Client'),m)))
 for name,err in eval(ex['throwable_errors'],vars(mod)).items():print(' ERROR',name,{k:v.get('description',v.get('type','ref')) for k,v in pydantic.TypeAdapter(typing.get_type_hints(err)['parameters']).json_schema().get('properties',{}).items()})
