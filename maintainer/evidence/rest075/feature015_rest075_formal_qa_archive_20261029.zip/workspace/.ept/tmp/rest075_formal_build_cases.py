"""Prepare source-derived REST075 literals without reading example constants."""
import ast
import copy
from datetime import datetime, timezone
import hashlib
import importlib
import inspect
import json
from pathlib import Path
import re
import subprocess
import typing
import time
import pydantic

TMP = Path(__file__).resolve().parent
REPO = TMP / 'feature015_integration'
OWNER = REPO / '.agents/skills/pal-found-dev'
AUTHOR = '/root/rest075_formal_recover_20261029'
UUID = '00000000-0000-0000-0000-000000000075'
STAMP = '2026-10-29T08:00:00Z'
RID = lambda name: 'ri.qa.main.' + name.replace('_', '-') + '.independent075'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sample(node, root=None, name='', depth=0):
    root = node if root is None else root
    if '$ref' in node:
        return sample(root['$defs'][node['$ref'].split('/')[-1]], root, name, depth + 1)
    if 'const' in node:
        return node['const']
    if 'enum' in node:
        return node['enum'][0]
    for key in ('anyOf', 'oneOf'):
        if key in node:
            choices = [v for v in node[key] if v.get('type') != 'null']
            if not choices:
                return None
            choices.sort(key=lambda choice: any(term in choice.get('$ref', '') for term in ('NotFilter', 'AndFilter', 'OrFilter', 'AndTrigger', 'OrTrigger')))
            return sample(choices[0], root, name, depth + 1)
    kind = node.get('type')
    if kind == 'object':
        if node.get('properties'):
            return {k: sample(v, root, k, depth + 1) for k, v in node['properties'].items()
                    if k in node.get('required', []) or 'const' in v}
        if isinstance(node.get('additionalProperties'), dict) and depth < 10:
            return {'independent075': sample(node['additionalProperties'], root, name, depth + 1)}
        return {}
    if kind == 'array':
        return [sample(node.get('items', {}), root, name, depth + 1)] if depth < 12 else []
    if kind == 'integer':
        return max(node.get('minimum', 1), 1)
    if kind == 'number':
        return 0.5
    if kind == 'boolean':
        return True
    if kind == 'null':
        return None
    if node.get('format') == 'date-time':
        return STAMP
    if node.get('format') == 'date':
        return '2026-10-28'
    if node.get('format') == 'uuid' or '0-9a-fA-F' in node.get('pattern', ''):
        return UUID
    if node.get('pattern', '').startswith('^ri'):
        return RID(re.sub(r'(?<!^)(?=[A-Z])', '-', name or 'resource').lower())
    return 'independent075' if kind == 'string' else {}


def encode(value):
    if isinstance(value, bytes):
        return {'__bytes_hex__': value.hex()}
    if isinstance(value, pydantic.BaseModel):
        return encode(value.model_dump(mode='python', by_alias=True, exclude_none=True))
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(v) for v in value]
    return value


def wire(expressions, module, kwargs):
    context = dict(vars(module), **kwargs)
    result = {k: encode(eval(expressions[k], context))
              for k in ('method', 'resource_path', 'query_params', 'path_params', 'header_params', 'body')}
    result['query_params'] = {k: v for k, v in result['query_params'].items() if v is not None}
    return result


DATASET = RID('dataset-output')
SUBJECT = {'datasetRid': DATASET, 'branchId': 'master'}
TARGET = {'type': 'upstream', 'targetRids': [DATASET], 'ignoredRids': [RID('excluded-upstream')]}
CONFIG = {'type': 'numericColumnRange', 'subject': SUBJECT, 'columnName': 'amount',
          'numericBoundsConfig': {'numericBounds': {'lowerBound': 0, 'upperBound': 1000}, 'severity': 'MODERATE'}}
ACTION = {'target': TARGET, 'branchName': 'master', 'fallbackBranches': ['master'],
          'forceBuild': False, 'abortOnFailure': True, 'notificationsEnabled': False,
          'retryCount': 0, 'retryBackoffDuration': {'value': 5, 'unit': 'SECONDS'}}


def request_overrides(resource, method, kwargs):
    result = {'preview': True, 'page_size': 2, 'page_token': None, 'sort_direction': 'ASC',
              'config': CONFIG, 'intent': 'Validate output amounts', 'fallback_branches': ['master'],
              'branch_name': 'master', 'target': TARGET, 'action': ACTION,
              'abort_on_failure': True, 'force_build': False, 'notifications_enabled': False,
              'retry_count': 0, 'retry_backoff_duration': {'value': 5, 'unit': 'SECONDS'},
              'display_name': 'Independent075 output build', 'description': 'Build reviewed output dataset',
              'trigger': {'type': 'manual'}, 'scope_mode': {'type': 'project', 'projectRids': [RID('project')]}}
    if resource == 'Record':
        result['where'] = {'filter': {'type': 'textSearch', 'field': 'justificationResponse',
                                     'query': 'Approved output review', 'matchType': 'EXACT'}}
    if resource == 'Build':
        result['where'] = {'type': 'gte', 'field': 'STARTED_TIME', 'value': '2026-10-29T00:00:00Z'}
        result['order_by'] = None
    if method == 'get_batch':
        key = resource[0].lower() + resource[1:] + 'Rid'
        result['body'] = [{key: RID(resource.lower())}, {key: RID('omitted-' + resource.lower())}]
    return result


def result_model(resource):
    services = {'Record': 'checkpoints', 'Check': 'data_health', 'CheckReport': 'data_health'}
    module = importlib.import_module('foundry_sdk.v2.' + services.get(resource, 'orchestration') + '.models')
    return sample(pydantic.TypeAdapter(getattr(module, resource)).json_schema())


def rewrite_reply(value, resource, method, kwargs):
    if resource == 'ScheduleVersion' and method == 'schedule':
        return rewrite_reply(value, 'Schedule', 'get', {'schedule_rid': RID('schedule')})
    if method == 'get_batch':
        key = resource[0].lower() + resource[1:] + 'Rid'
        found = kwargs['body'][0][key]
        item = rewrite_reply(result_model(resource), resource, 'get', {resource.lower() + '_rid': found})
        return {'data': {found: item}}
    if isinstance(value, list):
        return [rewrite_reply(item, resource, method, kwargs) for item in value]
    if not isinstance(value, dict):
        return value
    if 'data' in value:
        child = 'Job' if resource == 'Build' and method == 'jobs' else 'ScheduleRun' if resource == 'Schedule' and method == 'runs' else resource
        return {'data': [rewrite_reply(item, child, 'get', kwargs) for item in value['data']]}
    value = copy.deepcopy(value)
    if resource == 'Record':
        value.update(rid=kwargs.get('record_rid', RID('record')), type='RUN_BUILD', scope='RESOURCE_SCOPED',
                     actingUser={'userId': UUID, 'username': {'value': 'independent-reviewer075'}},
                     checkpointedItems=[{'type': 'checkpointedJob', 'jobRid': RID('job')}],
                     createdAt=STAMP, justification={'type': 'responseJustification', 'response': 'Approved output review',
                                                   'prompt': 'Why run this build?', 'title': 'Build review'})
    elif resource == 'Check':
        value.update(rid=kwargs.get('check_rid', RID('check')), groups=[], config=copy.deepcopy(kwargs.get('config', CONFIG)))
        if kwargs.get('intent') is not None:
            value['intent'] = kwargs['intent']
    elif resource == 'CheckReport':
        value.update(rid=kwargs.get('check_report_rid', RID('check-report')),
                     check=rewrite_reply(result_model('Check'), 'Check', 'get', kwargs), createdTime=STAMP)
    elif resource == 'Build':
        value.update(rid=kwargs.get('build_rid', RID('build')), branchName=kwargs.get('branch_name') or 'master',
                     createdTime=STAMP, createdBy=UUID, fallbackBranches=kwargs.get('fallback_branches', ['master']),
                     jobRids=[RID('job')], retryCount=0, retryBackoffDuration={'value': 5, 'unit': 'SECONDS'},
                     abortOnFailure=True, status='RUNNING')
    elif resource == 'Job':
        value.update(rid=kwargs.get('job_rid', RID('job')), buildRid=kwargs.get('build_rid', RID('build')),
                     startedTime=STAMP, jobStatus='RUNNING', outputs=[{'type': 'datasetJobOutput', 'datasetRid': DATASET}])
    elif resource == 'Schedule' and method == 'run':
        return rewrite_reply(value, 'ScheduleRun', method, kwargs)
    elif resource == 'Schedule' and method == 'get_affected_resources':
        return {'datasets': [DATASET]}
    elif resource in ('Schedule', 'ScheduleVersion'):
        value.update(rid=kwargs.get('schedule_rid' if resource == 'Schedule' else 'schedule_version_rid', RID('schedule' if resource == 'Schedule' else 'schedule-version')),
                     action=copy.deepcopy(kwargs.get('action', ACTION)), scopeMode=copy.deepcopy(kwargs.get('scope_mode') or {'type': 'project', 'projectRids': [RID('project')]}),
                     createdTime=STAMP, createdBy=UUID, trigger=copy.deepcopy(kwargs.get('trigger') or {'type': 'manual'}))
        if resource == 'Schedule':
            value.update(currentVersionRid=RID('schedule-version'), updatedTime=STAMP, updatedBy=UUID, paused=False)
            for arg, alias in [('display_name', 'displayName'), ('description', 'description')]:
                if kwargs.get(arg) is not None:
                    value[alias] = kwargs[arg]
        else:
            value['scheduleRid'] = RID('schedule')
    elif resource == 'ScheduleRun':
        value.update(rid=RID('schedule-run'), scheduleRid=kwargs.get('schedule_rid', RID('schedule')),
                     scheduleVersionRid=RID('schedule-version'), createdTime=STAMP,
                     result={'type': 'submitted', 'buildRid': RID('build')})
    return value


def adverse(name, params, kwargs, resource, method, reply):
    conditions = ['Synthetic service denies or cannot find the exact requested resource; fixture proves SDK decoding only.']
    if name == 'CheckAlreadyExists':
        params['conflictingCheck'] = copy.deepcopy(reply)
        conditions = ['An accessible existing check has exactly the requested subject and config; the service returns that check as the conflict.']
    if name == 'CheckTypeNotSupported':
        params['checkType'] = kwargs.get('config', CONFIG)['type']
        conditions = ['Synthetic enrollment does not expose this requested or stored check type; the SDK declares no universal supported subset.']
    if name == 'ModifyingCheckTypeNotSupported':
        params.update(originalCheckType='columnType', newCheckType=kwargs['config']['type'])
        conditions = ['Existing check has columnType config. Replacement requests numericColumnRange. Changing type is unsupported.']
    invalid = {
        'InvalidNumericColumnCheckConfig': ('numericColumnMean', 'numericColumnCheckConfig', {'columnName': 'amount'}),
        'InvalidPercentageCheckConfig': ('nullPercentage', 'percentageCheckConfig', {'columnName': 'amount'}),
        'InvalidTimeCheckConfig': ('buildDuration', 'timeCheckConfig', {}),
        'InvalidTransactionTimeCheckConfig': ('timeSinceLastUpdated', 'timeCheckConfig', {}),
        'InvalidTrendConfig': ('numericColumnMean', 'numericColumnCheckConfig', {'columnName': 'amount', 'trend': {'severity': 'MODERATE'}})}
    if name in invalid:
        kind, key, config = invalid[name]
        kwargs['config'] = {'type': kind, 'subject': copy.deepcopy(SUBJECT), key: copy.deepcopy(config)}
        conditions = ['Adverse config omits both alternatives required by the source error description. Pydantic accepts the shape; synthetic service rejects its semantic condition.']
        if method == 'replace':
            conditions.append('Existing check has the same type as this adverse replacement; only the invalid nested config changes.')
    return params, kwargs, conditions


def domain_extras(row, resource, method, kwargs, reply, defaults, expressions, module):
    tree = ast.parse(Path(module.__file__).read_text())
    def wrapper_has(class_name):
        wrapper = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name)
        return any(isinstance(node, ast.Assign) and any(isinstance(target, ast.Attribute) and target.attr == method
                   and isinstance(target.value, ast.Name) and target.value.id == 'self' for target in node.targets)
                   for node in ast.walk(wrapper))
    row['available_modes'] = {'sync_typed': True, 'async_typed': True,
                              'sync_raw': wrapper_has('_' + resource + 'ClientRaw'),
                              'async_raw': wrapper_has('_Async' + resource + 'ClientRaw'),
                              'sync_stream': wrapper_has('_' + resource + 'ClientStreaming'),
                              'async_stream': wrapper_has('_Async' + resource + 'ClientStreaming')}
    extras = row['additional_cases']
    for extra in extras:
        if extra['name'] == 'optional omission':
            extra['response'] = rewrite_reply(sample(row['success']['schema']), resource, method, extra['request'])
            extra['success']['json'] = copy.deepcopy(extra['response'])
            extra['source_condition'] = 'Synthetic enrollment returns the selected optional values. This fixture does not establish platform defaults for omitted trigger, scope, branch or other options.'
        if extra['name'] == 'finite continuation':
            first = extra['responses'][0]['data'][0]
            second = extra['responses'][1]['data'][0]
            if isinstance(second, dict) and 'rid' in second:
                second['rid'] = RID('second-page-' + resource.lower())
    if resource == 'ScheduleVersion' and method == 'schedule':
        extras.append({'name': 'schedule absent for retained version', 'request': copy.deepcopy(kwargs),
                       'expected_wire': wire(expressions, module, kwargs), 'success': {'http_status': 200, 'json': None}})
    if method == 'get_batch':
        limit = row['request']['argument_schemas']['body']['maxItems']
        for count in (0, limit + 1):
            bad = copy.deepcopy(kwargs)
            bad['body'] = kwargs['body'][:1] * count
            extras.append({'name': 'batch length ' + str(count), 'request': bad,
                           'expected_exception': 'pydantic.ValidationError', 'expected_request_count': 0})
    if resource == 'Build' and method == 'search':
        row['source_silence'].append('SearchBuildsGteFilter.value is Any. UTC string is illustrative and requires enrollment verification; SDK acceptance is not server validation.')
        row['search_state'] = {'started_time_by_build_rid': {
            RID('build'): '2026-10-29T08:00:00Z',
            RID('second-page-build'): '2026-10-29T09:00:00Z'},
            'boundary': 'Synthetic server start metadata supports the filter. Build.createdTime is not asserted to be STARTED_TIME.'}
        bad = copy.deepcopy(kwargs)
        bad['where']['value'] = {'unsupported': 'time-object'}
        row['execution_error_variants'] = [{'name': 'InvalidSearchTimestamp075', 'status': 400,
            'errorCode': 'INVALID_ARGUMENT', 'parameters': {'field': 'STARTED_TIME'}, 'kwargs': bad,
            'expected_wire': wire(expressions, module, bad)}]
        row['execution_variants'] = []


def make_journeys(rows):
    by_id = {row['operation']: row for row in rows}
    steps = []
    sequence = [('schedule', 'Schedule.get'), ('submitted', 'Schedule.run'),
                ('running', 'Build.get'), ('succeeded', 'Build.get'), ('job', 'Job.get'),
                ('checkpoint', 'Record.get'), ('check', 'Check.get'), ('report', 'CheckReport.get'),
                ('pause', 'Schedule.pause'), ('paused', 'Schedule.get'),
                ('unpause', 'Schedule.unpause'), ('unpaused', 'Schedule.get')]
    for label, suffix in sequence:
        service = 'checkpoints' if suffix.startswith('Record.') else 'data_health' if suffix.startswith(('Check.', 'CheckReport.')) else 'orchestration'
        operation = 'v2.' + service + '.' + suffix
        success = copy.deepcopy(by_id[operation]['success'])
        value = success['json']
        if label == 'succeeded':
            value.update(status='SUCCEEDED', finishedTime='2026-10-29T08:03:00Z')
        if label == 'job':
            value.update(jobStatus='SUCCEEDED', finishedTime='2026-10-29T08:02:59Z')
            value['outputs'][0]['outputTransactionRid'] = RID('transaction')
        if label == 'paused':
            value['paused'] = True
        if label in ('checkpoint', 'report'):
            value['createdAt' if label == 'checkpoint' else 'createdTime'] = '2026-10-29T08:04:00Z'
        steps.append({'name': label, 'operation': operation, 'success': success})
    return [{'id': 'J12-REST075', 'steps': steps, 'max_requests_per_mode': 12,
             'max_build_observations': 2, 'adverse': 'Denied schedule read stops before run.',
             'boundary': 'This REST partition links synthetic state only. Transaction file verification belongs to separate J12 integrated evidence; no real build or data persistence is claimed.'}]


domain = json.loads((REPO / 'maintainer/rest-domain-authoring-register.json').read_bytes())
oracle_path = REPO / 'tests/fixtures/offline/rest-acceptance/source-oracle.json'
oracle = json.loads(oracle_path.read_bytes())
rows = []
validation_gaps = []
for index, asset in enumerate((r for r in domain['operations'] if r['story'] == 'DEV-STORY-075'), 1):
    operation_start = time.perf_counter()
    version, service, resource, method = asset['id'].split('.')
    module_name = 'foundry_sdk.' + version + '.' + service + '.' + re.sub(r'(?<!^)(?=[A-Z])', '_', resource).lower()
    module = importlib.import_module(module_name)
    source_path = Path(module.__file__)
    source = source_path.read_text()
    tree = ast.parse(source)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == resource + 'Client')
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == method)
    call = next(n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'RequestInfo')
    expressions = {kw.arg: ast.unparse(kw.value) for kw in call.keywords}
    assert sha(source_path) == oracle['operations'][asset['id']]['source_sha256']
    schemas, kwargs = {}, {}
    for arg in [*fn.args.args, *fn.args.kwonlyargs]:
        if arg.arg in ('self', '_sdk_internal', 'request_timeout'):
            continue
        annotation = eval(ast.unparse(arg.annotation), vars(module))
        schemas[arg.arg] = pydantic.TypeAdapter(annotation).json_schema()
        kwargs[arg.arg] = sample(schemas[arg.arg], name=arg.arg)
    defaults = {arg.arg for arg, default in zip(fn.args.kwonlyargs, fn.args.kw_defaults) if default is not None and arg.arg in kwargs}
    for name in defaults:
        kwargs[name] = None
    kwargs.update({k: RID(k.removesuffix('_rid')) for k in kwargs if k.endswith('_rid')})
    overrides = request_overrides(resource, method, kwargs)
    kwargs.update({k: copy.deepcopy(v) for k, v in overrides.items() if k in kwargs})
    response_type = eval(expressions['response_type'], vars(module))
    response_schema = pydantic.TypeAdapter(response_type).json_schema()
    reply = rewrite_reply(sample(response_schema), resource, method, kwargs)
    success = {'http_status': 204 if response_type is None else 200, 'json': reply, 'result_type': expressions['response_type'], 'schema': response_schema}
    if response_type is bytes:
        binary = (b'[{"score":0.75}]' if method == 'json' else b'PAR1-independent075-fixture-PAR1') if resource != 'Session' else b'event: complete\ndata: {"message":"done"}\n\n'
        success = {'http_status': 200, 'content_hex': binary.hex(), 'expected_bytes_hex': binary.hex(), 'result_type': 'bytes', 'schema': response_schema,
                   'boundary': 'Synthetic bytes exercise lifetime and exact persistence only; PAR1 marker is not a valid Parquet artifact.'}
    expected_wire = wire(expressions, module, kwargs)
    errors = []
    mapping = {'BadRequestError': (400, 'INVALID_ARGUMENT'), 'InternalServerError': (500, 'INTERNAL'),
               'UnauthorizedError': (401, 'UNAUTHORIZED'), 'UnprocessableEntityError': (422, 'INVALID_ARGUMENT'),
               'NotFoundError': (404, 'NOT_FOUND'), 'PermissionDeniedError': (403, 'PERMISSION_DENIED'),
               'InvalidArgumentError': (400, 'INVALID_ARGUMENT'), 'ConflictError': (409, 'CONFLICT'),
               'InternalError': (500, 'INTERNAL'), 'FailedPreconditionError': (400, 'FAILED_PRECONDITION'),
               'RequestEntityTooLargeError': (413, 'REQUEST_ENTITY_TOO_LARGE'), 'TimeoutError': (500, 'TIMEOUT'),
               'CustomClientError': (400, 'CUSTOM_CLIENT'), 'CustomServerError': (500, 'CUSTOM_SERVER')}
    for error_name, error_class in eval(expressions['throwable_errors'], vars(module)).items():
        parameter_type = typing.get_type_hints(error_class)['parameters']
        error_schema = pydantic.TypeAdapter(parameter_type).json_schema()
        params = sample(error_schema)
        error_kwargs = copy.deepcopy(kwargs)
        available = dict(expected_wire['query_params'], **expected_wire['path_params'])
        if isinstance(expected_wire['body'], dict):
            available.update(expected_wire['body'])
        params.update({k: copy.deepcopy(v) for k, v in available.items() if k in params})
        params, error_kwargs, condition = adverse(error_name, params, error_kwargs, resource, method, reply)
        base = next((c.__name__ for c in error_class.__mro__[1:] if c.__name__ in mapping), None)
        assert base, (asset['id'], error_name, error_class.__mro__)
        status, code = mapping[base]
        envelope = {'errorName': error_name, 'errorCode': code, 'errorInstanceId': UUID, 'parameters': params}
        errors.append({'name': error_name, 'status': status, 'errorCode': code, 'parameters': params,
                       'parameter_schema': error_schema, 'error_source': inspect.getfile(error_class),
                       'error_source_sha256': sha(inspect.getfile(error_class)), 'error_base': base,
                       'request': encode(error_kwargs), 'expected_wire': wire(expressions, module, error_kwargs),
                       'envelope': envelope, 'source_condition': condition,
                       'source_description': inspect.getdoc(error_class),
                       'expected': {'exception_class': error_class.__module__ + '.' + error_name,
                                    'name': error_name, 'parameters': copy.deepcopy(params), 'error_instance_id': UUID}})
    async_cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Async' + resource + 'Client')
    async_fn = next(n for n in async_cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method)
    assets = {kind: {'path': asset[kind] if kind != 'contract' else 'references/rest/contracts/' + asset['id'].replace('.', '/') + '.md',
                     'sha256': sha(OWNER / (asset[kind] if kind != 'contract' else 'references/rest/contracts/' + asset['id'].replace('.', '/') + '.md'))}
              for kind in ('behavior', 'example', 'contract')}
    row = {'case_id': f'F075-{index:02d}', 'operation': asset['id'], 'source': {'module': module_name, 'path': str(source_path),
           'sha256': sha(source_path), 'method_source_sha256': hashlib.sha256(ast.get_source_segment(source, fn).encode()).hexdigest(),
           'async_method_source_sha256': hashlib.sha256(ast.get_source_segment(source, async_fn).encode()).hexdigest(),
           'line': fn.lineno, 'docstring': ast.get_docstring(fn), 'request_expressions': expressions, 'oracle_sha256': sha(oracle_path)},
           'assets': assets, 'request': {'kwargs': encode(kwargs), 'argument_schemas': schemas, 'expected_wire': expected_wire,
           'path_prefix': '/api', 'timeout': 7, 'authorization': 'Bearer independent-qa-075'}, 'success': success, 'errors': errors,
           'additional_cases': [], 'semantic_expectation': ast.get_docstring(fn).split(':param')[0].strip(),
           'source_silence': ['Mock transport does not prove tenant access, service lifecycle effects, billing, inference quality or idempotency.'],
           'review': {'example_fixture_executed': False, 'formal_execution': 'NOT_RUN'}}
    extras = row['additional_cases']
    minimal = copy.deepcopy(kwargs)
    minimal.update({k: None for k in defaults if k != 'preview'})
    extras.append({'name': 'optional omission', 'request': encode(minimal), 'expected_wire': wire(expressions, module, minimal),
                   'response': copy.deepcopy(reply), 'response_status': success['http_status'], 'success': copy.deepcopy(success)})
    required = [a.arg for a in fn.args.args[:len(fn.args.args) - len(fn.args.defaults)] if a.arg != 'self'] + [a.arg for a, d in zip(fn.args.kwonlyargs, fn.args.kw_defaults) if d is None]
    if required:
        missing = copy.deepcopy(kwargs)
        missing.pop(required[0])
        extras.append({'name': 'required argument omitted', 'request': encode(missing), 'expected_exception': 'pydantic.ValidationError',
                       'omitted_parameter': required[0], 'expected_request_count': 0})
    if 'page_token' in kwargs:
        first, second = copy.deepcopy(kwargs), copy.deepcopy(kwargs)
        first['page_token'] = None
        second['page_token'] = 'independent-next075'
        a, b = copy.deepcopy(reply), copy.deepcopy(reply)
        a['nextPageToken'] = 'independent-next075'
        b.pop('nextPageToken', None)
        item = b['data'][0]
        if isinstance(item, dict):
            if resource == 'AgentVersion':
                item.update(string='2.2', version={'major': 2, 'minor': 2})
            elif resource == 'ModelStudioConfigVersion':
                item['version'] = 3
            elif 'rid' in item:
                item['rid'] = RID('second-page-' + resource.lower())
            elif 'runId' in item:
                item['runId'] = RID('second-run')
        extras.append({'name': 'finite continuation', 'requests': [encode(first), encode(second)],
                       'expected_wires': [wire(expressions, module, first), wire(expressions, module, second)],
                       'responses': [a, b], 'response_status': 200, 'expected_request_count': 2, 'expected_terminal_token': None})
    domain_extras(row, resource, method, kwargs, reply, defaults, expressions, module)
    row['gherkin'] = {'feature': asset['id'], 'scenarios': [
        {'name': row['case_id'] + ' source-derived request and result', 'given': ['Pinned SDK and all source/asset hashes match.', 'Deny sockets and DNS; synthetic HTTP only.'],
         'when': ['Call exact operation in declared sync/async/raw/stream modes using request literals.'],
         'then': ['Compare HTTP method/path/query/headers/body and timeout7.', 'Decode declared SDK response or exact bytes; close responses and transports.']},
        {'name': row['case_id'] + ' every declared error', 'given': ['Use each errors entry with its source-derived request and error literal.'],
         'when': ['Synthetic service returns its literal status/envelope.'], 'then': ['Assert exact named SDK exception and typed parameters; no successful result.']}]}
    row['preparation_elapsed_seconds'] = time.perf_counter() - operation_start
    row['case_sha256'] = hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    rows.append(row)
manifest = {'story': 'DEV-STORY-075', 'testcase': 'TESTCASE-077', 'author_identity': AUTHOR, 'sdk_release': '1.101.0',
            'source_commit': oracle['source_commit'], 'reviewed_candidate_sha': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip(),
            'generation_method': 'Installed SDK AST, annotations, request/response/error definitions. Author register supplies operation IDs and asset paths. No example EXPECTED/SUCCESS/ERRORS values are used as oracles and no example invoke/verify is run.',
            'approval': 'PENDING_INDEPENDENT_REVIEW', 'execution': 'NOT_RUN', 'operations': rows, 'review_gaps': validation_gaps,
            'network_policy': {'required': 'Deny public socket connect/connect_ex/create_connection and DNS; use fresh synthetic httpx.MockTransport.'}}
manifest['model_source_bindings'] = {str(Path(importlib.import_module('foundry_sdk.v2.' + service + '.models').__file__)): sha(importlib.import_module('foundry_sdk.v2.' + service + '.models').__file__) for service in ('core', 'checkpoints', 'data_health', 'orchestration')}
manifest['journeys'] = make_journeys(rows)
out = TMP / 'rest075_formal_cases.json'
out.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'operations': len(rows), 'errors': sum(len(r['errors']) for r in rows), 'manifest_sha256': sha(out)}))
