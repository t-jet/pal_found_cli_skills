from pathlib import Path
p=Path('.ept/tmp/rest075_formal_discover.py')
s=p.read_text().replace("pydantic.TypeAdapter(typing.get_type_hints(err)['parameters']).json_schema(),inspect.getdoc(err)","{k:v.get('description',v.get('type','ref')) for k,v in pydantic.TypeAdapter(typing.get_type_hints(err)['parameters']).json_schema().get('properties',{}).items()}")
p.write_text(s)
