"""Correct the eight owned pipeline fixtures; preserve their original bytes."""
import ast
import copy
import hashlib
import json
from pathlib import Path
from pprint import pformat

TMP = Path(__file__).resolve().parent
REPO = TMP / 'feature015_integration'
BASE = REPO / '.agents/skills/pal-found-dev/examples/rest/075/v2'
ARCHIVE = TMP / 'rest075_originals_20261028'
ARCHIVE.mkdir(exist_ok=True)
FOUND = 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001'
OMITTED = 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000002'
files = [BASE / 'data_health/Check/replace.py',
         BASE / 'orchestration/Schedule/create.py', BASE / 'orchestration/Schedule/replace.py',
         *(BASE / service / resource / 'get_batch.py' for service, resource in (
             ('checkpoints', 'Record'), ('orchestration', 'Build'),
             ('orchestration', 'Job'), ('orchestration', 'Schedule'))),
         BASE / 'orchestration/Build/search.py']
inventory = []
for path in [*files, REPO / 'tests/test_offline_rest_075.py']:
    relative = path.relative_to(REPO).as_posix()
    saved = ARCHIVE / relative
    saved.parent.mkdir(parents=True, exist_ok=True)
    assert not saved.exists(), 'Refuse to overwrite original evidence'
    saved.write_bytes(path.read_bytes())
    inventory.append({'path': relative, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(ARCHIVE / 'manifest.json').write_text(json.dumps(inventory, indent=2) + '\n', encoding='utf-8')

def values(text):
    return {node.targets[0].id: ast.literal_eval(node.value) for node in ast.parse(text).body
            if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}

def replace_assignment(text, name, value):
    node = next(node for node in ast.parse(text).body if isinstance(node, ast.Assign)
                and isinstance(node.targets[0], ast.Name) and node.targets[0].id == name)
    lines = text.splitlines(keepends=True)
    lines[node.lineno - 1:node.end_lineno] = [name + ' = ' + pformat(value, width=100, sort_dicts=False) + '\n']
    return ''.join(lines)

for path in files:
    original = path.read_bytes()
    newline = '\r\n' if b'\r\n' in original else '\n'
    text = path.read_text(encoding='utf-8')
    constants = values(text)
    resource, operation = path.parent.name, path.stem
    if resource == 'Check':
        errors = copy.deepcopy(constants['ERRORS'])
        error = next(row for row in errors if row['name'] == 'ModifyingCheckTypeNotSupported')
        error['parameters'] = {'originalCheckType': 'columnType',
                               'newCheckType': constants['EXPECTED_BODY']['config']['type']}
        text = replace_assignment(text, 'ERRORS', errors)
    elif resource == 'Schedule' and operation in ('create', 'replace'):
        success = copy.deepcopy(constants['SUCCESS'])
        success['action']['target']['ignoredRids'] = []
        text = replace_assignment(text, 'SUCCESS', success)
        old = '            assert normalized(raw.decode()) == SUCCESS'
        assert old in text
        text = text.replace(old, old + "\n            assert SUCCESS['action']['target']['targetRids'] == EXPECTED_BODY['action']['target']['targetRids']\n            assert SUCCESS['action']['target']['ignoredRids'] == []", 1)
    elif operation == 'get_batch':
        key = resource[0].lower() + resource[1:] + 'Rid'
        body = [{key: FOUND}, {key: OMITTED}]
        found = values(path.with_name('get.py').read_text(encoding='utf-8'))['SUCCESS']
        assert found['rid'] == FOUND
        text = replace_assignment(text, 'EXPECTED_BODY', body)
        text = replace_assignment(text, 'SUCCESS', {'data': {FOUND: found}})
        start = text.index('def invoke(client):')
        end = text.index('def check_request(request):', start)
        text = text[:start] + 'def invoke(client):\n    return client.with_raw_response.get_batch(body=EXPECTED_BODY, request_timeout=30)\n\n' + text[end:]
        old = '            assert normalized(raw.decode()) == SUCCESS'
        assert old in text
        text = text.replace(old, "            decoded = normalized(raw.decode())\n            assert decoded == SUCCESS\n            # One accessible record is returned; the second synthetic RID is omitted.\n            assert set(decoded['data']) == {EXPECTED_BODY[0]['" + key + "']}\n            assert EXPECTED_BODY[1]['" + key + "'] not in decoded['data']", 1)
    else:
        body = {'where': {'field': 'STARTED_TIME', 'value': '2026-10-01T00:00:00Z', 'type': 'gte'}}
        text = replace_assignment(text, 'EXPECTED_BODY', body)
        start = text.index('def invoke(client):')
        end = text.index('def check_request(request):', start)
        text = text[:start] + 'def invoke(client):\n    # SDK filter value is Any; validate this illustrative UTC literal in the target enrollment.\n    return client.with_raw_response.search(where=EXPECTED_BODY[\'where\'], request_timeout=30)\n\n' + text[end:]
    path.write_bytes(text.replace('\n', newline).encode())
print(json.dumps({'corrected_owned_files': len(files), 'preserved_original_files': len(inventory)}))
