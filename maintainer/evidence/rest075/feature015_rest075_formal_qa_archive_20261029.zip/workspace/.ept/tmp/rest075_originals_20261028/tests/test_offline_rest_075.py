"""Pipeline SDK examples checked against installed source and semantic invariants.

Synthetic HTTP responses demonstrate decoding and request/result correspondence.
They do not prove server-side scheduling, filter semantics or live health checks.
"""

import ast
import copy
import datetime
import hashlib
import importlib
import importlib.metadata
import inspect
import json
import runpy
import socket
import textwrap
from functools import lru_cache
from pathlib import Path

import httpx
import pytest
from foundry_sdk import PalantirRPCException
from pydantic import TypeAdapter, ValidationError


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".agents/skills/pal-found-dev/examples/rest/075/v2"
REGISTER = json.loads((ROOT / "maintainer/rest-domain-authoring-register.json").read_text())
ORACLE = json.loads((ROOT / "tests/fixtures/offline/rest-acceptance/source-oracle.json").read_text())
OPERATIONS = {
    ("checkpoints", "Record"): ("get", "get_batch", "search"),
    ("data_health", "Check"): ("create", "delete", "get", "replace"),
    ("data_health", "CheckReport"): ("get", "get_latest"),
    ("orchestration", "Build"): ("cancel", "create", "get", "get_batch", "jobs", "search"),
    ("orchestration", "Job"): ("get", "get_batch"),
    ("orchestration", "Schedule"): ("create", "delete", "get", "get_affected_resources",
                                    "get_batch", "pause", "replace", "run", "runs", "unpause"),
    ("orchestration", "ScheduleVersion"): ("get", "schedule"),
}
CASES = [(service, resource, op) for (service, resource), ops in OPERATIONS.items() for op in ops]
BATCHES = [("checkpoints", "Record"), ("orchestration", "Build"),
           ("orchestration", "Job"), ("orchestration", "Schedule")]
FOUND = "ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001"
OMITTED = "ri.synthetic.main.resource.00000000-0000-0000-0000-000000000002"
OTHER = "ri.synthetic.main.resource.00000000-0000-0000-0000-000000000003"


@pytest.fixture(autouse=True)
def deny_public_network(monkeypatch):
    def denied(*args, **kwargs):
        raise AssertionError("REST075 attempted public network access")

    for name in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, name, denied)
    for name in ("create_connection", "getaddrinfo", "gethostbyname", "gethostbyname_ex"):
        monkeypatch.setattr(socket, name, denied)
    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", denied)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", denied)


def example(service, resource, operation):
    return runpy.run_path(str(BASE / service / resource / f"{operation}.py"))["invoke"].__globals__


@lru_cache
def contract(service, resource, operation):
    snake = "".join(("_" if i else "") + c.lower() if c.isupper() else c
                    for i, c in enumerate(resource))
    module = importlib.import_module(f"foundry_sdk.v2.{service}.{snake}")
    client = getattr(module, resource + "Client")
    tree = ast.parse(textwrap.dedent(inspect.getsource(getattr(client, operation))))
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Attribute) and node.func.attr == "RequestInfo"]
    assert len(calls) == 1
    fields = {kw.arg: kw.value for kw in calls[0].keywords}

    def source_value(node):
        return eval(compile(ast.Expression(node), "<installed SDK contract>", "eval"), vars(module))

    return {
        "client": client,
        "method": ast.literal_eval(fields["method"]),
        "path": ast.literal_eval(fields["resource_path"]),
        "headers": ast.literal_eval(fields["header_params"]),
        "response": source_value(fields["response_type"]),
        "errors": source_value(fields["throwable_errors"]),
        "source_hash": hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),
    }


def normalized(value):
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json", by_alias=True, exclude_none=True)
    if isinstance(value, dict):
        return {key: normalized(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalized(child) for child in value]
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.isoformat()
    return value


def execute(namespace, source, handler):
    with namespace["mock_resource"](source["client"], handler) as client:
        raw = namespace["invoke"](client)
        try:
            return normalized(raw.decode())
        finally:
            raw.close()


def check_wire(source, request):
    path = source["path"]
    for field in ("recordRid", "checkRid", "checkReportRid", "buildRid", "jobRid",
                  "scheduleRid", "scheduleVersionRid"):
        path = path.replace("{" + field + "}", FOUND)
    assert request.method == source["method"]
    assert request.url.path == "/api" + path
    assert request.headers["Authorization"] == "Bearer offline-fixture-token"
    for key, value in source["headers"].items():
        assert request.headers[key] == value


def check_batch(requested, result):
    # These examples deliberately demonstrate one found and one inaccessible ID.
    assert set(requested) == {FOUND, OMITTED}
    assert set(result["data"]) == {FOUND}
    assert result["data"][FOUND]["rid"] == FOUND
    assert OMITTED not in result["data"]


def check_schedule_action(body, result):
    target = body["action"]["target"]
    returned = result["action"]["target"]
    assert target["type"] == returned["type"] == "upstream"
    assert returned["targetRids"] == target["targetRids"]
    assert returned["ignoredRids"] == target.get("ignoredRids", [])
    assert set(returned["targetRids"]).isdisjoint(returned["ignoredRids"])


def check_check_type_change(parameters, requested_type):
    assert parameters["newCheckType"] == requested_type
    assert parameters["originalCheckType"] != parameters["newCheckType"]


def check_business(resource, operation, request, result):
    body = json.loads(request.content) if request.content else None
    if operation == "get_batch":
        key = resource[0].lower() + resource[1:] + "Rid"
        check_batch([element[key] for element in body], result)
    if resource == "Schedule" and operation in ("create", "replace"):
        check_schedule_action(body, result)
    if resource == "Build" and operation == "search":
        where = body["where"]
        assert where["type"] == "gte" and where["field"] == "STARTED_TIME"
        # SDK value: Any does not validate this illustrative UTC filter literal.
        assert datetime.datetime.fromisoformat(where["value"].replace("Z", "+00:00")).tzinfo
    if operation == "get" and resource != "ScheduleVersion":
        assert result["rid"] == request.url.path.rsplit("/", 1)[1]
    if resource == "Check" and operation in ("create", "replace"):
        assert result["config"]["type"] == body["config"]["type"]
    if operation in ("cancel", "delete", "pause", "unpause"):
        assert result is None


def successful_example(service, resource, operation):
    namespace = example(service, resource, operation)
    source = contract(service, resource, operation)
    requests = []

    def handler(request):
        check_wire(source, request)
        requests.append(request)
        payload = namespace["SUCCESS"]
        return httpx.Response(204) if payload is None else httpx.Response(200, json=payload)

    result = execute(namespace, source, handler)
    assert len(requests) == 1
    return namespace, requests[0], result


def test_owned_operations_match_frozen_source_and_register():
    assert importlib.metadata.version("foundry-platform-sdk") == "1.101.0"
    rows = [row for row in REGISTER["operations"] if row["story"] == "DEV-STORY-075"]
    assert {row["id"] for row in rows} == {f"v2.{s}.{r}.{op}" for s, r, op in CASES}
    for row in rows:
        _, service, resource, operation = row["id"].split(".")
        source = contract(service, resource, operation)
        frozen = ORACLE["operations"][row["id"]]
        assert source["source_hash"] == row["source_sha256"] == frozen["source_sha256"]
        assert source["method"] == frozen["documentation"]["method"]
        assert source["path"] == frozen["documentation"]["resource_path"]


@pytest.mark.parametrize("service,resource,operation", CASES)
def test_each_operation_uses_source_wire_and_meaningful_result(service, resource, operation):
    _, request, result = successful_example(service, resource, operation)
    check_business(resource, operation, request, result)
    model = contract(service, resource, operation)["response"]
    if model is not None:
        TypeAdapter(model).validate_python(result)


@pytest.mark.parametrize("service,resource,operation", CASES)
def test_declared_errors_keep_sdk_types_and_semantic_parameters(service, resource, operation):
    namespace = example(service, resource, operation)
    source = contract(service, resource, operation)
    cases = {case["name"]: case for case in namespace["ERRORS"]}
    assert cases.keys() == source["errors"].keys()
    for name, error_type in source["errors"].items():
        case = cases[name]
        if name == "ModifyingCheckTypeNotSupported":
            check_check_type_change(case["parameters"], namespace["EXPECTED_BODY"]["config"]["type"])

        def failure(request):
            check_wire(source, request)
            return httpx.Response(case["status"], json={
                "errorName": name, "errorCode": case["code"], "parameters": case["parameters"],
                "errorInstanceId": "00000000-0000-0000-0000-000000000004",
            })

        with pytest.raises(error_type) as raised:
            execute(namespace, source, failure)
        assert isinstance(raised.value, PalantirRPCException)
        assert raised.value.name == name
        assert normalized(raised.value.parameters) == case["parameters"]


@pytest.mark.parametrize("service,resource", BATCHES)
@pytest.mark.parametrize("fault", ("empty_found", "wrong_key", "wrong_model_rid", "unrequested"))
def test_batch_oracle_rejects_uncorrelated_or_empty_demonstrations(service, resource, fault):
    _, request, result = successful_example(service, resource, "get_batch")
    key = resource[0].lower() + resource[1:] + "Rid"
    requested = [element[key] for element in json.loads(request.content)]
    damaged = copy.deepcopy(result)
    if fault == "empty_found":
        damaged["data"].clear()
    elif fault == "wrong_key":
        damaged["data"][OTHER] = damaged["data"].pop(FOUND)
    elif fault == "wrong_model_rid":
        damaged["data"][FOUND]["rid"] = OTHER
    else:
        damaged["data"][OTHER] = copy.deepcopy(damaged["data"][FOUND])
    with pytest.raises(AssertionError):
        check_batch(requested, damaged)


@pytest.mark.parametrize("operation", ("create", "replace"))
@pytest.mark.parametrize("fault", ("ignore_only_target", "change_target"))
def test_schedule_oracle_rejects_changed_submitted_target(operation, fault):
    _, request, result = successful_example("orchestration", "Schedule", operation)
    body = json.loads(request.content)
    damaged = copy.deepcopy(result)
    target = damaged["action"]["target"]
    if fault == "ignore_only_target":
        target["ignoredRids"] = target["targetRids"][:]
    else:
        target["targetRids"] = [OTHER]
    with pytest.raises(AssertionError):
        check_schedule_action(body, damaged)


@pytest.mark.parametrize("fault", ("same_type", "different_requested_type"))
def test_check_type_error_oracle_rejects_non_change_or_unrelated_request(fault):
    namespace = example("data_health", "Check", "replace")
    parameters = copy.deepcopy(next(case["parameters"] for case in namespace["ERRORS"]
                                    if case["name"] == "ModifyingCheckTypeNotSupported"))
    requested = namespace["EXPECTED_BODY"]["config"]["type"]
    if fault == "same_type":
        parameters["originalCheckType"] = parameters["newCheckType"]
    else:
        parameters["newCheckType"] = "columnType"
    with pytest.raises(AssertionError):
        check_check_type_change(parameters, requested)


@pytest.mark.parametrize("service,resource", BATCHES)
def test_batch_missing_rid_fails_sdk_validation_before_http(service, resource):
    namespace = example(service, resource, "get_batch")
    source = contract(service, resource, "get_batch")

    def unexpected(request):
        raise AssertionError("Invalid batch reached HTTP")

    with namespace["mock_resource"](source["client"], unexpected) as client:
        with pytest.raises(ValidationError):
            client.with_raw_response.get_batch(body=[{}])
