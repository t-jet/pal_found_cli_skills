"""Capture author evidence for the bounded REST075 transport-mode expansion."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

TMP = Path(__file__).resolve().parent
ROOT = TMP.parents[1]
TEST = TMP / 'feature015_integration/tests/test_offline_rest_075.py'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('rest075_modes_inventory', TEST)
suite = importlib.util.module_from_spec(spec)
spec.loader.exec_module(suite)
checks = []
for arguments in suite.CASES:
    source = suite.contract(*arguments)
    identity = 'v2.' + '.'.join(arguments)
    assert source['source_hash'] == suite.ORACLE['operations'][identity]['source_sha256']
    checks.append({'id': identity, 'source_sha256': source['source_hash']})
commands = []
for command in (
    ['ruff', 'check', str(TEST)],
    ['git', '-c', 'core.whitespace=cr-at-eol', '-C', str(TMP / 'feature015_integration'),
     'diff', '--check', '--', 'tests/test_offline_rest_075.py'],
):
    result = subprocess.run(command, capture_output=True, text=True)
    commands.append({'command': command, 'exit_code': result.returncode,
                     'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0
attempts = []
for number in range(1, 6):
    path = TMP / f'rest075_modes_attempt{number}_20261028.log'
    attempts.append({'path': str(path), 'sha256': sha(path),
                     'stdout_stderr': path.read_text(encoding='utf-8-sig')})
assert '214 passed' in attempts[-1]['stdout_stderr']
report = {
    'author_agent': '/root/rest075_modes_finish_20261028',
    'observed_at_utc': datetime.now(timezone.utc).isoformat(),
    'owned_file': str(TEST), 'test_sha256': sha(TEST),
    'status': 'AUTHOR_VALIDATED_PENDING_INDEPENDENT_REVIEW',
    'shared_source_or_tracker_edits': False, 'committed': False,
    'sdk_release': '1.101.0', 'source_bindings': checks,
    'test_count': 214, 'prior_semantic_and_sync_raw_tests_retained': 86,
    'added_runtime_checks': {
        'native_async_and_async_raw_per_operation': len(suite.CASES) * 2,
        'sync_async_stream_budget_early_close': len(suite.STREAM_CASES) * 2,
        'sync_async_finite_pagination': len(suite.PAGED_CASES) * 2,
        'sync_async_read_timeout_per_resource': len(suite.OPERATIONS) * 2,
    },
    'stream_operations': ['v2.' + '.'.join(case) for case in suite.STREAM_CASES],
    'paged_operations': ['v2.' + '.'.join(case) for case in suite.PAGED_CASES],
    'network_guard': 'Public socket and DNS connections and native HTTP transports denied. '
        'Windows event-loop local socket pair initialized in module fixture before guard activation.',
    'stream_cleanup': 'Custom SyncByteStream/AsyncByteStream starts open, yields exactly two chunks '
        'before caller budget raises, closes via SDK context, leaves third chunk unread.',
    'timeout_scope': 'Synthetic httpx.ReadTimeout maps to SDK ReadTimeout with preserved cause; '
        'per-resource read sends exactly one request under existing max_retries=1 fixture config.',
    'input_boundary': 'Argument recorder reads example input kwargs without issuing SDK calls. '
        'Existing frozen-source contracts define expected wire/result/error types; existing semantic mutation guards remain.',
    'mode_boundary': 'Native async iterators are distinct from awaitable raw/model responses. '
        'Paginated response models use explicit continuation; native iterators stop at final page. '
        'No SSE return is declared by these 29 frozen SDK methods; no SSE runtime coverage is claimed.',
    'attempt_notes': {
        '1': '17 harness failures: literal-only AST input reader rejected variable/subscript expressions; 154 passed.',
        '2': '171 passed after input capture handles actual example argument expressions.',
        '3': '2 harness failures: source alias ResourceAsyncIterator resolves to class AsyncResourceIterator; 212 passed.',
        '4': '214 passed after checking source annotation origin class instead of alias spelling.',
        '5': '214 passed after strengthening stream closure proof with tracked, initially-open byte streams.',
    },
    'attempts': attempts, 'additional_commands': commands,
    'limits': ['Synthetic SDK transport evidence only; no live Foundry behavior or server-side effects.',
               'Fresh independent unit review and formal case/execution approval remain required.'],
}
output = TMP / 'rest075_modes_author_validation_20261028.json'
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report': str(output), 'sha256': sha(output), 'test_sha256': sha(TEST),
                  'test_count': report['test_count'], 'added_runtime_checks': report['added_runtime_checks']}))
