_typed_failure = failure


def assert_service_error(error, name, code, parameters, expected_class):
    assert isinstance(error, PalantirRPCException), type(error)
    assert error.name == name
    assert normalized(error.parameters) == normalized(parameters)
    assert error.error_instance_id == '00000000-0000-0000-0000-000000000075'
    if expected_class:
        module, cls = expected_class.rsplit('.', 1)
        assert type(error) is getattr(importlib.import_module(module), cls)
    else:
        assert error.error_code == code


def failure(case, cls, method, status, name, code, parameters, expected_class=None, kwargs=None, wire=None):
    _typed_failure(case, cls, method, status, name, code, parameters, expected_class, kwargs, wire)
    kwargs = kwargs or case['request']['kwargs']
    wire = wire or case['request']['expected_wire']
    envelope = dict(errorName=name, errorCode=code, parameters=parameters,
                    errorInstanceId='00000000-0000-0000-0000-000000000075')
    for mode in ('raw', 'stream'):
        if mode == 'stream' and not case['available_modes']['sync_stream']:
            with resource(cls, denied) as (client, _):
                assert not hasattr(client.with_streaming_response, method)
            record(case['case_id'], 'error_' + name + '_sync_stream_absent_in_source', requests=0)
            continue
        calls, responses = [], []
        def handler(request):
            wire_check(request, wire)
            calls.append(request)
            reply = httpx.Response(status, json=envelope)
            responses.append(reply)
            return reply
        with resource(cls, handler) as (client, _):
            try:
                if mode == 'raw':
                    invoke(client, method, kwargs, True)
                else:
                    with getattr(client.with_streaming_response, method)(**materialize(kwargs), request_timeout=7):
                        raise AssertionError('Failed service response entered success stream')
            except PalantirRPCException as error:
                assert_service_error(error, name, code, parameters, expected_class)
            else:
                raise AssertionError('Service error accepted')
        assert len(calls) == 1 and all(reply.is_closed for reply in responses)
        record(case['case_id'], 'error_' + name + '_sync_' + mode + '_closed', requests=1)
    async_cls = getattr(importlib.import_module(case['source']['module']), 'Async' + cls.__name__)
    async def run():
        for mode in ('typed', 'raw', 'stream'):
            if mode == 'stream' and not case['available_modes']['async_stream']:
                async with async_resource(async_cls, denied) as (client, _):
                    assert not hasattr(client.with_streaming_response, method)
                record(case['case_id'], 'error_' + name + '_async_stream_absent_in_source', requests=0)
                continue
            calls, responses = [], []
            def handler(request):
                wire_check(request, wire)
                calls.append(request)
                reply = httpx.Response(status, json=envelope)
                responses.append(reply)
                return reply
            async with async_resource(async_cls, handler) as (client, _):
                try:
                    if mode == 'stream':
                        async with getattr(client.with_streaming_response, method)(**materialize(kwargs), request_timeout=7):
                            raise AssertionError('Failed service response entered success stream')
                    else:
                        await invoke(client, method, kwargs, mode == 'raw')
                except PalantirRPCException as error:
                    assert_service_error(error, name, code, parameters, expected_class)
                else:
                    raise AssertionError('Async service error accepted')
            assert len(calls) == 1 and all(reply.is_closed for reply in responses)
            record(case['case_id'], 'error_' + name + '_async_' + mode + '_closed', requests=1)
    EVENT_LOOP.run_until_complete(run())


def bounded_chunks(chunks, max_bytes, max_chunks):
    collected = bytearray()
    for count, chunk in enumerate(chunks, 1):
        if count > max_chunks or len(collected) + len(chunk) > max_bytes:
            raise RuntimeError('REST075_RESPONSE_BUDGET_EXCEEDED')
        collected.extend(chunk)
    return bytes(collected)


def pipeline_lifecycle(manifest):
    journey = manifest['journeys'][0]
    by_id = {case['operation']: case for case in manifest['operations']}
    observed = {}
    for step in journey['steps']:
        base = by_id[step['operation']]
        case = copy.deepcopy(base)
        case['success'] = copy.deepcopy(step['success'])
        module = importlib.import_module(base['source']['module'])
        name, method = base['operation'].split('.')[-2:]
        success(case, getattr(module, name + 'Client'), method, label='pipeline_' + step['name'])
        observed[step['name']] = step['success']['json']
    assert observed['submitted']['result']['buildRid'] == observed['running']['rid'] == observed['succeeded']['rid']
    assert observed['job']['buildRid'] == observed['succeeded']['rid']
    assert observed['checkpoint']['checkpointedItems'][0]['jobRid'] == observed['job']['rid']
    assert observed['report']['check']['rid'] == observed['check']['rid']
    assert observed['succeeded']['status'] == observed['job']['jobStatus'] == 'SUCCEEDED'
    assert observed['report']['result']['status'] == 'PASSED'
    assert observed['paused']['paused'] is True
    assert observed['unpaused']['paused'] is False
    assert len(journey['steps']) <= journey['max_requests_per_mode']
    record('J12-REST075', 'bounded_lifecycle_links_and_state', requests=len(journey['steps']) * 2)
    first = by_id['v2.orchestration.Schedule.get']
    module = importlib.import_module(first['source']['module'])
    mutations = []
    with resource(module.ScheduleClient, lambda request: httpx.Response(403, json={
            'errorName': 'IndependentDenied075', 'errorCode': 'PERMISSION_DENIED',
            'errorInstanceId': '00000000-0000-0000-0000-000000000075', 'parameters': {}})) as (client, _):
        try:
            invoke(client, 'get', first['request']['kwargs'])
            mutations.append('run')
            invoke(client, 'run', by_id['v2.orchestration.Schedule.run']['request']['kwargs'])
        except PalantirRPCException as error:
            assert error.error_code == 'PERMISSION_DENIED'
        else:
            raise AssertionError('Denied preflight accepted')
    assert mutations == []
    record('J12-REST075', 'denied_preflight_stops_before_mutation', requests=1)
    for kind in ('bytes', 'chunks'):
        try:
            bounded_chunks([b'abc', b'def'], 4 if kind == 'bytes' else 100, 1 if kind == 'chunks' else 100)
        except RuntimeError as error:
            assert str(error) == 'REST075_RESPONSE_BUDGET_EXCEEDED'
        else:
            raise AssertionError('Response budget accepted')
        record('REST075', kind + '_budget_rejects_overflow')
