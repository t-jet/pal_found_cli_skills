"""Independent static review of REST075 cases. Never invoke SDK operations."""
import ast
import hashlib
import importlib
import importlib.util
import inspect
import json
from pathlib import Path
import typing

import pydantic

TMP = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = json.loads((TMP / 'rest075_formal_cases.json').read_bytes())
spec = importlib.util.spec_from_file_location('reviewed_harness', TMP / 'rest075_formal_execute.py')
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
oracle = json.loads((TMP / 'feature015_integration/tests/fixtures/offline/rest-acceptance/source-oracle.json').read_bytes())
rows = []
for case in manifest['operations']:
    operation = case['operation']
    module = importlib.import_module(case['source']['module'])
    resource, method = operation.split('.')[-2:]
    source = Path(module.__file__).read_text()
    tree = ast.parse(source)
    functions = []
    for class_name in (resource + 'Client', 'Async' + resource + 'Client'):
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name)
        fn = next(n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method)
        functions.append(fn)
    fn = functions[0]
    call = next(n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'RequestInfo')
    expressions = {k.arg: ast.unparse(k.value) for k in call.keywords}
    assert expressions == case['source']['request_expressions'], operation
    assert sha(module.__file__) == case['source']['sha256'] == oracle['operations'][operation]['source_sha256']
    for key, node in zip(('method_source_sha256', 'async_method_source_sha256'), functions):
        assert hashlib.sha256(ast.get_source_segment(source, node).encode()).hexdigest() == case['source'][key]
    hints = typing.get_type_hints(getattr(getattr(module, resource + 'Client'), method), include_extras=True)
    for key, schema in case['request']['argument_schemas'].items():
        assert pydantic.TypeAdapter(hints[key]).json_schema() == schema, (operation, key)
    result_type = eval(expressions['response_type'], vars(module))
    assert pydantic.TypeAdapter(result_type).json_schema() == case['success']['schema']
    throwable = eval(expressions['throwable_errors'], vars(module))
    assert set(throwable) == {e['name'] for e in case['errors']}
    literals = [('success', case['request']['kwargs'], case['request']['expected_wire'], case['success'])]
    for extra in case['additional_cases']:
        if 'success' in extra:
            literals.append((extra['name'], extra['request'], extra['expected_wire'], extra['success']))
        if 'requests' in extra:
            for i, kwargs in enumerate(extra['requests']):
                literals.append((extra['name'], kwargs, extra['expected_wires'][i], {'json': extra['responses'][i]}))
    for label, kwargs, wire, reply in literals:
        context = dict(vars(module), **kwargs)
        for key in ('method', 'resource_path', 'path_params', 'query_params', 'header_params', 'body'):
            expected = eval(expressions[key], context)
            if key == 'query_params':
                expected = {k: v for k, v in expected.items() if v is not None}
            if isinstance(expected, pydantic.BaseModel):
                expected = expected.model_dump(mode='json', by_alias=True, exclude_none=True)
            assert expected == wire[key], (operation, label, key)
        assert harness.normalized(reply['json']) == harness.expected_decoded(case, reply), (operation, label, 'lossy normalization')
    errors = []
    for error in case['errors']:
        cls = throwable[error['name']]
        assert error['expected']['exception_class'] == cls.__module__ + '.' + cls.__name__
        parameter_type = typing.get_type_hints(cls)['parameters']
        assert error['parameter_schema'] == pydantic.TypeAdapter(parameter_type).json_schema()
        context = dict(vars(module), **error['request'])
        for key in ('method', 'resource_path', 'path_params', 'query_params', 'header_params', 'body'):
            expected = eval(expressions[key], context)
            if key == 'query_params':
                expected = {k: v for k, v in expected.items() if v is not None}
            if isinstance(expected, pydantic.BaseModel):
                expected = expected.model_dump(mode='json', by_alias=True, exclude_none=True)
            assert expected == error['expected_wire'][key], (operation, error['name'], key)
        for key, value in error['parameters'].items():
            wire = error['expected_wire']
            available = dict(wire['path_params'], **wire['query_params'])
            if isinstance(wire['body'], dict):
                available.update(wire['body'])
            if key in available:
                assert value == available[key], (operation, error['name'], key)
        errors.append({'name': error['name'], 'parameter_source_condition': inspect.getdoc(parameter_type)})
    wrapper_classes = [n.name for n in tree.body if isinstance(n, ast.ClassDef) and any(isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)) and f.name == method for f in ast.walk(n))]
    assert len(wrapper_classes) in (4, 6), (operation, wrapper_classes)
    if 'available_modes' in case:
        assert case['available_modes'] == {
            'sync_typed': resource + 'Client' in wrapper_classes,
            'async_typed': 'Async' + resource + 'Client' in wrapper_classes,
            'sync_raw': '_' + resource + 'ClientRaw' in wrapper_classes,
            'async_raw': '_Async' + resource + 'ClientRaw' in wrapper_classes,
            'sync_stream': '_' + resource + 'ClientStreaming' in wrapper_classes,
            'async_stream': '_Async' + resource + 'ClientStreaming' in wrapper_classes,
        }, operation
    rows.append({'operation': operation, 'source_ast_signatures_wire_schemas': 'PASS', 'literal_identity_and_adverse_conditions': 'PASS', 'lossless_expected_normalization': 'PASS', 'wrapper_classes': wrapper_classes, 'error_conditions': errors})
assert len(rows) == 29
assert sum(len(r['error_conditions']) for r in rows) == 44
for path, bound in manifest['model_source_bindings'].items():
    assert sha(path) == bound
report = {'reviewer_identity': '/root/rest075_cases_review_20261029', 'execution': 'NOT_RUN', 'verdict': 'REJECTED_HARNESS', 'cases_sha256': sha(TMP / 'rest075_formal_cases.json'), 'harness_sha256': sha(TMP / 'rest075_formal_execute.py'), 'source_model_bindings': len(manifest['model_source_bindings']), 'operations': rows, 'initial_failed_proof': {'harness_sha256': 'ee6c63a9946d81c9ce63699b83a861d1419bdc4a8af597870761c8f0dded3ab7', 'finding': 'failure() unconditionally invokes sync and async streaming error paths for methods whose streaming wrappers are absent, including Check.delete. Source AST proves no streaming method; execution would raise AttributeError.', 'probe_corrections': ['Initial reviewer probe assumed six wrappers per method; source establishes four wrappers for methods without streaming. Corrected source-mode inventory.', 'Wire probe compares model body by aliases with omitted None values.'], 'formal_execution': 'NOT_RUN'}}
(TMP / 'rest075_case_approval_20261029.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
approved = {
    'rest075_formal_cases.json': 'f7f7a19d1a34aa3ce3ff2816398c721cd29f458c3e76c38d5c52424c8aa85346',
    'rest075_formal_execute.py': 'f5e876ca5ed6d1d0b479d1214a49ed0704ac1b08e7043ba37f03ce216171bc8d',
    'rest075_formal_readiness.json': '5e8d619a789e5adafc405f5bc5abe9b072f3a35d2ce82abfc28dad35d5008e6e',
    'rest075_formal_static_validation.json': 'd4bfbf11e97f0f2338b49cd16a49966979ed900e6091812a6eb1bc90dddc81f0',
}
for name, expected in approved.items():
    assert sha(TMP / name) == expected, name
readiness = json.loads((TMP / 'rest075_formal_readiness.json').read_bytes())
for path, expected in readiness['source_asset_bindings'].items():
    assert sha(path) == expected, path
assert len(readiness['source_asset_bindings']) == 83
rejected = json.loads((TMP / 'rest075_formal_rejected01_manifest.json').read_bytes())
for artifact in rejected['files']:
    assert sha(artifact['preserved']) == artifact['sha256'], artifact
report.update(verdict='APPROVED_CASES_AND_HARNESS', approved_immutable_artifacts=approved,
              source_asset_bindings=83,
              corrected_finding='Source-derived stream availability matches all 29 AST definitions. Five absent stream methods assert absence and record zero requests in success and error paths.',
              harness_review=['Exact typed/raw result comparison with lossless expected normalization.',
                              'Source error identity, parameters, HTTP base and denial assertions.',
                              'Sync/async typed/raw available for 29; sync/async streams for 24 and explicit absence for 5.',
                              'Finite two-page iteration and terminal token checks; timeout seven seconds, zero retry; malformed response rejection.',
                              'All seven socket/DNS traps probed before execution; response/transport close assertions and byte/chunk limits.',
                              'Twelve synthetic lifecycle steps link schedule/build/job/checkpoint/check/report and pause state. STARTED_TIME uses separate synthetic server metadata.'],
              boundaries=['Static independent review only; no SDK operation or formal execution performed.',
                          'Approval covers exact immutable cases/harness and 83 source/asset bindings. It does not waive live workflow prerequisites.',
                          'Separate executor must run only after actual TESTCASE Closed and TESTEXEC In Progress.',
                          'Synthetic fixtures do not establish enrollment permissions, persisted state, service defaults or idempotency.'])
(TMP / 'rest075_case_approval_20261029.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'operations'}))
