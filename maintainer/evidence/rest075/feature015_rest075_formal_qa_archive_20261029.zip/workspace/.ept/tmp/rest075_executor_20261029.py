"""Run the approved harness with independent identity and retained attempt outputs."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

TMP = Path(__file__).resolve().parent
IDENTITY = '/root/rest075_execute_20261029'
REVIEWER = '/root/rest075_cases_review_20261029'
CASES_SHA = 'f7f7a19d1a34aa3ce3ff2816398c721cd29f458c3e76c38d5c52424c8aa85346'
HARNESS_SHA = 'f5e876ca5ed6d1d0b479d1214a49ed0704ac1b08e7043ba37f03ce216171bc8d'
READINESS_SHA = '5e8d619a789e5adafc405f5bc5abe9b072f3a35d2ce82abfc28dad35d5008e6e'
PREFIX = TMP / 'rest075_executor_20261029_attempt01'
HARNESS = TMP / 'rest075_formal_execute.py'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def bindings():
    approval_path = TMP / 'rest075_case_approval_20261029.json'
    approval = json.loads(approval_path.read_bytes())
    assert approval['verdict'] == 'APPROVED_CASES_AND_HARNESS'
    assert approval['reviewer_identity'] == REVIEWER
    assert approval['cases_sha256'] == CASES_SHA
    assert approval['harness_sha256'] == HARNESS_SHA
    expected = {str(TMP / name): sha for name, sha in approval['approved_immutable_artifacts'].items()}
    assert expected[str(TMP / 'rest075_formal_readiness.json')] == READINESS_SHA
    readiness = json.loads((TMP / 'rest075_formal_readiness.json').read_bytes())
    assert readiness['author_identity'] not in (IDENTITY, REVIEWER)
    assert len(readiness['source_asset_bindings']) == 83
    expected.update(readiness['source_asset_bindings'])
    cases = json.loads((TMP / 'rest075_formal_cases.json').read_bytes())
    expected.update(cases['model_source_bindings'])
    assert len(cases['operations']) == 29
    assert sum(len(case['errors']) for case in cases['operations']) == 44
    preserved = json.loads((TMP / 'rest075_formal_rejected01_manifest.json').read_bytes())
    for item in preserved['files']:
        expected[str(TMP.parent.parent / item['preserved'])] = item['sha256']
    expected[str(approval_path)] = digest(approval_path)
    actual = {path: digest(path) for path in expected}
    assert actual == expected, [path for path in expected if actual[path] != expected[path]]
    return actual, cases, approval


def child():
    bindings()
    spec = importlib.util.spec_from_file_location('rest075_approved_harness', HARNESS)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.PENDING = Path(str(PREFIX) + '_execution.json')
    module.LOG = Path(str(PREFIX) + '_checks.jsonl')
    assert not module.PENDING.exists() and not module.LOG.exists()
    sys.argv = [str(HARNESS), '--execute', '--executor-identity', IDENTITY,
                '--testcase-closed', 'TESTCASE-077', '--approved-cases-sha256', CASES_SHA,
                '--readiness-confirmed', '--reviewer-identity', REVIEWER,
                '--approved-harness-sha256', HARNESS_SHA]
    module.main()


def main():
    if sys.argv[1:] == ['--child']:
        child()
        return
    before, cases, approval = bindings()
    if not sys.argv[1:]:
        print(json.dumps(dict(execution='NOT_RUN', identity=IDENTITY,
                             wrapper_sha256=digest(__file__), approval_sha256=digest(TMP / 'rest075_case_approval_20261029.json'),
                             verified_bindings=len(before), operations=29, declared_errors=44)))
        return
    assert sys.argv[1:] == ['--root-confirmed', '--coordinator-confirmed']
    result_path = Path(str(PREFIX) + '_result.json')
    assert not result_path.exists(), 'Attempt output already exists; retain it'
    gate_states = {'DEV-077': 'Resolved', 'UNITTEST-077': 'Resolved',
                   'CODEREVIEW-078': 'Closed', 'TESTCASE-077': 'Closed', 'TESTEXEC-077': 'In Progress'}
    gates = {}
    for ticket, state in gate_states.items():
        command = [sys.executable, '.ept/tools/tracker/tracker_cli.py', 'get', ticket]
        proc = subprocess.run(command, cwd=TMP.parent.parent, capture_output=True, text=True, encoding='utf-8')
        gates[ticket] = dict(command=command, exit_code=proc.returncode, stdout=proc.stdout, stderr=proc.stderr)
        write(str(PREFIX) + '_gates.json', gates)
        assert proc.returncode == 0, gates[ticket]
        assert f'current_status: {state}\n' in proc.stdout, gates[ticket]
    command = [sys.executable, '-B', str(Path(__file__).resolve()), '--child']
    record = dict(identity=IDENTITY, reviewer=REVIEWER, started_at=now(), command=command,
                  wrapper_sha256=digest(__file__), bindings_before=before, gates=gates)
    write(result_path, record)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMP=str(TMP), TEMP=str(TMP), TMPDIR=str(TMP))
    with Path(str(PREFIX) + '_stdout.log').open('xb') as stdout, Path(str(PREFIX) + '_stderr.log').open('xb') as stderr:
        proc = subprocess.run(command, cwd=TMP.parent.parent, stdout=stdout, stderr=stderr, env=env)
    after = {path: digest(path) for path in before}
    record.update(exit_code=proc.returncode, completed_at=now(), bindings_after=after, bindings_unchanged=(before == after))
    execution_path = Path(str(PREFIX) + '_execution.json')
    if execution_path.exists():
        execution = json.loads(execution_path.read_bytes())
        record['execution'] = execution['execution']
        rows = execution.get('results', [])
        reconciliation = []
        for case in cases['operations']:
            checks = [row for row in rows if row['case_id'] == case['case_id']]
            names = {row['check'] for row in checks}
            required = {'success_typed', 'success_raw_closed', 'async_typed', 'async_raw_closed',
                        'sync_stream_closed' if case['available_modes']['sync_stream'] else 'sync_stream_absent_in_source',
                        'async_stream_closed' if case['available_modes']['async_stream'] else 'async_stream_absent_in_source'}
            errors = {}
            for error in case['errors']:
                base = 'error_' + error['name']
                error_modes = {base, base + '_sync_raw_closed', base + '_async_typed_closed',
                               base + '_async_raw_closed',
                               base + ('_sync_stream_closed' if case['available_modes']['sync_stream'] else '_sync_stream_absent_in_source'),
                               base + ('_async_stream_closed' if case['available_modes']['async_stream'] else '_async_stream_absent_in_source')}
                errors[error['name']] = error_modes <= names
            absent = [row for row in checks if 'stream_absent_in_source' in row['check']]
            reconciliation.append(dict(operation=case['operation'], case_id=case['case_id'], checks=len(checks),
                                       success_modes_complete=required <= names, declared_errors=errors,
                                       absent_stream_zero_requests=all(row['requests'] == 0 for row in absent)))
        record['reconciliation'] = reconciliation
        record['check_count'] = len(rows)
        record['declared_errors_observed'] = sum(sum(item['declared_errors'].values()) for item in reconciliation)
        record['reconciled_operations'] = sum(item['success_modes_complete'] for item in reconciliation)
        record['global_checks'] = [row for row in rows if row['case_id'] in ('REST075', 'J12-REST075')]
        record['all_rows_pass'] = all(row['result'] == 'PASS' for row in rows)
        record['available_stream_operations'] = sum(case['available_modes']['sync_stream'] for case in cases['operations'])
        record['absent_stream_operations'] = [case['operation'] for case in cases['operations'] if not case['available_modes']['sync_stream']]
    record['inventory'] = {str(path): dict(sha256=digest(path), bytes=path.stat().st_size)
                           for path in TMP.glob(PREFIX.name + '*') if path != result_path}
    write(result_path, record)
    print(json.dumps(dict(result=str(result_path), exit_code=proc.returncode, execution=record.get('execution'),
                         checks=record.get('check_count'), operations=record.get('reconciled_operations'), errors=record.get('declared_errors_observed'))))
    sys.exit(proc.returncode or (0 if before == after else 1))


if __name__ == '__main__':
    main()
