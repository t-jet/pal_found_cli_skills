"""Reuse transport checks and add independent pipeline semantic assertions."""
from pathlib import Path

tmp = Path(__file__).resolve().parent
code = (tmp / 'rest071_formal_execute.py').read_text(encoding='utf-8').replace('071', '075').replace('TESTCASE-074', 'TESTCASE-077')
code = code.replace("assert len(manifest['operations']) == 27", "assert len(manifest['operations']) == 29")
code = code.replace("    for case in manifest['operations']:\n        assert digest", "    for path, expected in manifest['model_source_bindings'].items():\n        assert digest(path) == expected, path\n    for case in manifest['operations']:\n        canonical = {key: value for key, value in case.items() if key != 'case_sha256'}\n        assert hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == case['case_sha256']\n        assert digest")
begin, end = code.index('def semantic_check('), code.index('\ndef materialize(')
semantic = '''def semantic_check(case, kwargs, value, label):
    if value is None:
        return
    name, method = case['operation'].split('.')[-2:]
    if method == 'get_batch':
        key = name[0].lower() + name[1:] + 'Rid'
        requested = [item[key] for item in kwargs['body']]
        assert len(requested) == 2 and requested[0] != requested[1]
        assert set(value['data']) == {requested[0]}
        assert value['data'][requested[0]]['rid'] == requested[0]
        assert requested[1] not in value['data']
        return
    if name == 'ScheduleVersion' and method == 'schedule':
        assert value['rid'] != kwargs['schedule_version_rid']
        assert value['currentVersionRid'] == kwargs['schedule_version_rid']
        return
    rows = value.get('data', [value]) if isinstance(value, dict) else value
    for item in rows:
        if name == 'Record':
            if method == 'get':
                assert item['rid'] == kwargs['record_rid']
            if method == 'search':
                assert item['justification']['response'] == kwargs['where']['filter']['query']
            assert item['type'] == 'RUN_BUILD'
            assert item['checkpointedItems'][0]['type'] == 'checkpointedJob'
        if name == 'Check':
            if 'check_rid' in kwargs:
                assert item['rid'] == kwargs['check_rid']
            if 'config' in kwargs:
                assert item['config'] == kwargs['config']
        if name == 'CheckReport':
            assert item['check']['rid'] == kwargs['check_rid']
            if 'check_report_rid' in kwargs:
                assert item['rid'] == kwargs['check_report_rid']
        if name == 'Build':
            if method == 'jobs':
                assert item['buildRid'] == kwargs['build_rid']
            elif method == 'get':
                assert item['rid'] == kwargs['build_rid']
            elif method == 'create':
                assert item['branchName'] == kwargs.get('branch_name', None) or item['branchName'] == 'master'
                assert item['fallbackBranches'] == kwargs['fallback_branches']
            elif method == 'search':
                boundary = datetime.fromisoformat(kwargs['where']['value'].replace('Z', '+00:00'))
                started = case['search_state']['started_time_by_build_rid'][item['rid']]
                assert datetime.fromisoformat(started.replace('Z', '+00:00')) >= boundary
        if name == 'Job' and method == 'get':
            assert item['rid'] == kwargs['job_rid']
        if name == 'Schedule':
            if method == 'get_affected_resources':
                assert value['datasets'] == ['ri.qa.main.dataset-output.independent075']
                continue
            if method == 'get':
                assert item['rid'] == kwargs['schedule_rid']
            if method in ('create', 'replace'):
                assert item['action'] == kwargs['action']
                target = item['action']['target']
                assert set(target['targetRids']).isdisjoint(target['ignoredRids'])
            if method in ('run', 'runs'):
                assert item['scheduleRid'] == kwargs['schedule_rid']
                assert item['result']['type'] == 'submitted'
        if name == 'ScheduleVersion' and method == 'get':
            assert item['rid'] == kwargs['schedule_version_rid']

'''
code = code[:begin] + semantic + code[end:]
# Error parameters are checked against their own source-derived shape before execution.
needle = "        response_type = eval(case['source']['request_expressions']['response_type'], vars(module))"
at = code.index(needle, code.index('def preflight('))
code = code[:at] + '''        for declared in case['errors']:
            mod_name, class_name = declared['expected']['exception_class'].rsplit('.', 1)
            cls = getattr(importlib.import_module(mod_name), class_name)
            parameter_type = __import__('typing').get_type_hints(cls)['parameters']
            pydantic.TypeAdapter(parameter_type).validate_python(declared['parameters'])
            if declared['name'] == 'ModifyingCheckTypeNotSupported':
                assert declared['parameters']['originalCheckType'] != declared['parameters']['newCheckType']
                assert declared['parameters']['newCheckType'] == declared['request']['config']['type']
''' + code[at:]
code = code.replace("    parser.add_argument('--readiness-confirmed', action='store_true')", "    parser.add_argument('--readiness-confirmed', action='store_true')\n    parser.add_argument('--reviewer-identity')\n    parser.add_argument('--approved-harness-sha256')")
code = code.replace("    assert args.readiness_confirmed, 'Parent readiness confirmation required'", "    assert args.readiness_confirmed, 'Parent readiness confirmation required'\n    assert args.reviewer_identity and args.reviewer_identity not in (manifest['author_identity'], args.executor_identity), 'Fresh case reviewer and executor required'\n    assert args.approved_harness_sha256 == digest(__file__), 'Approval must bind exact harness'\n    evidence['reviewer_identity'] = args.reviewer_identity")
code = code.replace("    LOG.write_text('', encoding='utf-8')", "    assert not PENDING.exists() or json.loads(PENDING.read_bytes()).get('execution') == 'NOT_RUN', 'Preserve prior execution evidence before rerun'\n    LOG.write_text('', encoding='utf-8')")
code = code.replace("    assert args.executor_identity and args.executor_identity != manifest['author_identity'], 'Actual independent executor identity required'", "    assert args.executor_identity and args.executor_identity != manifest['author_identity'], 'Actual independent executor identity required'")
code = code.replace("failure(case, cls, method, status, 'IndependentPermissionDenied', 'PERMISSION_DENIED', {})", "failure(case, cls, method, status, 'IndependentUnauthorized' if status == 401 else 'IndependentPermissionDenied', 'UNAUTHORIZED' if status == 401 else 'PERMISSION_DENIED', {})")
code = code.replace("            execute(manifest)", "            execute(manifest)\n            pipeline_lifecycle(manifest)")
code = code.replace("chunks = b''.join(wrapper.iter_bytes(chunk_size=5))", "chunks = bounded_chunks(wrapper.iter_bytes(chunk_size=5), max_bytes=1048576, max_chunks=10000)")
code = code.replace("chunks = b''.join([chunk async for chunk in wrapper.aiter_bytes(chunk_size=5)])", "parts = []\n            total = 0\n            async for chunk in wrapper.aiter_bytes(chunk_size=5):\n                total += len(chunk)\n                assert total <= 1048576 and len(parts) < 10000, 'REST075_RESPONSE_BUDGET_EXCEEDED'\n                parts.append(chunk)\n            chunks = b''.join(parts)")
extra = (tmp / 'rest075_formal_harness_extra.py').read_text(encoding='utf-8')
code = code.replace("\ndef main():", '\n' + extra + '\n\ndef main():')
(tmp / 'rest075_formal_execute.py').write_text(code, encoding='utf-8')
