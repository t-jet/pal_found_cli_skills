"""Independently validate applicability and runtime evidence for REST075 unit modes."""
import ast
import asyncio
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import socket
import subprocess
import sys
import time

import pytest

TMP = Path(__file__).resolve().parent
ROOT = TMP.parents[1]
REPO = TMP / 'feature015_integration'
TEST = REPO / 'tests/test_offline_rest_075.py'
AUTHOR = TMP / 'rest075_modes_author_validation_20261028.json'
OUT = TMP / 'feature015_rest075_unit_modes_review_20261028.json'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(TEST) == 'd81a04ec9b51a1e480f03570900509d02a293d60e79fba7cd9089b3310f72db3'
assert sha(AUTHOR) == '70af321f65e44f2757b49a417ef46c05fba43f4ee4d4d66611b57d0c0766c8d4'
spec = importlib.util.spec_from_file_location('independent_rest075_modes_candidate', TEST)
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
report = {
    'story': 'DEV-STORY-075', 'unit_ticket': 'UNITTEST-077',
    'reviewer_agent': '/root/rest075_qa_20261028',
    'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'review_date': '2026-10-28 Europe/Sofia', 'sdk_release': '1.101.0',
    'test_path': str(TEST), 'test_sha256': sha(TEST),
    'author_evidence': {'path': str(AUTHOR), 'sha256': sha(AUTHOR)},
    'operations': [], 'commands': [], 'shared_edits': False,
    'formal_qa_status': 'pending',
}

def save():
    OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

stream_ids, paged_ids, native_async_iterators = [], [], []
for service, resource, operation in candidate.CASES:
    identity = f'v2.{service}.{resource}.{operation}'
    source = candidate.contract(service, resource, operation)
    source_path = Path(inspect.getfile(source['client']))
    tree = ast.parse(source_path.read_text())
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    wrappers = {}
    for prefix in ('_' + resource + 'Client', '_Async' + resource + 'Client'):
        for mode in ('Raw', 'Streaming'):
            init = next(node for node in classes[prefix + mode].body
                        if isinstance(node, ast.FunctionDef) and node.name == '__init__')
            names = {target.attr for node in ast.walk(init) if isinstance(node, ast.Assign)
                     for target in node.targets if isinstance(target, ast.Attribute)
                     and isinstance(target.value, ast.Name) and target.value.id == 'self'}
            wrappers[prefix + mode] = operation in names
    assert wrappers['_' + resource + 'ClientRaw']
    assert wrappers['_Async' + resource + 'ClientRaw']
    streaming = wrappers['_' + resource + 'ClientStreaming']
    assert streaming == wrappers['_Async' + resource + 'ClientStreaming']
    assert streaming == ((service, resource, operation) in candidate.STREAM_CASES)
    if streaming:
        stream_ids.append(identity)
    paged = 'page_token' in inspect.signature(getattr(source['client'], operation)).parameters
    assert paged == ((service, resource, operation) in candidate.PAGED_CASES)
    if paged:
        paged_ids.append(identity)
    annotation = inspect.signature(getattr(candidate.async_client(source), operation)).return_annotation
    if 'AsyncResourceIterator' in str(annotation):
        native_async_iterators.append(identity)
    report['operations'].append({
        'id': identity, 'source_path': str(source_path), 'source_sha256': sha(source_path),
        'async_return_annotation': str(annotation), 'raw_sync_and_async': True,
        'stream_sync_and_async_applicable': streaming, 'finite_pagination_applicable': paged,
        'unit_source_binding': 'PASS',
    })
assert len(report['operations']) == 29 and len(stream_ids) == 24 and len(paged_ids) == 4
assert set(native_async_iterators) == {
    'v2.orchestration.Build.jobs', 'v2.orchestration.Schedule.runs'}
report['applicability'] = {
    'stream_operations': stream_ids, 'paged_operations': paged_ids,
    'native_async_iterators': native_async_iterators,
    'sse_operations': [],
    'no_sse_source_evidence': 'All29 RequestInfo response types are ordinary models or None; wrapper constructors use raw/streaming response functions, with no SSE wrapper declared.',
}

loop = asyncio.new_event_loop()
patch = pytest.MonkeyPatch()
try:
    candidate.deny_public_network.__wrapped__(patch, loop)
    for label, action in (
        ('DNS', lambda: socket.getaddrinfo('offline.invalid', 443)),
        ('public_connection', lambda: socket.create_connection(('offline.invalid', 443))),
    ):
        try:
            action()
        except AssertionError as error:
            assert 'REST075 attempted public network access' in str(error)
        else:
            raise AssertionError(label + ' guard did not block')
finally:
    patch.undo()
    loop.close()
report['network_guard'] = {
    'self_test': 'PASS',
    'scope': 'Each test denies socket connect/connect_ex, DNS helpers and native HTTP transports; mock HTTP remains permitted. Windows event-loop local socket pair is deliberately initialized before guard activation.',
}

for command in (
    [sys.executable, '-m', 'pytest', str(TEST), '-q', '--basetemp=' + str(TMP / 'rest075_modes_independent_basetemp_20261028'),
     '-o', 'cache_dir=' + str(TMP / 'rest075_modes_independent_cache_20261028')],
    ['ruff', 'check', str(TEST)],
):
    started = time.perf_counter()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
    report['commands'].append({'command': command, 'exit_code': result.returncode,
                               'elapsed_seconds': time.perf_counter() - started,
                               'stdout': result.stdout, 'stderr': result.stderr})
    save()
    assert result.returncode == 0, result.stdout + result.stderr
assert '214 passed' in report['commands'][0]['stdout']
assert sha(TEST) == report['test_sha256']
assert all(sha(Path(row['source_path'])) == row['source_sha256'] for row in report['operations'])
report['manual_review'] = [
    'Original86 semantic/source/error/mutation tests remain;58 new native/raw async checks invoke actual SDK classes for all29 operations. Actual iterator annotations are distinguished from awaitables.',
    'Forty-eight streaming checks cover exactly24 methods declared by SDK streaming wrappers. CustomSync/AsyncByteStream is initially open; two4-byte chunks consumed before caller exception, third chunk unread, both response and stream closed by SDK context. Closure proof is not eager-content vacuity.',
    'Eight pagination checks cover four actual page-token methods in both sync/async forms, asserting exact first/continuation token, two requests, final-page termination and response closure. Native iterators and explicit response continuation are treated separately.',
    'Fourteen read-timeout cases cover seven resource clients, verify actual timeout30 extension, SDK ReadTimeout with preserved httpx cause and one request under the configured one-attempt fixture policy.',
    'Tests source the request/result types and method/path/header contracts from installed frozen SDK and reconcile source hashes with the independent oracle. Example inputs remain adaptable input data; semantic mutation guards prevent fixture-only mirroring.',
]
report['runtime_counts'] = {
    'prior_semantic_and_sync_raw': 86, 'native_async_and_async_raw': 58,
    'sync_async_stream_budget_early_close': 48, 'sync_async_finite_pagination': 8,
    'sync_async_read_timeout': 14, 'total': 214,
}
report['unit_mode_scope_verdict'] = 'ACCEPTED'
report['unit_runtime_mode_gap_from_prior_review'] = 'RESOLVED'
report['status_boundary'] = 'UNIT077 applicable runtime coverage is now supported at these exact bytes. Ticket resolution still requires committed files, accurate time/frontmatter and workflow DoD. This report changes no ticket; formal case/execution acceptance is separate.'
report['limits'] = [
    'No live Foundry service, server scheduling, authorization, filtering, actual retry policy or uncertain mutation guarantee is established by the synthetic transport.',
    'Finite pagination checks prove bounded fixture termination for these four methods, not exhaustive repeated-token/recovery behavior in all possible service responses.',
    'Streaming early-exit exercises byte transport lifetime; typed response decoding remains covered separately by raw/native tests.',
]
report['asset_stability_after_execution'] = True
report['completed_at_utc'] = datetime.now(timezone.utc).isoformat()
save()
print(json.dumps({'unit_mode_scope': report['unit_mode_scope_verdict'], 'tests': 214,
                  'report': str(OUT), 'sha256': sha(OUT)}))
