from pathlib import Path
import hashlib,json
p=Path('.ept/tmp')
names=['cases.json','execute.py','readiness.json','static_validation.json','execution.json','prepare_harness.py','harness_extra.py','build_cases.py','prepare.py','semantics.py','validate.py']
rows=[]
for name in names:
 src=p/('rest075_formal_'+name); dst=p/('rest075_formal_rejected01_'+name)
 assert not dst.exists(),dst
 dst.write_bytes(src.read_bytes());rows.append({'original':str(src),'preserved':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
review=p/'rest075_case_approval_20261029.json'
if review.exists():
 dst=p/'rest075_formal_rejected01_review.json';dst.write_bytes(review.read_bytes());rows.append({'original':str(review),'preserved':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
(p/'rest075_formal_rejected01_manifest.json').write_text(json.dumps({'finding':'Unconditional streaming error invocation on five methods with no streaming wrapper: Check.delete, Build.cancel, Schedule.delete, Schedule.pause, Schedule.unpause. No formal execution run.','files':rows},indent=2)+'\n')
print(json.dumps(rows[:4]))
