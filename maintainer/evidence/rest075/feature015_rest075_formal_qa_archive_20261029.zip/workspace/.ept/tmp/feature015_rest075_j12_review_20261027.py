"""Capture bounded independent REST075 semantic review and J12 continuity."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.metadata
import inspect
import json
from pathlib import Path
import runpy
import socket
import subprocess
import sys
import textwrap
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
TMP = ROOT / '.ept/tmp'
REPO = TMP / 'feature015_integration'
OWNER = REPO / '.agents/skills/pal-found-dev'
OUT = TMP / 'feature015_rest075_j12_readiness_20261027.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
register = json.loads((REPO / 'maintainer/rest-domain-authoring-register.json').read_bytes())
oracle = json.loads((REPO / 'tests/fixtures/offline/rest-acceptance/source-oracle.json').read_bytes())
contracts = {r['id']: r for r in json.loads((REPO / 'maintainer/rest-contract-register.json').read_bytes())['operations']}

def deny(*args, **kwargs):
    raise AssertionError('Public DNS/socket access denied in REST075 QA')

def normalized(value):
    return ast.dump(ast.parse(value, mode='eval').body)

findings = {
    'v2.data_health.Check.replace': ('FAIL', 'ModifyingCheckTypeNotSupported uses equal originalCheckType/newCheckType; the source-declared error means changing the type. Error fixture contradicts its own source semantics.'),
    'v2.orchestration.Schedule.create': ('FAIL', 'Submitted upstream target contains the target dataset and omits ignoredRids; success adds that same target to ignoredRids, changing the intended build set without explanation. Source UpstreamTarget describes ignored datasets as excluded from the final set.'),
    'v2.orchestration.Schedule.replace': ('FAIL', 'Replacement upstream target omits ignoredRids; returned action ignores its only selected target, so successful replacement does not demonstrate preservation of the submitted target.'),
    'v2.orchestration.Build.search': ('UNCERTAIN', 'STARTED_TIME lt filter value is synthetic-value. Frozen SDK permits Any and does not supply a value-format constraint; serialization cannot prove an applicable time query. Use a meaningful timestamp and a result consistent with the selected comparison.'),
}
for identity in ['v2.checkpoints.Record.get_batch', 'v2.orchestration.Build.get_batch', 'v2.orchestration.Job.get_batch', 'v2.orchestration.Schedule.get_batch']:
    findings[identity] = ('UNCERTAIN', 'Success contains an empty data map although one identity was requested. SDK permits missing/inaccessible omissions, so this is not a proven endpoint defect; example lacks a found record and requested-to-returned identity demonstration.')

observations = {
    'checkpoints': 'Record IDs, checkpoint processing context and justification are synthetic. Search text matches the response justification. Batch omission remains separately uncertain.',
    'data_health': 'Check configuration is distinct from evaluation report; create/replace payload matches returned numericColumnRange config. NumericBounds optional lower/upper are both absent: the SDK permits this, so no unsupported nonempty-bound rule is invented. Reports explicitly PASSED and latest returns one report. Type-change error separately fails.',
    'orchestration': 'Build RUNNING is not success, cancel/pause/unpause acknowledge requests without claiming completed work, jobs keep build identity, schedules/runs/versions remain separate resources. Configurable synthetic identity and response objects are not tenant-valid execution evidence. Specific batch/search/action issues are separately withheld.',
}
report = {
    'story': 'DEV-STORY-075', 'reviewer_agent': '/root/j12_075_readiness_20261027',
    'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'candidate_sha': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip(),
    'sdk_release': importlib.metadata.version('foundry-platform-sdk'),
    'scope': 'Independent source/behavior/example review of all 29 operations and original example execution through real SDK synthetic HTTP transport. Formal independently authored TESTEXEC cases, all wrapper modes, full pagination, live enrollment and whole-page CLI review are not claimed.',
    'network_boundary': 'DNS and socket connect/connect_ex/create_connection patched to fail in the probe process. Actual source examples use httpx MockTransport. This is not OS-wide or subprocess network isolation.',
    'operations': [],
}
assert report['sdk_release'] == oracle['sdk_release'] == '1.101.0'
with patch.object(socket, 'getaddrinfo', deny), patch.object(socket, 'create_connection', deny), patch.object(socket.socket, 'connect', deny), patch.object(socket.socket, 'connect_ex', deny):
    try:
        socket.getaddrinfo('example.com', 443)
        raise RuntimeError('Network guard did not deny DNS')
    except AssertionError:
        report['network_guard_probe'] = 'PASS'
    for row in register['operations']:
        if row['story'] != report['story']:
            continue
        identity = row['id']
        frozen = oracle['operations'][identity]
        module = importlib.import_module(frozen['module'])
        resource, method = identity.split('.')[-2:]
        source = Path(module.__file__)
        fn = getattr(getattr(module, resource + 'Client'), method)
        tree = ast.parse(textwrap.dedent(inspect.getsource(fn)))
        expected_args = ast.parse('def f(' + frozen['ordinary']['signature'] + '): pass').body[0].args
        assert ast.dump(tree.body[0].args) == ast.dump(expected_args), identity
        wire = next(node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'RequestInfo')
        values = {kw.arg: ast.dump(kw.value) for kw in wire.keywords}
        assert all(values[key] == normalized(value) for key, value in frozen['wire'].items()), identity
        assert sha(source) == row['source_sha256'] == frozen['source_sha256'], identity
        paths = {'behavior': OWNER / row['behavior'], 'example': OWNER / row['example'], 'contract': OWNER / contracts[identity]['contract']}
        hashes = {key + '_sha256': sha(path) for key, path in paths.items()}
        assert hashes['behavior_sha256'] == row['behavior_sha256'] and hashes['example_sha256'] == row['example_sha256'], identity
        ns = runpy.run_path(str(paths['example']))
        status, reason = findings.get(identity, ('PASS', observations[identity.split('.')[1]]))
        try:
            ns['verify']()
            fixture = 'PASS'
        except Exception as exc:
            fixture = 'FAIL'
            status, reason = 'FAIL', f'Actual SDK fixture failed: {type(exc).__name__}: {exc}'
        report['operations'].append({
            'id': identity, 'verdict': status, 'reason': reason, **hashes,
            'source_module': frozen['module'], 'source_sha256': sha(source),
            'source_method_sha256': hashlib.sha256(inspect.getsource(fn).encode()).hexdigest(),
            'source_method_documentation': inspect.getdoc(fn),
            'source_stage': frozen['documentation']['stage'],
            'source_doc_sha256': row['doc_sha256'], 'signature_and_wire_source_match': True,
            'fixture_execution': fixture, 'declared_errors_exercised': len(ns['ERRORS']),
            'expected_body': ns['EXPECTED_BODY'], 'success_fixture': ns['SUCCESS'],
            'error_fixtures': ns['ERRORS'],
        })

old = TMP / 'feature015_fresh_reader'
manifest = json.loads((old / 'manifest.json').read_bytes())
consulted = ['SKILL.md', 'references/rest-api.md', 'references/rest/catalog.md',
    'references/rest/authentication.md', 'references/rest/client-behavior.md',
    'references/rest/v2/datasets/Transaction.md', 'references/rest/v2/datasets/File.md',
    'references/rest/v2/orchestration/Build.md',
    *[f'references/rest/contracts/v2/datasets/Transaction/{method}.md' for method in ['create', 'commit', 'get', 'abort']],
    'references/rest/contracts/v2/datasets/File/upload.md',
    'references/rest/contracts/v2/orchestration/Build/get.md',
    'examples/rest/074/v2/datasets/staged_commit_journey.py']
report['j12'] = {
    'bug': 'BUG-SUB-025',
    'current_fixture_sha256': sha(OWNER / consulted[-1]),
    'prior_reader_sha256': sha(old / 'j12_reader.py'),
    'prior_answer_sha256': sha(old / 'j12_answer.md'),
    'prior_output_sha256': sha(old / 'j12_output.json'),
    'continuity': [{'path': path, 'old_snapshot_sha256': manifest['skill_files'].get(path),
                    'current_sha256': sha(OWNER / path),
                    'unchanged': manifest['skill_files'].get(path) == sha(OWNER / path)} for path in consulted],
    'fresh_reader_required': True,
    'boundary': 'This reviewer read retained answers; rerunning that code is continuity verification, not a new source-blind reader task. A fresh independent reader plus durable exact-candidate output is still required by the bug acceptance criteria.',
}
# The reader itself and current distributed fixture contain their own process-scoped
# socket/DNS guards. They do not import implementation from the knowledge checkout.
for label, script in [('retained_reader', old / 'j12_reader.py'), ('current_distributed_fixture', OWNER / consulted[-1])]:
    result = subprocess.run([sys.executable, '-B', str(script)], capture_output=True, text=True, cwd=ROOT)
    report['j12'][label] = {'command': [sys.executable, '-B', str(script)], 'exit_code': result.returncode,
                            'stdout': result.stdout, 'stderr': result.stderr}
report['counts'] = dict(Counter(row['verdict'] for row in report['operations']))
report['fixture_counts'] = dict(Counter(row['fixture_execution'] for row in report['operations']))
report['readiness'] = {'dedicated_test_suite': 'No tests/test_offline_rest_075*.py found at review start.',
                       'formal_test_execution': 'pending; this semantic probe does not substitute TESTEXEC acceptance',
                       'tracker_writer': 'No tracker writes performed; existing BUG-SUB-025 In Progress and LINK-01894 retained.'}
OUT.write_text(json.dumps(report, indent=2, default=str) + '\n', encoding='utf-8')
print(json.dumps({'report': str(OUT), 'counts': report['counts'], 'fixtures': report['fixture_counts'],
                  'j12_changed_consulted_paths': [r['path'] for r in report['j12']['continuity'] if not r['unchanged']],
                  'j12_exit_codes': {k: report['j12'][k]['exit_code'] for k in ['retained_reader', 'current_distributed_fixture']}}))
