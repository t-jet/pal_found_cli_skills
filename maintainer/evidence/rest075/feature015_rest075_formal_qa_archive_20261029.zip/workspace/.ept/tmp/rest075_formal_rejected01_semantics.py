DATASET = RID('dataset-output')
SUBJECT = {'datasetRid': DATASET, 'branchId': 'master'}
TARGET = {'type': 'upstream', 'targetRids': [DATASET], 'ignoredRids': [RID('excluded-upstream')]}
CONFIG = {'type': 'numericColumnRange', 'subject': SUBJECT, 'columnName': 'amount',
          'numericBoundsConfig': {'numericBounds': {'lowerBound': 0, 'upperBound': 1000}, 'severity': 'MODERATE'}}
ACTION = {'target': TARGET, 'branchName': 'master', 'fallbackBranches': ['master'],
          'forceBuild': False, 'abortOnFailure': True, 'notificationsEnabled': False,
          'retryCount': 0, 'retryBackoffDuration': {'value': 5, 'unit': 'SECONDS'}}


def request_overrides(resource, method, kwargs):
    result = {'preview': True, 'page_size': 2, 'page_token': None, 'sort_direction': 'ASC',
              'config': CONFIG, 'intent': 'Validate output amounts', 'fallback_branches': ['master'],
              'branch_name': 'master', 'target': TARGET, 'action': ACTION,
              'abort_on_failure': True, 'force_build': False, 'notifications_enabled': False,
              'retry_count': 0, 'retry_backoff_duration': {'value': 5, 'unit': 'SECONDS'},
              'display_name': 'Independent075 output build', 'description': 'Build reviewed output dataset',
              'trigger': {'type': 'manual'}, 'scope_mode': {'type': 'project', 'projectRids': [RID('project')]}}
    if resource == 'Record':
        result['where'] = {'filter': {'type': 'textSearch', 'field': 'justificationResponse',
                                     'query': 'Approved output review', 'matchType': 'EXACT'}}
    if resource == 'Build':
        result['where'] = {'type': 'gte', 'field': 'STARTED_TIME', 'value': '2026-10-29T00:00:00Z'}
        result['order_by'] = None
    if method == 'get_batch':
        key = resource[0].lower() + resource[1:] + 'Rid'
        result['body'] = [{key: RID(resource.lower())}, {key: RID('omitted-' + resource.lower())}]
    return result


def result_model(resource):
    services = {'Record': 'checkpoints', 'Check': 'data_health', 'CheckReport': 'data_health'}
    module = importlib.import_module('foundry_sdk.v2.' + services.get(resource, 'orchestration') + '.models')
    return sample(pydantic.TypeAdapter(getattr(module, resource)).json_schema())


def rewrite_reply(value, resource, method, kwargs):
    if resource == 'ScheduleVersion' and method == 'schedule':
        return rewrite_reply(value, 'Schedule', 'get', {'schedule_rid': RID('schedule')})
    if method == 'get_batch':
        key = resource[0].lower() + resource[1:] + 'Rid'
        found = kwargs['body'][0][key]
        item = rewrite_reply(result_model(resource), resource, 'get', {resource.lower() + '_rid': found})
        return {'data': {found: item}}
    if isinstance(value, list):
        return [rewrite_reply(item, resource, method, kwargs) for item in value]
    if not isinstance(value, dict):
        return value
    if 'data' in value:
        child = 'Job' if resource == 'Build' and method == 'jobs' else 'ScheduleRun' if resource == 'Schedule' and method == 'runs' else resource
        return {'data': [rewrite_reply(item, child, 'get', kwargs) for item in value['data']]}
    value = copy.deepcopy(value)
    if resource == 'Record':
        value.update(rid=kwargs.get('record_rid', RID('record')), type='RUN_BUILD', scope='RESOURCE_SCOPED',
                     actingUser={'userId': UUID, 'username': {'value': 'independent-reviewer075'}},
                     checkpointedItems=[{'type': 'checkpointedJob', 'jobRid': RID('job')}],
                     createdAt=STAMP, justification={'type': 'responseJustification', 'response': 'Approved output review',
                                                   'prompt': 'Why run this build?', 'title': 'Build review'})
    elif resource == 'Check':
        value.update(rid=kwargs.get('check_rid', RID('check')), groups=[], config=copy.deepcopy(kwargs.get('config', CONFIG)))
        if kwargs.get('intent') is not None:
            value['intent'] = kwargs['intent']
    elif resource == 'CheckReport':
        value.update(rid=kwargs.get('check_report_rid', RID('check-report')),
                     check=rewrite_reply(result_model('Check'), 'Check', 'get', kwargs), createdTime=STAMP)
    elif resource == 'Build':
        value.update(rid=kwargs.get('build_rid', RID('build')), branchName=kwargs.get('branch_name') or 'master',
                     createdTime=STAMP, createdBy=UUID, fallbackBranches=kwargs.get('fallback_branches', ['master']),
                     jobRids=[RID('job')], retryCount=0, retryBackoffDuration={'value': 5, 'unit': 'SECONDS'},
                     abortOnFailure=True, status='RUNNING')
    elif resource == 'Job':
        value.update(rid=kwargs.get('job_rid', RID('job')), buildRid=kwargs.get('build_rid', RID('build')),
                     startedTime=STAMP, jobStatus='RUNNING', outputs=[{'type': 'datasetJobOutput', 'datasetRid': DATASET}])
    elif resource == 'Schedule' and method == 'run':
        return rewrite_reply(value, 'ScheduleRun', method, kwargs)
    elif resource == 'Schedule' and method == 'get_affected_resources':
        return {'datasets': [DATASET]}
    elif resource in ('Schedule', 'ScheduleVersion'):
        value.update(rid=kwargs.get('schedule_rid' if resource == 'Schedule' else 'schedule_version_rid', RID('schedule' if resource == 'Schedule' else 'schedule-version')),
                     action=copy.deepcopy(kwargs.get('action', ACTION)), scopeMode=copy.deepcopy(kwargs.get('scope_mode') or {'type': 'project', 'projectRids': [RID('project')]}),
                     createdTime=STAMP, createdBy=UUID, trigger=copy.deepcopy(kwargs.get('trigger') or {'type': 'manual'}))
        if resource == 'Schedule':
            value.update(currentVersionRid=RID('schedule-version'), updatedTime=STAMP, updatedBy=UUID, paused=False)
            for arg, alias in [('display_name', 'displayName'), ('description', 'description')]:
                if kwargs.get(arg) is not None:
                    value[alias] = kwargs[arg]
        else:
            value['scheduleRid'] = RID('schedule')
    elif resource == 'ScheduleRun':
        value.update(rid=RID('schedule-run'), scheduleRid=kwargs.get('schedule_rid', RID('schedule')),
                     scheduleVersionRid=RID('schedule-version'), createdTime=STAMP,
                     result={'type': 'submitted', 'buildRid': RID('build')})
    return value


def adverse(name, params, kwargs, resource, method, reply):
    conditions = ['Synthetic service denies or cannot find the exact requested resource; fixture proves SDK decoding only.']
    if name == 'CheckAlreadyExists':
        params['conflictingCheck'] = copy.deepcopy(reply)
        conditions = ['An accessible existing check has exactly the requested subject and config; the service returns that check as the conflict.']
    if name == 'CheckTypeNotSupported':
        params['checkType'] = kwargs.get('config', CONFIG)['type']
        conditions = ['Synthetic enrollment does not expose this requested or stored check type; the SDK declares no universal supported subset.']
    if name == 'ModifyingCheckTypeNotSupported':
        params.update(originalCheckType='columnType', newCheckType=kwargs['config']['type'])
        conditions = ['Existing check has columnType config. Replacement requests numericColumnRange. Changing type is unsupported.']
    invalid = {
        'InvalidNumericColumnCheckConfig': ('numericColumnMean', 'numericColumnCheckConfig', {'columnName': 'amount'}),
        'InvalidPercentageCheckConfig': ('nullPercentage', 'percentageCheckConfig', {'columnName': 'amount'}),
        'InvalidTimeCheckConfig': ('buildDuration', 'timeCheckConfig', {}),
        'InvalidTransactionTimeCheckConfig': ('timeSinceLastUpdated', 'timeCheckConfig', {}),
        'InvalidTrendConfig': ('numericColumnMean', 'numericColumnCheckConfig', {'columnName': 'amount', 'trend': {'severity': 'MODERATE'}})}
    if name in invalid:
        kind, key, config = invalid[name]
        kwargs['config'] = {'type': kind, 'subject': copy.deepcopy(SUBJECT), key: copy.deepcopy(config)}
        conditions = ['Adverse config omits both alternatives required by the source error description. Pydantic accepts the shape; synthetic service rejects its semantic condition.']
        if method == 'replace':
            conditions.append('Existing check has the same type as this adverse replacement; only the invalid nested config changes.')
    return params, kwargs, conditions


def domain_extras(row, resource, method, kwargs, reply, defaults, expressions, module):
    extras = row['additional_cases']
    for extra in extras:
        if extra['name'] == 'optional omission':
            extra['response'] = rewrite_reply(sample(row['success']['schema']), resource, method, extra['request'])
            extra['success']['json'] = copy.deepcopy(extra['response'])
            extra['source_condition'] = 'Synthetic enrollment returns the selected optional values. This fixture does not establish platform defaults for omitted trigger, scope, branch or other options.'
        if extra['name'] == 'finite continuation':
            first = extra['responses'][0]['data'][0]
            second = extra['responses'][1]['data'][0]
            if isinstance(second, dict) and 'rid' in second:
                second['rid'] = RID('second-page-' + resource.lower())
    if resource == 'ScheduleVersion' and method == 'schedule':
        extras.append({'name': 'schedule absent for retained version', 'request': copy.deepcopy(kwargs),
                       'expected_wire': wire(expressions, module, kwargs), 'success': {'http_status': 200, 'json': None}})
    if method == 'get_batch':
        limit = row['request']['argument_schemas']['body']['maxItems']
        for count in (0, limit + 1):
            bad = copy.deepcopy(kwargs)
            bad['body'] = kwargs['body'][:1] * count
            extras.append({'name': 'batch length ' + str(count), 'request': bad,
                           'expected_exception': 'pydantic.ValidationError', 'expected_request_count': 0})
    if resource == 'Build' and method == 'search':
        row['source_silence'].append('SearchBuildsGteFilter.value is Any. UTC string is illustrative and requires enrollment verification; SDK acceptance is not server validation.')
        row['search_state'] = {'started_time_by_build_rid': {
            RID('build'): '2026-10-29T08:00:00Z',
            RID('second-page-build'): '2026-10-29T09:00:00Z'},
            'boundary': 'Synthetic server start metadata supports the filter. Build.createdTime is not asserted to be STARTED_TIME.'}
        bad = copy.deepcopy(kwargs)
        bad['where']['value'] = {'unsupported': 'time-object'}
        row['execution_error_variants'] = [{'name': 'InvalidSearchTimestamp075', 'status': 400,
            'errorCode': 'INVALID_ARGUMENT', 'parameters': {'field': 'STARTED_TIME'}, 'kwargs': bad,
            'expected_wire': wire(expressions, module, bad)}]
        row['execution_variants'] = []


def make_journeys(rows):
    by_id = {row['operation']: row for row in rows}
    steps = []
    sequence = [('schedule', 'Schedule.get'), ('submitted', 'Schedule.run'),
                ('running', 'Build.get'), ('succeeded', 'Build.get'), ('job', 'Job.get'),
                ('checkpoint', 'Record.get'), ('check', 'Check.get'), ('report', 'CheckReport.get'),
                ('pause', 'Schedule.pause'), ('paused', 'Schedule.get'),
                ('unpause', 'Schedule.unpause'), ('unpaused', 'Schedule.get')]
    for label, suffix in sequence:
        service = 'checkpoints' if suffix.startswith('Record.') else 'data_health' if suffix.startswith(('Check.', 'CheckReport.')) else 'orchestration'
        operation = 'v2.' + service + '.' + suffix
        success = copy.deepcopy(by_id[operation]['success'])
        value = success['json']
        if label == 'succeeded':
            value.update(status='SUCCEEDED', finishedTime='2026-10-29T08:03:00Z')
        if label == 'job':
            value.update(jobStatus='SUCCEEDED', finishedTime='2026-10-29T08:02:59Z')
            value['outputs'][0]['outputTransactionRid'] = RID('transaction')
        if label == 'paused':
            value['paused'] = True
        if label in ('checkpoint', 'report'):
            value['createdAt' if label == 'checkpoint' else 'createdTime'] = '2026-10-29T08:04:00Z'
        steps.append({'name': label, 'operation': operation, 'success': success})
    return [{'id': 'J12-REST075', 'steps': steps, 'max_requests_per_mode': 12,
             'max_build_observations': 2, 'adverse': 'Denied schedule read stops before run.',
             'boundary': 'This REST partition links synthetic state only. Transaction file verification belongs to separate J12 integrated evidence; no real build or data persistence is claimed.'}]

