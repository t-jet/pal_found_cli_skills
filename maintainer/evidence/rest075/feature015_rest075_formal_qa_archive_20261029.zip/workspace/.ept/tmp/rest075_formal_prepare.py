"""Build independent REST075 cases from pinned SDK source and model schemas."""
from pathlib import Path

TMP = Path(__file__).resolve().parent
prior = (TMP / 'rest087_formal_build_cases.py').read_text(encoding='utf-8')
prefix = prior[:prior.index('def model_api():')].replace('087', '075').replace('/root/rest075_cases_correct_20261028', '/root/rest075_formal_recover_20261029')
prefix = prefix.replace("STAMP = '2026-10-28T08:00:00Z'", "STAMP = '2026-10-29T08:00:00Z'")
prefix = prefix.replace('import typing\n', 'import typing\nimport time\n')
prefix = prefix.replace("return sample(choices[0], root, name, depth + 1)", "choices.sort(key=lambda choice: any(term in choice.get('$ref', '') for term in ('NotFilter', 'AndFilter', 'OrFilter', 'AndTrigger', 'OrTrigger')))\n            return sample(choices[0], root, name, depth + 1)")
main = prior[prior.index('domain = json.loads'):]
main = main.replace('087', '075').replace('TESTCASE-068', 'TESTCASE-077')
main = main.replace("    version, service, resource, method = asset['id'].split('.')", "    operation_start = time.perf_counter()\n    version, service, resource, method = asset['id'].split('.')")
main = main.replace("    row['case_sha256']", "    row['preparation_elapsed_seconds'] = time.perf_counter() - operation_start\n    row['case_sha256']")
start = main.index('    overrides = ')
end = main.index('    kwargs.update({k: copy.deepcopy(v)', start)
main = main[:start] + "    overrides = request_overrides(resource, method, kwargs)\n" + main[end:]
start = main.index("    if resource == 'OpenAiModel':")
end = main.index('    success = ', start)
main = main[:start] + main[end:]
start = main.index("        aliases = ")
end = main.index("        base = next", start)
main = main[:start] + "        params, error_kwargs, condition = adverse(error_name, params, error_kwargs, resource, method, reply)\n" + main[end:]
start = main.index("    if resource == 'ModelStudioConfigVersion' and method == 'get':")
end = main.index("    row['gherkin']", start)
main = main[:start] + "    domain_extras(row, resource, method, kwargs, reply, defaults, expressions, module)\n" + main[end:]
start = main.index("manifest['journeys']")
end = main.index("out = TMP", start)
main = main[:start] + "manifest['journeys'] = make_journeys(rows)\n" + main[end:]
main = main.replace("'example_fixture_executed': False", "'example_fixture_executed': False, 'formal_execution': 'NOT_RUN'")
main = main.replace(' The direct-REST adapter implementation was inspected to target its callable and response budgets.', '')
main = main.replace("manifest['journeys'] = make_journeys(rows)", "manifest['model_source_bindings'] = {str(Path(importlib.import_module('foundry_sdk.v2.' + service + '.models').__file__)): sha(importlib.import_module('foundry_sdk.v2.' + service + '.models').__file__) for service in ('core', 'checkpoints', 'data_health', 'orchestration')}\nmanifest['journeys'] = make_journeys(rows)")
main = main.replace("item['rid'] = RID('second-page-' + resource.lower())", "item['rid'] = RID('second-page-' + resource.lower())")
main = main.replace("    row['case_sha256']", "    row['case_sha256']")
custom = (TMP / 'rest075_formal_semantics.py').read_text(encoding='utf-8')
(TMP / 'rest075_formal_build_cases.py').write_text(prefix + custom + '\n' + main, encoding='utf-8')

