"""Record current, independent REST075 architect approval through tracker CLI."""
import ast
from datetime import datetime, timezone
import hashlib
import importlib
import inspect
import json
import os
from pathlib import Path
import re
import subprocess
import sys

import foundry_sdk

TMP = Path(__file__).resolve().parent
ROOT = TMP.parents[1]
REPO = TMP / 'feature015_integration'
OWNER = REPO / '.agents/skills/pal-found-dev'
MAINT = REPO / 'maintainer'
CLI = ROOT / '.ept/tools/tracker/tracker_cli.py'
OUT = TMP / 'feature015_rest075_architect_closure_20261029.json'
PROOF = TMP / 'feature015_rest075_architect_source_review_20261029.json'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
semantic_path = TMP / 'feature015_rest075_semantic_retest_20261028.json'
mode_path = TMP / 'feature015_rest075_unit_modes_review_20261028.json'
assert sha(semantic_path) == '60b155a7eb9f862a477081a53c9ff49213cca6ab4e2c31e5b9549b4618a40dd1'
assert sha(mode_path) == 'a52842ec84b69023a9c105daf00f83aaf3bee519e63cd7a692a8e03f5b57047d'
semantic = json.loads(semantic_path.read_bytes())
modes = json.loads(mode_path.read_bytes())
test = REPO / 'tests/test_offline_rest_075.py'
assert sha(test) == modes['test_sha256'] == 'd81a04ec9b51a1e480f03570900509d02a293d60e79fba7cd9089b3310f72db3'
assert modes['unit_mode_scope_verdict'] == 'ACCEPTED'
assert semantic['counts'] == {'PASS': 29}
contracts = {row['id']: row for row in json.loads((MAINT / 'rest-contract-register.json').read_bytes())['operations']}
rows = {row['id']: row for row in json.loads((MAINT / 'rest-domain-authoring-register.json').read_bytes())['operations'] if row['story'] == 'DEV-STORY-075'}
assert len(rows) == 29 and set(rows) == {row['id'] for row in semantic['operations']}
report = {'actor': '/root/rest075_qa_20261028', 'role': 'architect',
          'started_at_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
          'semantic_evidence_sha256': sha(semantic_path), 'mode_evidence_sha256': sha(mode_path)}

def save():
    OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def cli(*args):
    result = subprocess.run([sys.executable, str(CLI), *args], cwd=ROOT, capture_output=True,
                            text=True, encoding='utf-8', env=dict(os.environ, PYTHONIOENCODING='utf-8'))
    report['commands'].append({'args': list(args), 'exit_code': result.returncode,
                              'stdout': result.stdout, 'stderr': result.stderr})
    save()
    assert result.returncode == 0, result.stdout + result.stderr
    return result.stdout

def git_blob(relative):
    result = subprocess.run(['git', '-C', str(REPO), 'show', 'ad0580a:' + relative], capture_output=True)
    assert result.returncode == 0, result.stderr
    return result.stdout

def citation(path, contains):
    for number, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if contains in line:
            return {'path': str(path.relative_to(REPO)), 'line': number, 'snippet': line.strip()}
    raise AssertionError((path, contains))

proof = {'reviewer_agent': report['actor'], 'role': 'architect', 'operations': [],
         'test_sha256': sha(test), 'semantic_report_sha256': sha(semantic_path),
         'unit_modes_report_sha256': sha(mode_path), 'commit_binding': 'ad0580a'}
assert hashlib.sha256(git_blob('tests/test_offline_rest_075.py')).hexdigest() == sha(test)
for reviewed in semantic['operations']:
    identity = reviewed['id']
    row, contract = rows[identity], contracts[identity]
    _, service, resource, method = identity.split('.')
    module = importlib.import_module('foundry_sdk.v2.' + service + '.' + re.sub(r'(?<!^)(?=[A-Z])', '_', resource).lower())
    source = Path(module.__file__)
    assert sha(source) == reviewed['source_sha256'] == row['source_sha256']
    client = getattr(module, resource + 'Client')
    fn = ast.parse(inspect.cleandoc(inspect.getsource(getattr(client, method)))).body[0]
    assert ast.dump(fn.args) == ast.dump(ast.parse('def f(' + contract['signature'] + '): pass').body[0].args)
    wire = next(node for node in ast.walk(fn) if isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute) and node.func.attr == 'RequestInfo')
    actual_wire = {kw.arg: kw.value for kw in wire.keywords}
    assert all(ast.dump(actual_wire[key]) == ast.dump(ast.parse(value, mode='eval').body) for key, value in contract['wire'].items())
    for kind in ('behavior', 'example', 'contract'):
        relative = reviewed[kind + '_path']
        assert sha(OWNER / relative) == reviewed[kind + '_sha256']
        relative_repo = str((OWNER / relative).relative_to(REPO)).replace('\\', '/')
        assert hashlib.sha256(git_blob(relative_repo)).hexdigest() == reviewed[kind + '_sha256']
    example = OWNER / row['example']
    behavior = OWNER / row['behavior']
    example_citation = citation(example, 'return client.with_raw_response.')
    signature_citation = citation(OWNER / contract['contract'], 'def ' + method + '(')
    behavior_citation = citation(behavior, '### ' + method)
    source_lines, source_start = inspect.getsourcelines(getattr(client, method))
    source_line = source_start + next(i for i, line in enumerate(source_lines) if 'def ' + method + '(' in line)
    proof['operations'].append({'id': identity, 'verdict': 'APPROVED',
        'source_path': str(source), 'source_line': source_line, 'source_sha256': sha(source),
        'example': example_citation, 'contract': signature_citation, 'behavior': behavior_citation,
        'semantic_disposition': reviewed['manual_semantic_review'],
        'signature_and_every_wire_expression': 'PASS'})

model_register_path = MAINT / 'rest-model-register.json'
matrix_path = MAINT / 'rest-model-semantic-matrix.json'
model_register = {row['id']: row for row in json.loads(model_register_path.read_bytes())['symbols']}
matrix = {row['id']: row for row in json.loads(matrix_path.read_bytes())['symbols']}
model_review = json.loads((MAINT / 'rest-model-independent-review.json').read_bytes())
assert model_review['register_sha256'] == sha(model_register_path)
assert model_review['matrix_sha256'] == sha(matrix_path)
approved_models = {row['id']: row for row in model_review['symbols']}
pending = list(set().union(*(set(contracts[identity]['symbols']) for identity in rows)))
seen = set()
sdk_base = Path(foundry_sdk.__file__).parent.parent
while pending:
    identity = pending.pop()
    if identity in seen:
        continue
    seen.add(identity)
    registered, mapped, approved = model_register[identity], matrix[identity], approved_models[identity]
    assert registered['semantic_review_status'] == 'accepted'
    assert mapped['source_fidelity_review'] == mapped['local_meaning_review'] == 'PASS'
    assert approved['source_fidelity_review'] == approved['local_meaning_review'] == 'PASS' and not approved['issues']
    assert sha(sdk_base / registered['source']) == registered['source_sha256'] == mapped['source_file_sha256']
    assert registered['definition_sha256'] == mapped['source_definition_sha256'] == approved['reviewed_source_definition_sha256']
    assert mapped['local_page_sha256'] == approved['reviewed_local_page_sha256']
    for relative, expected in zip(mapped['local_pages'], mapped['local_page_sha256']):
        assert sha(OWNER / relative) == expected
    pending.extend(registered['dependencies'])
proof['reachable_model_error_symbols_verified'] = len(seen)
proof['model_review_scope'] = 'Current byte continuity and full reachable dependency resolution against previously independent approved model/source meanings; no new core model semantic review claim.'
proof['unit_citations'] = [citation(test, value) for value in (
    'assert body.closed and body.chunks_read == 2',
    'assert not inspect.isawaitable(pending)',
    'assert calls == [None, "next-fixture"]',
    'assert isinstance(raised.value.__cause__, httpx.ReadTimeout)',
)]
PROOF.write_text(json.dumps(proof, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
report['source_review_sha256'] = sha(PROOF)
assert 'current_status: Open' in cli('get', 'CODEREVIEW-078', '--author', 'architect')
assert 'current_status: Resolved' in cli('get', 'DEV-077', '--author', 'architect')
assert 'current_status: Resolved' in cli('get', 'UNITTEST-077', '--author', 'architect')
links = cli('link', 'list', 'CODEREVIEW-078', '--author', 'architect')
assert 'LINK-02042' in links and 'LINK-01822' in links and 'LINK-01823' in links
assert 'Found 4 link(s)' in links and 'Question' not in links

intro = '''## Independent architect approval

Decision: APPROVE the current29-operation DEV-077 implementation and214-test UNITTEST-077 suite at committed source ad0580a. Reviewer /root/rest075_qa_20261028 authored neither implementation nor tests. DEV-077 and UNITTEST-077 were freshly verified Resolved before this approval.

Reviewed indexed FEATURE-015 REST authoring handoff and SA-DES-014 source/mode/verification requirements. All29 current example, behavior and structural contract bytes equal the independently accepted semantic report and committed source. Frozen installed SDK1.101 module hashes, exact AST signatures and every RequestInfo expression still match. Reachable model/error dependencies resolve locally and retain independent accepted source/meaning hashes. No unanswered Question link exists on this review.

Semantic evidence: feature015_rest075_semantic_retest_20261028.json SHA256 60b155a7eb9f862a477081a53c9ff49213cca6ab4e2c31e5b9549b4618a40dd1. Independent mode evidence: feature015_rest075_unit_modes_review_20261028.json SHA256 a52842ec84b69023a9c105daf00f83aaf3bee519e63cd7a692a8e03f5b57047d. Test SHA256 d81a04ec9b51a1e480f03570900509d02a293d60e79fba7cd9089b3310f72db3.214 independent tests and Ruff passed; no optional full rerun was needed because these bytes and all29 relevant SDK/asset bindings are unchanged.

The suite preserves86 semantic/raw/error checks, adds58 native/async-raw checks,48 tracked sync/async early-budget streaming checks across exactly24 applicable operations,8 finite-pagination checks across4 methods and14 timeout/cause/no-repeat checks across7 resources. Five void operations expose no streaming wrapper; no SSE operation exists in this partition. Actual AsyncResourceIterator returns are never falsely awaited. Windows local event-loop socket-pair initialization precedes per-test public-network denial and is disclosed.

The examples and tests retain small shared transport/assertion helpers and source-derived oracles. Fake tokens and isolated synthetic HTTP avoid credentials/live effects. Type-change error, upstream target preservation, found/omitted identity maps and illustrative UTC filter corrections are guarded by meaningful mutations. No unsupported server idempotency, permission, billing, filtering or completion guarantee is introduced. No new architecture/policy change requires a SAD revision.

Formal independently authored CASE/EXEC acceptance, the separate J12 reader gate and release publication remain pending gates; this is code review approval only.
'''
intro += '\nCurrent source/model continuity proof: ' + PROOF.name + ', SHA256 ' + sha(PROOF) + '; reachable symbols ' + str(len(seen)) + '.\n'
for item in proof['unit_citations']:
    intro += f"\n- `{item['path']}:{item['line']}`: `{item['snippet']}`\n"
cli('comment', 'create', 'CODEREVIEW-078', '--author', 'architect', '--subject',
    'Independent architect approval and current source/mode evidence', '--text', intro)
for start in (0, 15):
    body = '## Per-operation findings and dispositions\n\nPaths are relative to pal_found_cli_skills. Actual code snippets below were read at the cited current lines.\n'
    for operation in proof['operations'][start:start + 15]:
        body += '\n### ' + operation['id'] + ': APPROVED\n\n'
        for kind in ('example', 'contract', 'behavior'):
            item = operation[kind]
            body += f"- `{item['path']}:{item['line']}`: `{item['snippet']}`\n"
        body += '- Frozen SDK source `' + operation['source_path'] + ':' + str(operation['source_line']) + '`; AST signature and all RequestInfo wire expressions match.\n'
        body += '- Disposition: ' + operation['semantic_disposition'] + '\n'
    cli('comment', 'create', 'CODEREVIEW-078', '--author', 'architect', '--subject',
        'Exact operation review citations ' + str(start + 1) + '-' + str(min(start + 15, 29)), '--text', body)
cli('workflow', 'transitions', 'codereview', 'Open', '--author', 'architect')
cli('comment', 'create', 'CODEREVIEW-078', '--author', 'architect', '--subject',
    'Approval decision and precise review-blocker cleanup', '--text',
    'All findings are corrected and independently accepted at exact current bytes. Normal codereview Open→Closed is the valid approval transition; this type has no Resolved state. Remove only verified review Blocks LINK-02042 from CODEREVIEW-078 to DEV-077; preserve reciprocal RelatesTo LINK-01822/01823 and leave DEV/UNIT Resolved for their responsible developer and formal workflow handoffs. No source, other ticket, release acceptance or formal execution is changed by this approval.')
cli('link', 'remove', 'LINK-02042', '--author', 'architect')
after_links = cli('link', 'list', 'CODEREVIEW-078', '--author', 'architect')
assert 'LINK-02042' not in after_links and 'LINK-01822' in after_links and 'LINK-01823' in after_links
cli('update', 'CODEREVIEW-078', '--status', 'Closed', '--author', 'architect')
closed = cli('get', 'CODEREVIEW-078', '--author', 'architect')
assert 'current_status: Closed' in closed
(TMP / 'CODEREVIEW-078-closure-20261029.txt').write_text(closed, encoding='utf-8')
assert 'current_status: Resolved' in cli('get', 'DEV-077', '--author', 'architect')
assert 'current_status: Resolved' in cli('get', 'UNITTEST-077', '--author', 'architect')
report['writer_done'] = True
report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
save()
print(json.dumps({'CODEREVIEW-078': 'Closed', 'writer_done': True,
                  'closure_sha256': sha(OUT), 'source_review_sha256': sha(PROOF)}))
