"""Capture source bindings, executable fixtures and focused unit-test results."""
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import py_compile
import runpy
import socket
import subprocess
import sys
from time import perf_counter
from unittest.mock import patch

TMP = Path(__file__).resolve().parent
ROOT = TMP.parents[1]
REPO = TMP / 'feature015_integration'
OWNER = REPO / '.agents/skills/pal-found-dev'
OUT = TMP / 'rest075_author_validation_20261028.json'
report = {'author_agent': '/root/rest075_author_recover_20261028',
          'observed_at_utc': datetime.now(timezone.utc).isoformat(),
          'boundary': 'Author verification only. Separate source/semantic/unit review and formal TESTEXEC acceptance remain required. No tenant request or server scheduling/filter result is claimed.',
          'commands': [], 'operations': []}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
register = json.loads((REPO / 'maintainer/rest-domain-authoring-register.json').read_bytes())
oracle = json.loads((REPO / 'tests/fixtures/offline/rest-acceptance/source-oracle.json').read_bytes())
rows = [row for row in register['operations'] if row['story'] == 'DEV-STORY-075']
assert len(rows) == 29 and importlib.metadata.version('foundry-platform-sdk') == '1.101.0'

def deny(*args, **kwargs):
    raise AssertionError('Public network forbidden in REST075 author validation')

patches = [patch.object(socket.socket, name, deny) for name in ('connect', 'connect_ex')]
patches += [patch.object(socket, name, deny) for name in (
    'create_connection', 'getaddrinfo', 'gethostbyname', 'gethostbyname_ex')]
for patched in patches:
    patched.start()
try:
    for row in rows:
        _, service, resource, operation = row['id'].split('.')
        snake = ''.join(('_' if index else '') + char.lower() if char.isupper() else char
                        for index, char in enumerate(resource))
        module = importlib.import_module(f'foundry_sdk.v2.{service}.{snake}')
        source = Path(module.__file__)
        assert sha(source) == row['source_sha256'] == oracle['operations'][row['id']]['source_sha256']
        path = OWNER / row['example']
        namespace = runpy.run_path(str(path))
        started = perf_counter()
        namespace['verify']()
        report['operations'].append({'id': row['id'], 'verdict': 'PASS', 'source_path': str(source),
                                     'source_sha256': sha(source), 'example': row['example'],
                                     'example_sha256': sha(path), 'declared_errors': len(namespace['ERRORS']),
                                     'elapsed_seconds': perf_counter() - started})
finally:
    for patched in reversed(patches):
        patched.stop()

unit = REPO / 'tests/test_offline_rest_075.py'
owned = [OWNER / 'examples/rest/075/v2' / relative for relative in (
    'data_health/Check/replace.py', 'orchestration/Schedule/create.py',
    'orchestration/Schedule/replace.py', 'checkpoints/Record/get_batch.py',
    'orchestration/Build/get_batch.py', 'orchestration/Job/get_batch.py',
    'orchestration/Schedule/get_batch.py', 'orchestration/Build/search.py')]
owned.append(unit)
compiled = TMP / 'rest075_recover_compile_20261028'
compiled.mkdir(exist_ok=True)
for index, path in enumerate(owned):
    py_compile.compile(str(path), cfile=str(compiled / f'{index}.pyc'), doraise=True)
report['owned_files'] = [{'path': path.relative_to(REPO).as_posix(), 'sha256': sha(path)} for path in owned]
report['original_inventory'] = {'path': str(TMP / 'rest075_originals_20261028/manifest.json'),
                                'sha256': sha(TMP / 'rest075_originals_20261028/manifest.json')}
baseline = TMP / 'rest075_author_initial_pytest.log'
report['initial_test_result'] = {'path': str(baseline), 'sha256': sha(baseline),
                               'scope': 'Prior author draft against original eight examples: 20 failed,65 passed. Preserved verbatim; not all failures were independent product defects.'}
commands = [
    [sys.executable, '-m', 'pytest', str(unit), '-q', '--basetemp=' + str(TMP / 'rest075_author_report_basetemp_20261028'),
     '-o', 'cache_dir=' + str(TMP / 'rest075_recover_pytest_cache_20261028')],
    ['ruff', 'check', str(unit)],
    ['git', '-C', str(REPO), '-c', 'core.whitespace=cr-at-eol', 'diff', '--check', '--',
     *[str(path.relative_to(REPO)) for path in owned]],
]
for index, command in enumerate(commands):
    started = perf_counter()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, encoding='utf-8')
    report['commands'].append({'command': command, 'exit_code': result.returncode,
                               'elapsed_seconds': perf_counter() - started,
                               'stdout': result.stdout, 'stderr': result.stderr})
    OUT.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    assert result.returncode == 0, result.stdout + result.stderr
report['verdict'] = 'AUTHOR_VERIFICATION_PASS'
report['source_bound_operations'] = len(rows)
report['fixture_declared_error_cases'] = sum(row['declared_errors'] for row in report['operations'])
report['network_guard'] = 'socket connect/connect_ex and socket DNS helpers denied for all29 executable fixtures; dedicated suite also denies real HTTP transports.'
report['compile_result'] = 'All9 owned Python files compiled to explicitly assigned parent-temp paths.'
OUT.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report': str(OUT), 'sha256': sha(OUT), 'fixture_passes': len(rows),
                  'declared_errors': report['fixture_declared_error_cases'], 'unit_result': report['commands'][0]['stdout'].strip().splitlines()[-1]}))
