"""Record REST075 execution and close authorized subtasks through tracker CLI."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

TMP = Path(__file__).resolve().parent
ROOT = TMP.parent.parent
PYTHON = str(TMP / 'feature015_shared_cli_qa_env/Scripts/python.exe')
IDENTITY = '/root/rest075_execute_20261029'
LOG = TMP / 'rest075_executor_closure_cli_20261029.jsonl'
CANON = TMP / 'feature015_rest075_formal_qa.json'
TICKETS = ['DEV-STORY-075', 'DESIGN-077', 'DEV-077', 'UNITTEST-077',
           'CODEREVIEW-078', 'TESTCASE-077', 'TESTEXEC-077', 'BUG-SUB-025']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def cli(*args, author='qa-engineer'):
    command = [PYTHON, '.ept/tools/tracker/tracker_cli.py', *args, '--author', author]
    started = datetime.now(timezone.utc).isoformat()
    proc = subprocess.run(command, cwd=ROOT, capture_output=True, encoding='utf-8')
    row = dict(command=command, started_at=started, completed_at=datetime.now(timezone.utc).isoformat(),
               exit_code=proc.returncode, stdout=proc.stdout, stderr=proc.stderr)
    with LOG.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(row) + '\n')
    assert proc.returncode == 0, row
    return proc.stdout


def comments(ticket):
    listing = cli('comment', 'list', ticket)
    ids = re.findall(r'^\s*(\d{8}-\d{6}-\S+)\s+', listing, re.M)
    return dict(ticket=ticket, listing=listing,
                comments=[dict(comment_id=key, output=cli('comment', 'get', ticket, key)) for key in ids])


def current(ticket, expected):
    output = cli('get', ticket)
    assert f'current_status: {expected}\n' in output, output
    return output


def artifact(path):
    path = Path(path)
    return dict(path=str(path), sha256=sha(path), bytes=path.stat().st_size)


def record():
    assert not CANON.exists()
    result = json.loads((TMP / 'rest075_executor_20261029_attempt01_result.json').read_bytes())
    evidence = json.loads((TMP / 'rest075_executor_20261029_attempt01_execution.json').read_bytes())
    cases = json.loads((TMP / 'rest075_formal_cases.json').read_bytes())
    raw = [json.loads(line) for line in (TMP / 'rest075_executor_20261029_attempt01_checks.jsonl').read_text().splitlines()]
    assert raw == evidence['results'] and len(raw) == 1012
    assert result['execution'] == 'PASS' and result['exit_code'] == 0
    assert result['reconciled_operations'] == 29 and result['declared_errors_observed'] == 44
    assert all(sha(path) == value for path, value in result['bindings_after'].items())
    assert sha(TMP / 'rest075_formal_cases.json') == 'f7f7a19d1a34aa3ce3ff2816398c721cd29f458c3e76c38d5c52424c8aa85346'
    assert sha(TMP / 'rest075_formal_execute.py') == 'f5e876ca5ed6d1d0b479d1214a49ed0704ac1b08e7043ba37f03ce216171bc8d'
    assert sha(TMP / 'rest075_case_approval_20261029.json') == '39481fb5f8b8630024d21b145c35bba94160391656dc794261597e5599dac299'
    seconds = (datetime.fromisoformat(result['completed_at']) - datetime.fromisoformat(result['started_at'])).total_seconds()
    operations = []
    for op in result['reconciliation']:
        case = next(case for case in cases['operations'] if case['case_id'] == op['case_id'])
        rows = [row for row in raw if row['case_id'] == op['case_id']]
        operations.append(dict(**op, case_sha256=case['case_sha256'], available_modes=case['available_modes'],
                               recorded_checks=rows, result='PASS'))
    canonical = dict(story='DEV-STORY-075', testcase='TESTCASE-077', testexec='TESTEXEC-077',
                     executor=IDENTITY, case_author=cases['author_identity'],
                     case_reviewer='/root/rest075_cases_review_20261029', source_reviewer='/root/rest075_qa_20261028',
                     execution='PASS', formal_execution='PASS', formal_workflow_acceptance='Pending closure',
                     checks=1012, operations_count=29, declared_error_count=44, sdk_release='1.101.0',
                     source_commit='168d51910570b6966afa2320333ab36f6a3f7ccf',
                     cases_sha256=sha(TMP / 'rest075_formal_cases.json'), harness_sha256=sha(TMP / 'rest075_formal_execute.py'),
                     case_approval_sha256=sha(TMP / 'rest075_case_approval_20261029.json'),
                     readiness_sha256=sha(TMP / 'rest075_formal_readiness.json'),
                     source_asset_bindings_checked=83, immutable_bindings_checked=100,
                     all_bindings_current_and_unchanged=True, raw_log_equals_every_result_in_order=True,
                     actual_results=raw, operations=operations, formal_attempts=[result],
                     timing=dict(started_at=result['started_at'], completed_at=result['completed_at'],
                                 measured_formal_machine_seconds=seconds, measured_formal_machine_hours=seconds/3600,
                                 unmeasured_contributor_effort_hours=None,
                                 frontmatter_basis='Measured machine duration of successful formal attempt only; excludes unmeasured contributor effort, authoring, review and closure administration.'),
                     global_checks=result['global_checks'],
                     rejected_bundle=json.loads((TMP / 'rest075_formal_rejected01_manifest.json').read_bytes()),
                     fresh_case_review=json.loads((TMP / 'rest075_case_approval_20261029.json').read_bytes()),
                     evidence_inventory=artifact(TMP / 'rest075_executor_20261029_inventory.json'),
                     scope='29 operation REST075 partition, 44 source-declared errors, synthetic SDK HTTP fixtures; no additional execution during recording.',
                     limits=['No live tenant authorization, persistence, enrollment, deployment, idempotency or service default claim.',
                             'STARTED_TIME checks use separate synthetic server metadata, not Build.createdTime.',
                             'Integrated REST acceptance belongs to DEV-STORY-093 and release belongs to DEV-STORY-070.'])
    write(CANON, canonical)
    for op in operations:
        modes = op['available_modes']
        mode_text = ('Sync/async typed and raw PASS; sync/async stream PASS with response closure.'
                     if modes['sync_stream'] else
                     'Sync/async typed and raw PASS; sync/async streaming wrappers absent in frozen source, asserted absent with zero HTTP requests.')
        names = [row['check'] for row in op['recorded_checks']]
        text = (f"## Actual result: PASS\nExecutor `{IDENTITY}`; formal attempt 01. Operation `{op['operation']}`: {op['checks']} PASS checks.\n"
                f"\n{mode_text}\n\nAll {len(op['declared_errors'])} declared errors reconciled across six mode dispositions: `{json.dumps(op['declared_errors'])}`.\n"
                f"\nCase `{op['case_id']}` SHA256 `{op['case_sha256']}`. Checks: `{json.dumps(names)}`.\n"
                f"\nRaw `.ept/tmp/rest075_executor_20261029_attempt01_checks.jsonl` SHA256 `{sha(TMP / 'rest075_executor_20261029_attempt01_checks.jsonl')}`. "
                f"Result `.ept/tmp/rest075_executor_20261029_attempt01_result.json` SHA256 `{sha(TMP / 'rest075_executor_20261029_attempt01_result.json')}`.\n"
                f"\nApproved cases `{canonical['cases_sha256']}`; harness `{canonical['harness_sha256']}`; fresh review `{canonical['case_approval_sha256']}`. "
                "Exact requests, inputs, responses, errors and source/asset bindings are preserved in these artifacts and approved cases.\n"
                "\nSynthetic offline SDK execution; no live tenant or persisted service-state claim.")
        cli('comment', 'create', 'TESTEXEC-077', '--subject', f"{op['case_id']} actual PASS {op['operation']}", '--text', text)
    text = (f"## Formal execution and DoD evidence\n29/29 operations, 44/44 declared errors and all 1012 checks PASS; process exit 0, stderr empty. "
            f"Actual interval `{result['started_at']}` through `{result['completed_at']}`. SDK 1.101.0 in `.ept/tmp/feature015_shared_cli_qa_env/Scripts/python.exe`, fake credential and HTTP MockTransport; seven public socket/DNS traps actively probed.\n"
            f"\nMachine runtime {seconds!r} seconds ({seconds/3600!r} hours) only is recorded in frontmatter. Contributor effort, authoring, review and closure administration remain unmeasured and excluded.\n"
            "\nAll 29 operation comments above record actual outcomes; raw1012 checks exactly equal execution results in order. 24 streaming methods exercised and five source-absent methods recorded zero requests. All 100 immutable hashes, including 83 source/assets and initial rejected bundle, unchanged. Finite pages, seven-second timeout with zero retry, malformed results, required arguments, closure, byte/chunk budgets, denied preflight before mutation and 12-step synthetic lifecycle PASS. STARTED_TIME uses independent synthetic server metadata.\n"
            f"\nCanonical `.ept/tmp/feature015_rest075_formal_qa.json` preclosure SHA256 `{sha(CANON)}`. Raw result SHA256 `d5b305470480e606f395719eefbe625e4f4b3f0b298a0924be7dbaef35cdb369`; executor inventory SHA256 `96a62f3af983e29f560320edb4b49e5559c4e3c7b07b49c5d2b7af2c312e019c`.\n"
            "\nInitial rejected cases SHA256 `28012f9ef63a5a6f3fdb60da3a99f2cc05e40851b265ae9f946d15816c20828b` and harness SHA256 `ee6c63a9946d81c9ce63699b83a861d1419bdc4a8af597870761c8f0dded3ab7` retained. Their static review found unconditional invocation of absent streaming wrappers; separate author correction and fresh review preceded the sole formal SDK attempt.\n"
            "\nExecutor, case author, case reviewer and source reviewer are independent as recorded in canonical evidence. Documentation index, authoring contract, ticket instructions and transitions reviewed. Required parent links exist, no active blocker or Question is linked. No new candidate defect found; BUG-SUB-025 already Closed remains untouched. No rerun during recording. Integrated acceptance093 and publication070 remain separate gates.")
    cli('comment', 'create', 'TESTEXEC-077', '--subject', 'Independent formal PASS evidence, provenance and measured runtime', '--text', text)
    cli('update', 'TESTEXEC-077', '--field', f'time_spent_hours={seconds/3600!r}')
    print(json.dumps(dict(recorded_operations=29, measured_seconds=seconds, canonical_sha256=sha(CANON))))


def main():
    phase = sys.argv[1]
    if phase == 'preflight':
        for ticket in TICKETS:
            print(ticket, re.search(r'current_status: (.+)', cli('get', ticket)).group(1))
            cli('link', 'list', ticket)
        cli('list', '--parent', 'DEV-STORY-075')
        for kind in ['testexec', 'development', 'unittest']:
            cli('type-info', kind)
            cli('workflow', 'status', kind)
        for ticket in ['DEV-077', 'UNITTEST-077', 'CODEREVIEW-078', 'TESTCASE-077', 'TESTEXEC-077']:
            write(TMP / f'rest075_executor_{ticket}_preclosure_comments_20261029.json', comments(ticket))
    elif phase == 'record':
        record()
    elif phase == 'resolve':
        current('TESTEXEC-077', 'In Progress')
        cli('workflow', 'transitions', 'testexec', 'In Progress')
        print(cli('update', 'TESTEXEC-077', '--status', 'Resolved'))
    elif phase == 'close':
        current('CODEREVIEW-078', 'Closed')
        for ticket, kind, actor in [('DEV-077', 'development', 'python-developer'),
                                    ('UNITTEST-077', 'unittest', 'python-developer'),
                                    ('TESTEXEC-077', 'testexec', 'qa-engineer')]:
            current(ticket, 'Resolved')
            links = cli('link', 'list', ticket)
            assert 'Blocks' not in links and 'Question' not in links, links
            cli('workflow', 'transitions', kind, 'Resolved', author=actor)
            cli('comment', 'create', ticket, '--subject', 'Closure verification after independent REST075 formal PASS',
                '--text', '## Closure evidence\nCODEREVIEW-078 is Closed; no active blocker remains. Independent TESTEXEC-077 formal attempt01 passed all 29 operations, 44 declared errors and 1012 checks. Source/asset bindings unchanged. Canonical `.ept/tmp/feature015_rest075_formal_qa.json` links exact approved cases/harness, independent reviews, retained rejected bundle and raw outcomes. No additional execution occurred. Existing DEV/UNIT measured frontmatter time preserved; QA frontmatter records measured formal machine runtime only, with contributor effort unmeasured. BUG-SUB-025, CASE077 and CR078 remain Closed and untouched. No live tenant or publication claim.', author=actor)
            print(cli('update', ticket, '--status', 'Closed', author=actor).split('Ticket Details:')[0])
        print(cli('get', 'DEV-STORY-075').split('Ticket Details:')[0])
    elif phase == 'export':
        exports = {}
        for ticket in TICKETS:
            output = cli('get', ticket)
            status = re.search(r'current_status: (.+)', output).group(1)
            path = TMP / f'rest075_executor_{ticket}_closure_20261029.txt'
            path.write_text(output, encoding='utf-8')
            cpath = TMP / f'rest075_executor_{ticket}_comments_20261029.json'
            write(cpath, comments(ticket))
            exports[ticket] = dict(status=status, export=artifact(path), comments=artifact(cpath))
            print(ticket, status)
        canonical = json.loads(CANON.read_bytes())
        assert exports['DEV-STORY-075']['status'] == 'Deployment'
        assert all(value['status'] == 'Closed' for ticket, value in exports.items() if ticket != 'DEV-STORY-075')
        canonical.update(formal_workflow_acceptance='Closed', closure_exports=exports,
                         story_status='Deployment', publication='Not performed; DEV-STORY-070 owns release',
                         closure_cli=artifact(LOG),
                         source_review=artifact(TMP / 'feature015_rest075_architect_source_review_20261029.json'),
                         architect_closure=artifact(TMP / 'feature015_rest075_architect_closure_20261029.json'),
                         staging_workflow=artifact(TMP / 'rest075_stage_workflow_transcript_20261029.json'))
        write(CANON, canonical)
    elif phase == 'archive':
        canonical = json.loads(CANON.read_bytes())
        assert canonical['formal_workflow_acceptance'] == 'Closed'
        canonical.update(source_review=artifact(TMP / 'feature015_rest075_architect_source_review_20261029.json'),
                         architect_closure=artifact(TMP / 'feature015_rest075_architect_closure_20261029.json'),
                         staging_workflow=artifact(TMP / 'rest075_stage_workflow_transcript_20261029.json'))
        write(CANON, canonical)
        files = {p.resolve() for pattern in ['rest075*', 'feature015_rest075*'] for p in TMP.glob(pattern) if p.is_file()}
        files.add(CANON.resolve())
        result = json.loads((TMP / 'rest075_executor_20261029_attempt01_result.json').read_bytes())
        files.update(Path(path).resolve() for path in result['bindings_after'])
        for path in TMP.glob('feature015_rest075*'):
            if path.is_file():
                files.add(path.resolve())
        for path in (TMP / 'rest075_originals_20261028').rglob('*'):
            if path.is_file():
                files.add(path.resolve())
        archive = TMP / 'feature015_rest075_formal_qa_archive_20261029.zip'
        inventory_path = TMP / 'feature015_rest075_formal_qa_inventory.json'
        files.discard(archive.resolve())
        files.discard(inventory_path.resolve())
        inventory = dict(story='DEV-STORY-075', execution='PASS', artifacts={str(p):artifact(p) for p in sorted(files)},
                         canonical_sha256=sha(CANON), inventory_self_excluded=True, archive_self_excluded=True)
        write(inventory_path, inventory)
        files.add(inventory_path.resolve())
        assert not archive.exists()
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
            for path in sorted(files):
                try:
                    target = 'workspace/' + path.relative_to(ROOT).as_posix()
                except ValueError:
                    target = 'external/' + path.as_posix().replace(':', '')
                bundle.write(path, target)
        with zipfile.ZipFile(archive) as bundle:
            assert bundle.testzip() is None
        print(json.dumps(dict(canonical=artifact(CANON), inventory=artifact(inventory_path), archive=artifact(archive), artifacts=len(files)), indent=2))
    else:
        raise ValueError(phase)


if __name__ == '__main__':
    main()
