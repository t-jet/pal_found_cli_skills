"""Bind prepared formal cases to source, assets and observed workflow state."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

TMP = Path(__file__).resolve().parent
WORKSPACE = TMP.parents[1]
REPO = TMP / 'feature015_integration'
OWNER = REPO / '.agents/skills/pal-found-dev'
CLI = WORKSPACE / '.ept/tools/tracker/tracker_cli.py'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest_path = TMP / 'rest087_formal_cases.json'
manifest = json.loads(manifest_path.read_bytes())
bindings = {}
for row in manifest['operations']:
    bindings[row['source']['path']] = row['source']['sha256']
    for value in row['assets'].values():
        bindings[str(OWNER / value['path'])] = value['sha256']
    for error in row['errors']:
        bindings[error['error_source']] = error['error_source_sha256']
    if row.get('direct_rest_adapter'):
        bindings[str(OWNER / row['direct_rest_adapter']['path'])] = row['direct_rest_adapter']['sha256']
for path, expected in bindings.items():
    assert sha(path) == expected, path
commands = []
for ticket in ('DEV-STORY-087', 'DESIGN-069', 'DEV-069', 'UNITTEST-068', 'CODEREVIEW-069', 'TESTCASE-068', 'TESTEXEC-068', 'BUG-SUB-023'):
    args = [sys.executable, str(CLI), 'get', ticket, '--author', 'qa-engineer']
    result = subprocess.run(args, cwd=WORKSPACE, capture_output=True, encoding='utf-8',
                            env=dict(os.environ, PYTHONIOENCODING='utf-8'))
    commands.append({'args': args, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0, result.stderr
report = {'story': 'DEV-STORY-087', 'case_author': manifest['author_identity'],
          'created_at_utc': datetime.now(timezone.utc).isoformat(), 'sdk_release': importlib.metadata.version('foundry-platform-sdk'),
          'operations': len(manifest['operations']), 'declared_errors': sum(len(r['errors']) for r in manifest['operations']),
          'cases_sha256': sha(manifest_path), 'harness_sha256': sha(TMP / 'rest087_formal_execute.py'),
          'source_asset_bindings': bindings, 'unique_bindings': len(bindings), 'commands': commands,
          'preparation_state': 'Source-derived literals and static preflight ready; independent review and real execution still required.',
          'execution': 'NOT_RUN', 'approval': 'PENDING_INDEPENDENT_REVIEW',
          'workflow_gaps': ['DEV-069 and UNITTEST-068 must reach developer handoff and separate code review approval.',
                            'TESTCASE-068 must close after fresh independent review of exact cases and harness.',
                            'A fresh executor distinct from the case author and case reviewer must execute after actual TESTEXEC-068 readiness.',
                            'Dedicated tests/test_offline_rest_087.py currently has 30 tests concentrated on the bridge and corrected examples; make all47 operation coverage explicit before UNITTEST handoff.'],
          'formal_coverage': ['Every source-declared named error has a typed literal and matching request.',
                              'Ordinary sync/async iterator semantics, raw/stream cleanup, finite continuation, timeout/no retry and malformed JSON scenarios.',
                              'Native SDK integer-path failure remains separate from typed bounded direct-REST adapter tests.',
                              'J14 isolated selected-agent/session conversation and denied-access stop before mutation.'],
          'scope_limits': ['Static preparation only; this author has not run SDK operations or candidate example invoke/verify.',
                           'Synthetic responses cannot prove tenant access, real inference, scheduling, billing or persisted server lifecycle effects.']}
out = TMP / 'rest087_formal_readiness.json'
out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'operations': report['operations'], 'errors': report['declared_errors'], 'bindings': len(bindings),
                  'readiness_sha256': sha(out), 'cases_sha256': report['cases_sha256'], 'harness_sha256': report['harness_sha256']}))
