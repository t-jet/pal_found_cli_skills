"""Check the CPU literal correction without executing SDK operations."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

TMP = Path(__file__).resolve().parent
SNAPSHOT = TMP / 'rest087_formal_runtime_snapshot_20261029'
spec = importlib.util.spec_from_file_location('rest087_static_harness', TMP / 'rest087_formal_execute.py')
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
old = json.loads((SNAPSHOT / 'rest087_formal_cases.json').read_bytes())
new = json.loads((TMP / 'rest087_formal_cases.json').read_bytes())
changes = []


def compare(before, after, trail=()):
    assert type(before) is type(after) or (before == '1' and after == 1.0), trail
    if isinstance(before, dict):
        assert before.keys() == after.keys(), trail
        for key in before:
            compare(before[key], after[key], (*trail, key))
    elif isinstance(before, list):
        assert len(before) == len(after), trail
        for index, (left, right) in enumerate(zip(before, after)):
            compare(left, right, (*trail, index))
    elif before != after:
        changes.append(trail)
        assert trail[:1] == ('operations',) and trail[1] in (23, 26), trail
        assert trail[-1] == 'case_sha256' or (
            trail[-2] in ('runtime_configuration', 'runtimeConfiguration')
            and trail[-1] == 'cpu' and before == '1' and type(after) is float and after == 1.0
        ), trail


compare(old, new)
assert len(changes) == 25
assert (SNAPSHOT / 'rest087_formal_execute.py').read_bytes() == (TMP / 'rest087_formal_execute.py').read_bytes()
rejected = 0
for index in (23, 26):
    previous, corrected = old['operations'][index], new['operations'][index]
    try:
        harness.semantic_check(previous, previous['request']['kwargs'], harness.expected_decoded(previous, previous['success']), 'regression')
    except AssertionError:
        rejected += 1
    else:
        raise AssertionError('Original CPU mismatch no longer reproduced')
    value = harness.expected_decoded(corrected, corrected['success'])
    harness.semantic_check(corrected, corrected['request']['kwargs'], value, 'regression')
    for field, invalid in [('cpu', 2.0), ('memory', '4Gi'), ('threadCount', 2), ('minReplicas', 2), ('maxReplicas', 3)]:
        mutated = copy.deepcopy(value)
        mutated['runtimeConfiguration'][field] = invalid
        try:
            harness.semantic_check(corrected, corrected['request']['kwargs'], mutated, 'regression')
        except AssertionError:
            rejected += 1
        else:
            raise AssertionError(f'Meaningful {field} mismatch accepted')
for case in new['operations']:
    row = copy.deepcopy(case)
    expected = row.pop('case_sha256')
    assert expected == hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    harness.semantic_check(case, case['request']['kwargs'], harness.expected_decoded(case, case['success']), 'static_only')
print(json.dumps({'changed_cpu_literals': 23, 'changed_case_hashes': 2,
                  'original_and_mutated_mismatches_rejected': rejected,
                  'static_semantic_cases': 47, 'sdk_operations_invoked': 0}))
