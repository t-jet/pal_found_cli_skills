"""Inspect frozen SDK request and response definitions without invoking clients."""
import ast
import importlib
import json
from pathlib import Path
import re
import pydantic

ROOT = Path(__file__).resolve().parent / 'feature015_integration'
domain = json.loads((ROOT / 'maintainer/rest-domain-authoring-register.json').read_bytes())
result = []
for row in domain['operations']:
    if row['story'] != 'DEV-STORY-087':
        continue
    version, service, resource, operation = row['id'].split('.')
    module = importlib.import_module('foundry_sdk.' + version + '.' + service + '.' + re.sub(r'(?<!^)(?=[A-Z])', '_', resource).lower())
    tree = ast.parse(Path(module.__file__).read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == resource + 'Client')
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == operation)
    request = next(n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'RequestInfo')
    expressions = {kw.arg: ast.unparse(kw.value) for kw in request.keywords}
    response = eval(expressions['response_type'], vars(module))
    arguments = {}
    for arg in [*fn.args.args, *fn.args.kwonlyargs]:
        if arg.arg in ('self', '_sdk_internal', 'request_timeout'):
            continue
        arguments[arg.arg] = pydantic.TypeAdapter(eval(ast.unparse(arg.annotation), vars(module))).json_schema()
    result.append({'operation': row['id'], 'docstring': ast.get_docstring(fn), 'wire': expressions,
                   'arguments': arguments, 'response_schema': pydantic.TypeAdapter(response).json_schema()})
out = Path(__file__).with_name('rest087_formal_discovery.json')
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
for row in result:
    schema = row['response_schema']
    print(row['operation'], 'ARGS', ','.join(row['arguments']), 'RESULT', schema.get('required', schema.get('anyOf', schema.get('type'))))
