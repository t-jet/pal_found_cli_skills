"""Validate prepared case literals against frozen SDK types without HTTP calls."""
import copy
import hashlib
import importlib
import inspect
import json
from pathlib import Path
import typing
import pydantic

TMP = Path(__file__).resolve().parent
manifest_path = TMP / 'rest087_formal_cases.json'
manifest = json.loads(manifest_path.read_bytes())
errors = []
checks = []


def related_literals(case):
    kwargs = case['request']['kwargs']
    if case['operation'] in ('v2.models.LiveDeployment.create', 'v2.models.LiveDeployment.replace'):
        configuration = kwargs['runtime_configuration']
        assert type(configuration['cpu']) in (int, float), 'Runtime CPU literal must match SDK numeric field'
        from foundry_sdk.v2.models.models import LiveDeploymentRuntimeConfiguration
        decoded = LiveDeploymentRuntimeConfiguration.model_validate(case['success']['json']['runtimeConfiguration'])
        assert decoded.model_dump(by_alias=True, exclude_unset=True) == configuration
    if case['operation'] == 'v2.aip_agents.AgentVersion.list':
        pages = next(extra for extra in case['additional_cases'] if extra['name'] == 'finite continuation')['responses']
        versions = [(item['version']['major'], item['version']['minor'])
                    for page in pages for item in page['data']]
        assert versions == sorted(versions, reverse=True)
        assert len(set(versions)) == len(versions)
    if case['operation'] == 'v2.models.Experiment.get':
        assert case['success']['json']['rid'] == kwargs['experiment_rid']
        assert case['success']['json']['modelRid'] == kwargs['model_rid']
    for error in case['errors']:
        request, params = error['request'], error['parameters']
        aliases = {'artifactName': 'experiment_artifact_table_name',
                   'seriesName': 'experiment_series_name', 'studioRid': 'model_studio_rid',
                   'ontologyRid': 'ontology_binding'}
        for field, argument in aliases.items():
            if field in params and request.get(argument) is not None:
                assert params[field] == request[argument], (error['name'], field)
        if error['name'] == 'ModelNotFound' and isinstance(request.get('deployment_type'), dict):
            assert params['modelRid'] == request['deployment_type']['modelRid']
        if error['name'] == 'ModelStudioConfigVersionNotFound' and 'config_version' in request:
            assert request['config_version'] is not None
            assert params['configVersion'] == request['config_version']
        if error['name'] in ('InvalidDisplayName', 'ResourceNameAlreadyExists'):
            assert params['displayName'] == request['name']
        if error['name'] == 'InvalidDisplayName':
            name = request['name']
            assert name in ('.', '..') or '/' in name or len(name) > 700
        if error['name'] == 'InvalidParameter':
            assert params['parameter'] in request['parameter_inputs']
        assert params == error['envelope']['parameters'] == error['expected']['parameters']


for case in manifest['operations']:
    module = importlib.import_module(case['source']['module'])
    resource, method = case['operation'].split('.')[-2:]
    hints = typing.get_type_hints(getattr(getattr(module, resource + 'Client'), method))
    try:
        related_literals(case)
        for key, value in case['request']['kwargs'].items():
            pydantic.TypeAdapter(hints[key]).validate_python(value)
        response_type = eval(case['source']['request_expressions']['response_type'], vars(module))
        if 'content_hex' not in case['success']:
            pydantic.TypeAdapter(response_type).validate_python(case['success']['json'])
        for error in case['errors']:
            for key, value in error['request'].items():
                pydantic.TypeAdapter(hints[key]).validate_python(value)
            error_module, name = error['expected']['exception_class'].rsplit('.', 1)
            error_class = getattr(importlib.import_module(error_module), name)
            pydantic.TypeAdapter(typing.get_type_hints(error_class)['parameters']).validate_python(error['parameters'])
        for extra in case['additional_cases']:
            if 'expected_exception' in extra:
                continue
            for kwargs in extra.get('requests', [extra['request']] if 'request' in extra else []):
                for key, value in kwargs.items():
                    pydantic.TypeAdapter(hints[key]).validate_python(value)
            for reply in extra.get('responses', [extra['response']] if 'response' in extra else []):
                if response_type is not bytes:
                    pydantic.TypeAdapter(response_type).validate_python(reply)
        checks.append({'operation': case['operation'], 'verdict': 'PASS'})
    except Exception as error:
        errors.append({'operation': case['operation'], 'error': str(error)})
output = {'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
          'operations': len(manifest['operations']), 'errors': errors, 'checks': checks,
          'execution': 'No SDK operation or example invocation; static type validation only.'}
(TMP / 'rest087_formal_static_validation.json').write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'passed': len(checks), 'failed': len(errors), 'errors': errors}, indent=2))
