"""Adapt reviewed transport mechanisms; retain independent REST087 literal oracles."""
import hashlib
from pathlib import Path

TMP = Path(__file__).resolve().parent
prior = TMP / 'rest071_formal_execute.py'
code = prior.read_text(encoding='utf-8').replace('071', '087').replace('TESTCASE-074', 'TESTCASE-068')
code = code.replace("assert len(manifest['operations']) == 27", "assert len(manifest['operations']) == 47")
begin = code.index('def semantic_check(')
end = code.index('\ndef materialize(', begin)
semantic = '''def semantic_check(case, kwargs, value, label):
    if not isinstance(value, dict):
        return
    name, method = case['operation'].split('.')[-2:]
    if name == 'Agent' and method == 'get':
        assert value['rid'] == kwargs['agent_rid']
        if kwargs.get('version'):
            assert value['version'] == kwargs['version']
    if name == 'Experiment' and method == 'get':
        assert value['rid'] == kwargs['experiment_rid']
        assert value['modelRid'] == kwargs['model_rid']
    if name == 'AgentVersion':
        values = value.get('data', [value])
        for version in values:
            assert version['string'] == str(version['version']['major']) + '.' + str(version['version']['minor'])
    if name == 'Session' and method in ('create', 'get'):
        assert value['agentRid'] == kwargs['agent_rid']
        if 'session_rid' in kwargs:
            assert value['rid'] == kwargs['session_rid']
        if kwargs.get('agent_version'):
            assert value['agentVersion'] == kwargs['agent_version']
    if name == 'Model' and method == 'promote_version':
        assert value['rid'] != kwargs['source_model_version_rid']
        assert value['rid'] != kwargs['model_rid']
    if name == 'LiveDeployment' and method in ('create', 'replace'):
        assert value['runtimeConfiguration'] == kwargs['runtime_configuration']
    if name == 'OpenAiModel':
        assert len(value['data']) == len(kwargs['input'])
        assert value['model'] == kwargs['open_ai_model_model_id']
    if name == 'ModelStudioConfigVersion' and 'version' in value:
        if 'model_studio_config_version_version' in kwargs:
            assert value['version'] == kwargs['model_studio_config_version_version']
    if name == 'ModelStudioTrainer' and method == 'get':
        assert value['trainerId'] == kwargs['model_studio_trainer_trainer_id']
        if kwargs.get('version'):
            assert value['version'] == kwargs['version']

'''
code = code[:begin] + semantic + code[end:]
bridge = '''def bridge_case(case, module, cls, method):
    import runpy
    calls = []
    def forbidden(request):
        calls.append(request)
        raise AssertionError('Native integer-path request unexpectedly reached HTTP')
    for raw in (False, True):
        with resource(cls, forbidden) as (client, _):
            try:
                invoke(client, method, case['request']['kwargs'], raw)
            except TypeError as error:
                assert 'quote_from_bytes() expected bytes' in str(error)
            else:
                raise AssertionError('Native integer-path limitation disappeared')
        assert calls == []
        record(case['case_id'], 'native_raw_integer_path_denied' if raw else 'native_sync_integer_path_denied', requests=0)
    async def async_native():
        for raw in (False, True):
            async with async_resource(getattr(module, 'Async' + cls.__name__), forbidden) as (client, _):
                try:
                    await invoke(client, method, case['request']['kwargs'], raw)
                except TypeError as error:
                    assert 'quote_from_bytes() expected bytes' in str(error)
                else:
                    raise AssertionError('Native async integer-path limitation disappeared')
            assert calls == []
            record(case['case_id'], 'native_async_raw_integer_path_denied' if raw else 'native_async_integer_path_denied', requests=0)
    EVENT_LOOP.run_until_complete(async_native())
    adapter_path = SKILL / case['direct_rest_adapter']['path']
    assert digest(adapter_path) == case['direct_rest_adapter']['sha256']
    function = runpy.run_path(str(adapter_path))['get_config_version']
    options = copy.deepcopy(case['direct_rest_adapter']['kwargs'])
    responses = []
    def run_bridge(reply, options_override=None, expected_exception=None, expected_named=None):
        requests = []
        def handler(request):
            wire_check(request, case['request']['expected_wire'])
            requests.append(request)
            returned = response(reply)
            responses.append(returned)
            return returned
        with httpx.Client(transport=httpx.MockTransport(handler)) as http:
            selected = dict(options, **(options_override or {}))
            try:
                result = function(http, **selected)
            except Exception as error:
                assert expected_exception and isinstance(error, expected_exception), repr(error)
                if expected_named:
                    assert type(error) is expected_named
                return error
            else:
                assert expected_exception is None, 'Bridge accepted adverse response'
                assert normalized(result) == expected_decoded(case, reply)
                assert len(requests) == 1
                return result
            finally:
                assert all(r.is_closed for r in responses)
    run_bridge(case['success'])
    record(case['case_id'], 'direct_rest_typed_success_closed', requests=1)
    for declared in case['errors']:
        error_module, error_name = declared['expected']['exception_class'].rsplit('.', 1)
        named = getattr(importlib.import_module(error_module), error_name)
        failure = run_bridge({'http_status': declared['status'], 'json': declared['envelope']}, expected_exception=PalantirRPCException, expected_named=named)
        assert normalized(failure.parameters) == normalized(declared['parameters'])
        record(case['case_id'], 'direct_rest_error_' + error_name, requests=1)
    run_bridge({'http_status': 403, 'json': {'errorName': 'IndependentDenied087', 'errorCode': 'PERMISSION_DENIED',
        'errorInstanceId': '00000000-0000-0000-0000-000000000087', 'parameters': {}}}, expected_exception=PalantirRPCException)
    record(case['case_id'], 'direct_rest_unknown_permission_error', requests=1)
    run_bridge(case['success'], {'max_bytes': 1}, RuntimeError)
    record(case['case_id'], 'direct_rest_byte_budget', requests=1)
    class Chunks(httpx.SyncByteStream):
        def __iter__(self):
            yield b'{' 
            yield b'"name":'
            yield b'"not-consumed"}'
    with httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(200, stream=Chunks()))) as http:
        try:
            function(http, **dict(options, max_chunks=1))
        except RuntimeError as error:
            assert 'budget' in str(error)
        else:
            raise AssertionError('Bridge chunk budget not enforced')
    record(case['case_id'], 'direct_rest_chunk_budget')
    with httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(200, content=b'{invalid'))) as http:
        try:
            function(http, **options)
        except pydantic.ValidationError:
            pass
        else:
            raise AssertionError('Bridge accepted malformed JSON')
    record(case['case_id'], 'direct_rest_malformed_json')
    for invalid in (True, '2'):
        with httpx.Client(transport=httpx.MockTransport(forbidden)) as http:
            try:
                function(http, **dict(options, version=invalid))
            except TypeError:
                pass
            else:
                raise AssertionError('Bridge accepted wrong version type')
        assert calls == []
        record(case['case_id'], 'direct_rest_invalid_version_' + type(invalid).__name__, requests=0)


'''
code = code.replace('def execute(manifest):', bridge + 'def execute(manifest):')
journey = '''def journey_j14(manifest):
    by_id = {case['operation']: case for case in manifest['operations']}
    plan = manifest['journeys'][0]
    state = {'session': False, 'continued': False, 'renamed': False, 'deleted': False}
    seen = []
    continuation = by_id['v2.aip_agents.Session.blocking_continue']
    for operation in plan['sequence']:
        case = copy.deepcopy(by_id[operation])
        name, method = operation.split('.')[-2:]
        if name == 'Content':
            case['success']['json'] = {'exchanges': [{'userInput': copy.deepcopy(continuation['request']['kwargs']['user_input']),
                'result': copy.deepcopy(continuation['success']['json'])}]}
        if name == 'Session' and method == 'get':
            case['success']['json']['metadata']['title'] = by_id['v2.aip_agents.Session.update_title']['request']['kwargs']['title']
        module = importlib.import_module(case['source']['module'])
        cls = getattr(module, name + 'Client')
        def handler(request):
            assert len(seen) < len(plan['sequence']), 'Journey exceeded its request budget'
            wire_check(request, case['request']['expected_wire'])
            if name == 'Session' and method == 'create':
                assert not state['session'] and not state['deleted']
                state['session'] = True
            elif name == 'Session' and method == 'blocking_continue':
                assert state['session'] and not state['continued']
                state['continued'] = True
            elif name in ('Content', 'SessionTrace'):
                assert state['continued']
            elif name == 'Session' and method == 'update_title':
                assert state['session']
                state['renamed'] = True
            elif name == 'Session' and method == 'get':
                assert state['renamed']
            elif name == 'Session' and method == 'delete':
                assert state['session'] and not state['deleted']
                state['deleted'] = True
            seen.append(operation)
            return response(case['success'])
        with resource(cls, handler) as (client, _):
            result = invoke(client, method, case['request']['kwargs'])
            assert normalized(result) == expected_decoded(case, case['success'])
            semantic_check(case, case['request']['kwargs'], normalized(result), 'J14')
        record('J14', operation, state=copy.deepcopy(state))
    assert seen == plan['sequence'] and state['deleted']
    agent_case = by_id['v2.aip_agents.Agent.get']
    module = importlib.import_module(agent_case['source']['module'])
    failure(agent_case, getattr(module, 'AgentClient'), 'get', 403, 'IndependentDenied087',
        'PERMISSION_DENIED', {})
    record('J14', 'permission_denial_stops_before_mutation', requests=1, session_mutations=0)


'''
code = code.replace('def execute(manifest):', journey + 'def execute(manifest):')
code = code.replace("    for case in manifest['operations']:\n        module = importlib.import_module(case['source']['module'])", "    journey_j14(manifest)\n    for case in manifest['operations']:\n        module = importlib.import_module(case['source']['module'])", 1)
needle = "        name, method = case['operation'].split('.')[-2:]\n        cls = getattr(module, name + 'Client')\n"
assert code.count(needle) == 1
code = code.replace(needle, needle + "        if case.get('native_sdk_limitation'):\n            bridge_case(case, module, cls, method)\n            continue\n")
code = code.replace("    assert args.testcase_closed == 'TESTCASE-068',", "    assert args.executor_identity != manifest.get('reviewer_identity'), 'Executor must differ from case reviewer'\n    assert args.testcase_closed == 'TESTCASE-068',")
out = TMP / 'rest087_formal_execute.py'
out.write_text(code, encoding='utf-8')
print({'harness_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
       'transport_mechanism_baseline': str(prior), 'baseline_sha256': hashlib.sha256(prior.read_bytes()).hexdigest(),
       'execution': 'NOT_RUN'})
