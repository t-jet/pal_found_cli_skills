"""Record formal evidence and close authorized REST087 QA tickets via tracker CLI."""
import argparse
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

TMP = Path(__file__).resolve().parent
LOG = TMP / 'rest087_executor_closure_cli_20261029.jsonl'
PYTHON = str(TMP / 'feature015_shared_cli_qa_env/Scripts/python.exe')
IDENTITY = '/root/rest087_executor_recover_20261029'
PREFIXES = [
    'rest087_executor_recover_20261029_20261028T231111547638Z',
    'rest087_executor_attempt2_20261029_20261028T231809401476Z',
    'rest087_executor_attempt3_20261029_20261029T084800037921Z',
]
CANON = TMP / 'feature015_rest087_formal_qa.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def cli(*args, author='qa-engineer'):
    command = [PYTHON, '.ept/tools/tracker/tracker_cli.py', *args, '--author', author]
    result = subprocess.run(command, capture_output=True, encoding='utf-8')
    entry = dict(command=command, exit_code=result.returncode, stdout=result.stdout,
                 stderr=result.stderr, recorded_at_utc=datetime.now(timezone.utc).isoformat())
    with LOG.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(entry) + '\n')
    assert result.returncode == 0, entry
    return result.stdout


def comments(ticket):
    listing = cli('comment', 'list', ticket)
    ids = re.findall(r'^\s*(\d{8}-\d{6}-\S+)\s+', listing, re.M)
    rows = [dict(comment_id=key, output=cli('comment', 'get', ticket, key)) for key in ids]
    return dict(ticket=ticket, listing=listing, comments=rows)


def main():
    phase = argparse.ArgumentParser()
    phase.add_argument('phase', choices=['preflight', 'record', 'resolve', 'close', 'export'])
    args = phase.parse_args()
    if args.phase == 'preflight':
        for ticket in ['DEV-STORY-087', 'DEV-069', 'UNITTEST-068', 'CODEREVIEW-069', 'TESTCASE-068', 'TESTEXEC-068', 'BUG-SUB-023']:
            value = cli('get', ticket)
            print(ticket, re.search(r'current_status: (.+)', value).group(1))
            print(cli('link', 'list', ticket, '--direction', 'all'))
        print(cli('list', '--parent', 'DEV-STORY-087'))
        for ticket in ['DEV-069', 'UNITTEST-068', 'CODEREVIEW-069']:
            write_new(TMP / (f'rest087_executor_{ticket}_preclosure_comments_20261029.json'), comments(ticket))
        for kind in ['testexec', 'development', 'unittest']:
            cli('type-info', kind)
            cli('workflow', 'status', kind)
        print('Preflight retained in', LOG)
    elif args.phase == 'record':
        reconciliation = json.loads((TMP / (PREFIXES[-1] + '_reconciliation.json')).read_text())
        evidence = json.loads((TMP / (PREFIXES[-1] + '_results.json')).read_text())
        manifest = json.loads((TMP / 'rest087_formal_cases.json').read_text())
        attempts = [json.loads((TMP / (prefix + '_outcome.json')).read_text()) for prefix in PREFIXES]
        raw = [json.loads(line) for line in (TMP / (PREFIXES[-1] + '_checks.jsonl')).read_text().splitlines()]
        assert raw == evidence['results'] and len(raw) == 894
        assert reconciliation['counts']['declared_errors_verified'] == 171
        assert all(sha(path) == value for path, value in reconciliation['current_bindings'].items())
        assert all(sha(TMP / name) == value for name, value in reconciliation['approved_artifact_hashes'].items())
        inventory = {}
        for prefix in PREFIXES:
            for path in TMP.glob(prefix + '*'):
                if path.is_file():
                    inventory[str(path)] = sha(path)
        for name in reconciliation['approved_artifact_hashes']:
            inventory[str(TMP / name)] = sha(TMP / name)
        for pattern in ['rest087_executor*.py', 'rest087_formal_runtime_snapshot_20261029/*', 'rest087_integer_runtime_snapshot_20261029/*']:
            for path in TMP.glob(pattern):
                if path.is_file():
                    inventory[str(path)] = sha(path)
        result = dict(story='DEV-STORY-087', testcase='TESTCASE-068', testexec='TESTEXEC-068',
                      recorder_identity=IDENTITY, executor=IDENTITY, execution='PASS',
                      formal_execution='PASS', formal_workflow_acceptance='Pending closure',
                      recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                      checks=894, operations_count=47, declared_error_count=171,
                      cases_sha256=sha(TMP / 'rest087_formal_cases.json'),
                      harness_sha256=sha(TMP / 'rest087_formal_execute.py'),
                      case_approval_sha256=sha(TMP / 'rest087_integer_independent_review_clean_20261029.json'),
                      case_author=manifest['author_identity'],
                      fresh_review=json.loads((TMP / 'rest087_integer_independent_review_clean_20261029.json').read_text()),
                      source_asset_bindings_checked=132, all_bindings_current_and_unchanged=True,
                      raw_log_equals_every_result_in_order=True, no_new_execution_during_recording=True,
                      observed_runs=attempts,
                      timing=dict(successful_attempt_seconds=attempts[-1]['duration_seconds'],
                                  failed_attempts_seconds=sum(a['duration_seconds'] for a in attempts[:-1]),
                                  total_measured_formal_seconds=sum(a['duration_seconds'] for a in attempts),
                                  unmeasured_contributor_effort_hours=None,
                                  frontmatter_basis='Total measured machine execution duration of three formal attempts only; excludes unmeasured contributor effort and recorder administration.'),
                      operations=reconciliation['operations'], actual_results=evidence['results'],
                      reconciliation=reconciliation, inventory=inventory, limits=reconciliation['limits'])
        write_new(CANON, result)
        write_new(TMP / 'feature015_rest087_formal_qa_preclosure_inventory.json', inventory)
        for op in result['operations']:
            case = next(c for c in manifest['operations'] if c['case_id'] == op['case_id'])
            actual = [row for row in raw if row['case_id'] == op['case_id']]
            text = (f"## Actual result: PASS\nExecutor `{IDENTITY}`. Attempt 3 recorded {len(actual)} PASS checks for `{op['operation']}` and all {len(op['declared_errors'])} source-declared errors.\n"
                    f"\nRaw results: `.ept/tmp/{PREFIXES[-1]}_results.json`, SHA256 `{sha(TMP / (PREFIXES[-1] + '_results.json'))}`. "
                    f"Checks JSONL: `.ept/tmp/{PREFIXES[-1]}_checks.jsonl`, SHA256 `{sha(TMP / (PREFIXES[-1] + '_checks.jsonl'))}`.\n"
                    f"\nApproved case `{op['case_id']}`, checksum `{case['case_sha256']}`. Manifest `{result['cases_sha256']}`; harness `{result['harness_sha256']}`; clean independent review `{result['case_approval_sha256']}`.\n"
                    f"\nRecorded checks: `{json.dumps(op['recorded_checks'])}`.\n"
                    f"\nDeclared error reconciliation: `{json.dumps(op['declared_errors'])}`.\n"
                    "\nSynthetic offline HTTP evidence; no tenant authorization, inference, server effect, or deployment claim.")
            cli('comment', 'create', 'TESTEXEC-068', '--subject', f"{op['case_id']} actual PASS {op['operation']}", '--text', text)
        timing = result['timing']
        text = (f"## Independent formal execution complete\nAll 47 operations and 171 source-declared errors passed, with 894 raw PASS records. "
                f"All 132 source/asset bindings match; raw JSONL equals results in order. Executor `{IDENTITY}` differs from case author, correction author and both reviewers.\n"
                f"\nAttempt 3 measured {timing['successful_attempt_seconds']!r} seconds. Preserved failed attempts measured {timing['failed_attempts_seconds']!r} seconds combined. "
                f"Total measured formal machine runtime {timing['total_measured_formal_seconds']!r} seconds ({timing['total_measured_formal_seconds']/3600!r} hours) is recorded in frontmatter. "
                "This excludes unmeasured contributor effort, authoring, review and recorder administration.\n"
                f"\nCanonical evidence `.ept/tmp/feature015_rest087_formal_qa.json`; preclosure snapshot SHA256 `{sha(CANON)}`. "
                f"Reconciliation `.ept/tmp/{PREFIXES[-1]}_reconciliation.json`, SHA256 `{sha(TMP / (PREFIXES[-1] + '_reconciliation.json'))}`.\n"
                "\nJ14 nine synthetic journey steps and denial before mutation passed. F087-39 native sync/raw SDKInternalError has direct TypeError cause; async/raw TypeError is separate; all fail before HTTP. "
                "Bounded direct REST typed success, named errors, unknown denial, size/chunk/malformed/invalid-version checks passed separately.\n"
                "\nBoth earlier failures were oracle defects, retained as immutable attempts; separate author corrections and fresh approvals preceded each rerun. No candidate defect found. Existing BUG-SUB-023 remains Closed. "
                "Documentation index, authoring handoff, ticket instructions and actual workflows reviewed; no linked active Question or blocker. The 47 preceding comments record individual actual outcomes. "
                "Final integrated REST acceptance 093 and release 070 remain separate gates. Parent story should advance only through its automatic workflow.")
        cli('comment', 'create', 'TESTEXEC-068', '--subject', 'Independent formal PASS evidence and measured machine runtime', '--text', text)
        cli('update', 'TESTEXEC-068', '--field', f"time_spent_hours={timing['total_measured_formal_seconds']/3600!r}")
        print(json.dumps(dict(canonical=str(CANON), sha256=sha(CANON), comments=48, timing=timing)))
    elif args.phase == 'resolve':
        cli('workflow', 'transitions', 'testexec', 'In Progress')
        print(cli('update', 'TESTEXEC-068', '--status', 'Resolved'))
    elif args.phase == 'close':
        for ticket, kind, author in [('DEV-069', 'development', 'python-developer'), ('UNITTEST-068', 'unittest', 'python-developer'), ('TESTEXEC-068', 'testexec', 'qa-engineer')]:
            print(cli('get', ticket, author=author).split('Ticket Details:')[0])
            print(cli('link', 'list', ticket, '--direction', 'all', author=author))
            cli('workflow', 'transitions', kind, 'Resolved', author=author)
            cli('comment', 'create', ticket, '--subject', 'Closure verification after independent REST087 formal PASS',
                '--text', '## Closure evidence\nCODEREVIEW-069 is Closed and no active blocker remains. Independent TESTEXEC-068 attempt 3 passed all 47 operations, 171 source-declared errors and 894 checks; all 132 source/asset bindings remain unchanged. Unit author/reviewer evidence is retained; no additional test run occurred. Canonical evidence `.ept/tmp/feature015_rest087_formal_qa.json` and immutable raw attempts are retained. Existing measured frontmatter time on DEV/UNIT is preserved. No source or publication change is claimed.', author=author)
            print(cli('update', ticket, '--status', 'Closed', author=author).split('Ticket Details:')[0])
    elif args.phase == 'export':
        for ticket in ['DEV-STORY-087', 'DESIGN-069', 'DEV-069', 'UNITTEST-068', 'CODEREVIEW-069', 'TESTCASE-068', 'TESTEXEC-068', 'BUG-SUB-023']:
            output = cli('get', ticket)
            target = TMP / f'rest087_executor_{ticket}_closure_20261029.txt'
            with target.open('x', encoding='utf-8') as stream:
                stream.write(output)
            write_new(TMP / f'rest087_executor_{ticket}_comments_20261029.json', comments(ticket))
            print(ticket, re.search(r'current_status: (.+)', output).group(1))


if __name__ == '__main__':
    main()
