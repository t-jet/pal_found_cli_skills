"""Run the reviewed harness once, retaining every attempt and its provenance."""
import argparse
import contextlib
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

TMP = Path(__file__).resolve().parent
IDENTITY = '/root/rest087_executor_recover_20261029'
APPROVED = {
    'rest087_formal_cases.json': '002ac59e66559aec4774cd217c8cd37fd7bb5280f50673f3a0d5e574d0642f3c',
    'rest087_formal_execute.py': '789dff9e390d08fc209fe1a90921911a649821f1fed3fc42679b25efa409d1fb',
    'rest087_fresh_review_cases_20261028.json': '3450e7c120ceb83b9a60ac50a109422447d983e1bafd3208a02e598134120196',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root-confirmation', required=True)
    parser.add_argument('--workflow-confirmation', required=True)
    args = parser.parse_args()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    prefix = TMP / ('rest087_executor_recover_20261029_' + stamp)
    reservation = prefix.with_suffix('.reserved')
    with reservation.open('x', encoding='utf-8') as stream:
        stream.write(IDENTITY + '\n')
    started = time.perf_counter()
    outcome = {
        'executor_identity': IDENTITY,
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'command': [sys.executable, *sys.argv],
        'root_confirmation': args.root_confirmation,
        'workflow_confirmation': args.workflow_confirmation,
        'runner_sha256': sha(__file__),
        'original_runner_sha256': '4d6f8c8546e7958af7722c8618b0e71fc20c4d92b29ab47e96113a168922e222',
        'output_prefix': str(prefix),
        'execution': 'FAIL',
        'gate_commands': [],
    }
    exit_code = 1
    try:
        actual = {name: sha(TMP / name) for name in APPROVED}
        outcome['approved_artifact_hashes'] = actual
        assert actual == APPROVED, 'Approved artifacts changed'
        review = json.loads((TMP / 'rest087_fresh_review_cases_20261028.json').read_text())
        manifest = json.loads((TMP / 'rest087_formal_cases.json').read_text())
        assert review['verdict'] == 'APPROVED'
        assert review['case_author_identity'] == manifest['author_identity']
        assert len({IDENTITY, review['reviewer_identity'], manifest['author_identity']}) == 3
        assert review['cases_sha256'] == actual['rest087_formal_cases.json']
        assert review['harness_sha256'] == actual['rest087_formal_execute.py']
        bindings = {path: sha(path) for path in review['bindings']}
        assert bindings == review['bindings'], 'Source or asset binding changed'
        assert len(bindings) == 132
        outcome['bindings'] = bindings
        outcome['counts'] = review['counts']
        inventory = Path(str(prefix) + '_inventory.json')
        with inventory.open('x', encoding='utf-8') as stream:
            json.dump({'executor_identity': IDENTITY, 'bindings': bindings,
                       'counts': review['counts'], 'approved_artifact_hashes': actual}, stream, indent=2)
            stream.write('\n')
        for ticket, status in [('TESTCASE-068', 'Closed'), ('TESTEXEC-068', 'In Progress'),
                               ('DEV-069', 'Resolved'), ('UNITTEST-068', 'Resolved'),
                               ('CODEREVIEW-069', 'Closed')]:
            command = [sys.executable, '.ept/tools/tracker/tracker_cli.py', 'get', ticket, '--author', 'qa-engineer']
            result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
            outcome['gate_commands'].append(dict(command=command, exit_code=result.returncode,
                                                 stdout=result.stdout, stderr=result.stderr))
            assert result.returncode == 0, ticket
            assert ('current_status: ' + status + '\n') in result.stdout, ticket + ' gate mismatch'
        spec = importlib.util.spec_from_file_location('rest087_approved_execution', TMP / 'rest087_formal_execute.py')
        harness = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(harness)
        harness.PENDING = Path(str(prefix) + '_results.json')
        harness.LOG = Path(str(prefix) + '_checks.jsonl')
        sys.argv = [str(TMP / 'rest087_formal_execute.py'), '--execute', '--executor-identity', IDENTITY,
                    '--testcase-closed', 'TESTCASE-068', '--approved-cases-sha256', APPROVED['rest087_formal_cases.json'],
                    '--readiness-confirmed']
        outcome['harness_arguments'] = list(sys.argv)
        with Path(str(prefix) + '_stdout.log').open('x', encoding='utf-8') as stdout, \
             Path(str(prefix) + '_stderr.log').open('x', encoding='utf-8') as stderr, \
             contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                harness.main()
            except BaseException:
                traceback.print_exc()
                raise
        assert {name: sha(TMP / name) for name in APPROVED} == APPROVED
        assert {path: sha(path) for path in bindings} == bindings
        evidence = json.loads(harness.PENDING.read_text())
        assert evidence['execution'] == 'PASS'
        rows = evidence['results']
        coverage = []
        for case in manifest['operations']:
            checks = [row['check'] for row in rows if row['case_id'] == case['case_id']]
            declared = [('direct_rest_error_' if case.get('native_sdk_limitation') else 'error_') + error['name']
                        for error in case['errors']]
            assert checks and all(check in checks for check in declared), case['operation']
            coverage.append(dict(operation=case['operation'], case_id=case['case_id'],
                                 check_count=len(checks), declared_errors=len(declared)))
        outcome['operation_coverage'] = coverage
        outcome['declared_errors_verified'] = sum(row['declared_errors'] for row in coverage)
        outcome['execution'] = 'PASS'
        outcome['recorded_checks'] = len(evidence['results'])
        exit_code = 0
    except BaseException as error:
        outcome['failure'] = repr(error)
        outcome['traceback'] = traceback.format_exc()
    finally:
        outcome['exit_code'] = exit_code
        outcome['duration_seconds'] = time.perf_counter() - started
        outcome['completed_at_utc'] = datetime.now(timezone.utc).isoformat()
        outcome['artifact_sha256'] = {str(path): sha(path) for path in TMP.glob(prefix.name + '*') if path.is_file()}
        report = Path(str(prefix) + '_outcome.json')
        with report.open('x', encoding='utf-8') as stream:
            json.dump(outcome, stream, indent=2)
            stream.write('\n')
        print(json.dumps({'outcome': str(report), 'sha256': sha(report), 'execution': outcome['execution'],
                          'exit_code': exit_code, 'duration_seconds': outcome['duration_seconds']}))
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
