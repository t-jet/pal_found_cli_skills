"""Reconcile preserved formal evidence without invoking SDK operations."""
import hashlib
import importlib.metadata
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

TMP = Path(__file__).resolve().parent
PREFIX = TMP / 'rest087_executor_attempt2_20261029_20261028T231809401476Z'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    outcome = json.loads(Path(str(PREFIX) + '_outcome.json').read_text())
    evidence = json.loads(Path(str(PREFIX) + '_results.json').read_text())
    manifest = json.loads((TMP / 'rest087_formal_cases.json').read_text())
    review = json.loads((TMP / 'rest087_runtime_independent_review_20261029.json').read_text())
    rows = evidence['results']
    operations = []
    for case in manifest['operations']:
        checks = [row['check'] for row in rows if row['case_id'] == case['case_id']]
        error_prefix = 'direct_rest_error_' if case.get('native_sdk_limitation') else 'error_'
        errors = [dict(name=error['name'], expected_check=error_prefix + error['name'],
                       recorded_pass=(error_prefix + error['name']) in checks)
                  for error in case['errors']]
        status = 'CHECKS_RECORDED' if checks else 'NOT_REACHED'
        if case['case_id'] == 'F087-39':
            status = 'FAIL_BEFORE_FIRST_PASS_RECORD'
        operations.append(dict(case_id=case['case_id'], operation=case['operation'],
                               status=status, recorded_checks=checks, declared_errors=errors,
                               native_sdk_limitation=case.get('native_sdk_limitation')))
    bindings = {path: sha(path) for path in review['bindings']}
    approved_unchanged = all(sha(TMP / name) == value
                             for name, value in outcome['approved_artifact_hashes'].items())
    raw_artifacts = {str(path): sha(path) for path in TMP.glob(PREFIX.name + '*')
                     if path.is_file() and not path.name.endswith('_reconciliation.json')}
    declared = sum(len(op['declared_errors']) for op in operations)
    verified = sum(error['recorded_pass'] for op in operations for error in op['declared_errors'])
    report = dict(
        executor_identity=outcome['executor_identity'], execution='FAIL',
        generated_at_utc=datetime.now(timezone.utc).isoformat(),
        started_at_utc=outcome['started_at_utc'], completed_at_utc=outcome['completed_at_utc'],
        duration_seconds=outcome['duration_seconds'], exit_code=outcome['exit_code'],
        environment=dict(python=sys.executable, python_version=platform.python_version(),
                         foundry_sdk=importlib.metadata.version('foundry-platform-sdk')),
        runner_sha256=outcome['runner_sha256'],
        original_runner_sha256=outcome['original_runner_sha256'],
        approved_artifact_hashes=outcome['approved_artifact_hashes'],
        approved_artifacts_unchanged=approved_unchanged,
        current_bindings=bindings, bindings_unchanged=bindings == review['bindings'],
        raw_artifact_sha256=raw_artifacts,
        raw_artifact_hashes_match_outcome=all(sha(path) == value
                                            for path, value in outcome['artifact_sha256'].items()),
        gate_exit_codes=[row['exit_code'] for row in outcome['gate_commands']],
        counts=dict(operations=len(operations), operations_with_recorded_checks=sum(
                    bool(op['recorded_checks']) for op in operations),
                    failed_operation=1, operations_not_reached=sum(
                    op['status'] == 'NOT_REACHED' for op in operations),
                    declared_errors=declared, declared_errors_verified=verified,
                    declared_errors_not_reached=declared - verified, recorded_pass_checks=len(rows)),
        failure=dict(case_id='F087-39', operation='v2.models.ModelStudioConfigVersion.get',
                     location='rest087_formal_execute.py:367',
                     actual_exception=outcome['failure'],
                     native_sdk_limitation=manifest['operations'][38]['native_sdk_limitation'],
                     traceback=outcome['traceback']),
        j14_checks=[row for row in rows if row['case_id'] == 'J14'],
        socket_denial_checks=[row for row in rows if row['case_id'] == 'REST087'],
        operations=operations,
        limits=[
            'Execution stopped at F087-39; remaining operations and their errors were not executed.',
            'J14 records synthetic local HTTP state and denial behavior, without tenant or inference claims.',
            'F087-39 native SDK call raised SDKInternalError wrapping TypeError before the harness recorded its native limitation; direct REST bridge was not reached.',
            'No harness, manifest, source asset, or expected outcome was changed after failure.',
            'A separate author and fresh reviewer must approve any correction before another formal attempt.',
        ])
    target = Path(str(PREFIX) + '_reconciliation.json')
    with target.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(report=str(target), sha256=sha(target), counts=report['counts'],
                          bindings_unchanged=report['bindings_unchanged'],
                          approved_artifacts_unchanged=approved_unchanged)))


if __name__ == '__main__':
    main()
