"""Finalize read-only closure exports and package the formal QA evidence."""
import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

TMP = Path(__file__).resolve().parent
ROOT = TMP.parent.parent
CANON = TMP / 'feature015_rest087_formal_qa.json'
TICKETS = ['DEV-STORY-087', 'DESIGN-069', 'DEV-069', 'UNITTEST-068', 'CODEREVIEW-069', 'TESTCASE-068', 'TESTEXEC-068', 'BUG-SUB-023']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    result = json.loads(CANON.read_text())
    before = TMP / 'feature015_rest087_formal_qa_preclosure.json'
    with before.open('xb') as stream:
        stream.write(CANON.read_bytes())
    closure = {}
    exports = []
    for ticket in TICKETS:
        path = TMP / f'rest087_executor_{ticket}_closure_20261029.txt'
        comments = TMP / f'rest087_executor_{ticket}_comments_20261029.json'
        status = re.search(r'current_status: (.+)', path.read_text()).group(1).strip()
        assert status == ('Deployment' if ticket == 'DEV-STORY-087' else 'Closed'), (ticket, status)
        value = json.loads(comments.read_text())
        if ticket == 'TESTEXEC-068':
            actual = [row for row in value['comments'] if 'subject         : F087-' in row['output'] and 'actual PASS' in row['output']]
            assert len(actual) == 47
        closure[ticket] = dict(path=str(path), sha256=sha(path), status=status)
        exports.append(dict(path=str(comments), sha256=sha(comments), comments=len(value['comments'])))
    log = TMP / 'rest087_executor_closure_cli_20261029.jsonl'
    commands = [json.loads(line) for line in log.read_text().splitlines()]
    assert commands and all(row['exit_code'] == 0 for row in commands)
    raw = result['actual_results']
    result.update(formal_workflow_acceptance='PASS', closure=closure, full_comment_exports=exports,
                  closure_cli=dict(path=str(log), sha256=sha(log), commands=len(commands), all_exit_codes_zero=True),
                  testcase_status='Closed', testexec_status='Closed', story_status='Deployment',
                  archive_inventory=dict(path=str(TMP / 'feature015_rest087_formal_qa_inventory.json')),
                  evidence_archive=dict(path=str(TMP / 'feature015_rest087_formal_qa_archive_20261029.zip')),
                  canonical_preclosure_sha256=sha(before),
                  unique_case_check_pairs=len({(r['case_id'], r['check']) for r in raw}),
                  unique_case_check_status_triples=len({(r['case_id'], r['check'], r.get('status')) for r in raw}),
                  finalized_at_utc=datetime.now(timezone.utc).isoformat(),
                  writer_released=True, source_or_acceptance_ledger_changes=False,
                  no_final_story_or_release_transition=True)
    assert all(sha(path) == value for path, value in result['reconciliation']['current_bindings'].items())
    assert all(sha(path) == value for path, value in result['inventory'].items())
    with CANON.open('w', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    paths = {Path(path).resolve() for path in result['inventory']}
    paths.update(Path(row['path']).resolve() for row in exports)
    paths.update(Path(row['path']).resolve() for row in closure.values())
    paths.update([CANON, before, log, Path(__file__), TMP / 'rest087_executor_close_20261029.py',
                  TMP / 'feature015_rest087_formal_qa_preclosure_inventory.json'])
    for path in TMP.glob('rest087_executor_*preclosure_comments_20261029.json'):
        paths.add(path)
    for name in ['rest087_fresh_review_cases_20261028.json', 'rest087_runtime_independent_review_20261029.json', 'rest087_integer_independent_review_clean_20261029.json']:
        review = json.loads((TMP / name).read_text())
        snapshot = Path(review.get('snapshot_path', ''))
        if snapshot.is_dir() and snapshot.is_relative_to(TMP):
            paths.update(path for path in snapshot.rglob('*') if path.is_file())
    # Include the exact bound inputs so archived evidence remains inspectable.
    paths.update(Path(path) for path in result['reconciliation']['current_bindings'])
    inventory = []
    for path in sorted(paths, key=str):
        if path.is_relative_to(ROOT):
            archive_name = str(path.relative_to(ROOT)).replace('\\', '/')
        else:
            archive_name = 'external_bound_inputs/' + sha(path) + '/' + path.name
        inventory.append(dict(path=str(path), archive_name=archive_name, sha256=sha(path), bytes=path.stat().st_size))
    inv = TMP / 'feature015_rest087_formal_qa_inventory.json'
    write_new(inv, dict(story='DEV-STORY-087', execution='PASS', recorder_identity=result['recorder_identity'],
                        canonical_sha256=sha(CANON), files=inventory,
                        prior_failure_prefixes=[row['output_prefix'] for row in result['observed_runs'][:2]],
                        limit='File hashes and archived bytes preserve the approved offline execution evidence; no live platform result is asserted.'))
    archive = TMP / 'feature015_rest087_formal_qa_archive_20261029.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
        for item in inventory:
            assert sha(item['path']) == item['sha256']
            zipped.write(item['path'], item['archive_name'])
        zipped.write(inv, '.ept/tmp/' + inv.name)
    receipt = dict(canonical=dict(path=str(CANON), sha256=sha(CANON)),
                   inventory=dict(path=str(inv), sha256=sha(inv), files=len(inventory)),
                   archive=dict(path=str(archive), sha256=sha(archive), bytes=archive.stat().st_size),
                   closure={ticket: row['status'] for ticket, row in closure.items()},
                   all_cli_exit_codes_zero=True, commands=len(commands))
    write_new(TMP / 'rest087_executor_final_receipt_20261029.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
