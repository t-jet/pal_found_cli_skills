"""v2.aip_agents.Session.blocking_continue: SDK request, decoded result and declared error fixtures.

Synthetic identifiers do not name tenant resources. Prepared SDK 1.101.0/httpx
required. No network connections or live mutations occur.
"""
import json
import sys
import urllib.parse
import datetime
from pathlib import Path

import httpx
from foundry_sdk import PalantirRPCException
from foundry_sdk.v2.aip_agents.session import SessionClient

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / 'common'))
from mock_transport import mock_resource

EXPECTED_METHOD = 'POST'
EXPECTED_PATH = '/api/v2/aipAgents/agents/ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001/sessions/ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001/blockingContinue'
EXPECTED_BODY = {'userInput': {'text': 'synthetic-value'}, 'parameterInputs': {}}
EXPECTED_QUERY = {'preview': None}
EXPECTED_HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}
SUCCESS = {'agentMarkdownResponse': 'synthetic-value',
 'parameterUpdates': {},
 'interruptedOutput': True,
 'sessionTraceId': '00000000-0000-0000-0000-000000000001'}
ERRORS = [{'name': 'ActionTypeNotFound',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'actionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001'}},
 {'name': 'AgentIterationsExceededLimit',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'details': 'synthetic-value'}},
 {'name': 'AgentNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001'}},
 {'name': 'BlockingContinueSessionPermissionDenied',
  'status': 403,
  'code': 'PERMISSION_DENIED',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001'}},
 {'name': 'ContextSizeExceededLimit',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'details': 'synthetic-value'}},
 {'name': 'FunctionLocatorNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'functionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'functionVersion': 'synthetic-value'}},
 {'name': 'InvalidParameter',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'parameter': 'synthetic-value'}},
 {'name': 'InvalidParameterType',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'parameter': 'synthetic-value',
                 'expectedType': 'string',
                 'receivedType': 'integer'}},
 {'name': 'ObjectTypeIdsNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'objectTypeIds': ['synthetic-value']}},
 {'name': 'ObjectTypeRidsNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'objectTypeRids': ['ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001']}},
 {'name': 'OntologyEntitiesNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'objectTypeRids': ['ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001'],
                 'linkTypeRids': ['ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001']}},
 {'name': 'RateLimitExceeded',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'details': 'synthetic-value'}},
 {'name': 'RetryAttemptsExceeded',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'details': 'synthetic-value'}},
 {'name': 'RetryDeadlineExceeded',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'details': 'synthetic-value'}},
 {'name': 'SessionExecutionFailed',
  'status': 500,
  'code': 'INTERNAL',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'message': 'synthetic-value',
                 'details': 'synthetic-value'}},
 {'name': 'SessionNotFound',
  'status': 404,
  'code': 'NOT_FOUND',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001'}},
 {'name': 'SessionTraceIdAlreadyExists',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'sessionTraceId': '00000000-0000-0000-0000-000000000001'}},
 {'name': 'UnsupportedLanguageModelRid',
  'status': 400,
  'code': 'INVALID_ARGUMENT',
  'parameters': {'agentRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'languageModelRid': 'ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001',
                 'modelPurpose': 'PRIMARY_AGENT'}}]

def invoke(client):
    return client.with_raw_response.blocking_continue(agent_rid='ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001', session_rid='ri.synthetic.main.resource.00000000-0000-0000-0000-000000000001', parameter_inputs={}, user_input={'text': 'synthetic-value'}, request_timeout=30)

def check_request(request):
    assert request.method == EXPECTED_METHOD
    assert urllib.parse.unquote(request.url.path) == EXPECTED_PATH
    assert request.headers['Authorization'] == 'Bearer offline-fixture-token'
    for key, value in EXPECTED_HEADERS.items():
        if value is None:
            assert key not in request.headers
        else:
            assert request.headers[key] == str(value)
    expected = httpx.QueryParams({key: value for key,value in EXPECTED_QUERY.items() if value is not None})
    assert sorted(request.url.params.multi_items()) == sorted(expected.multi_items())
    if isinstance(EXPECTED_BODY, bytes):
        assert request.content == EXPECTED_BODY
    elif EXPECTED_BODY is not None:
        assert json.loads(request.content) == EXPECTED_BODY

def normalized(value):
    if isinstance(value, dict):
        return {key: normalized(child) for key,child in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalized(child) for child in value]
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.isoformat()
    if isinstance(value, bytes):
        return bytes(value)
    if hasattr(value, 'model_dump'):
        return value.model_dump(mode='json', by_alias=True, exclude_none=True)
    return value

def verify():
    calls = []
    def success(request):
        check_request(request)
        calls.append(True)
        if isinstance(SUCCESS, bytes):
            return httpx.Response(200, content=SUCCESS)
        if SUCCESS is None:
            return httpx.Response(204)
        return httpx.Response(200, json=SUCCESS)
    with mock_resource(SessionClient, success) as client:
        raw = invoke(client)
        try:
            assert normalized(raw.decode()) == SUCCESS
        finally:
            raw.close()
    assert len(calls) == 1
    for error_case in ERRORS:
        def failure(request):
            check_request(request)
            return httpx.Response(error_case['status'], json={
                'errorName':error_case['name'], 'errorCode':error_case['code'],
                'parameters':error_case['parameters'],
                'errorInstanceId':'00000000-0000-0000-0000-000000000004',
            })
        with mock_resource(SessionClient, failure) as client:
            try:
                raw = invoke(client)
                raw.close()
            except PalantirRPCException as error:
                assert error.name == error_case['name']
                assert type(error).__name__ == error_case['name']
                assert normalized(error.parameters) == error_case['parameters']
            else:
                raise AssertionError('Expected ' + error_case['name'])

if __name__ == '__main__':
    verify()
    print('v2.aip_agents.Session.blocking_continue' + ': serialized request, decoded result and ' + str(len(ERRORS)) + ' named errors passed')
