"""Prepare source-derived REST087 literals without reading example constants."""
import ast
import copy
from datetime import datetime, timezone
import hashlib
import importlib
import inspect
import json
from pathlib import Path
import re
import subprocess
import typing
import pydantic

TMP = Path(__file__).resolve().parent
REPO = TMP / 'feature015_integration'
OWNER = REPO / '.agents/skills/pal-found-dev'
AUTHOR = '/root/rest087_cases_correct_20261028'
UUID = '00000000-0000-0000-0000-000000000087'
STAMP = '2026-10-28T08:00:00Z'
RID = lambda name: 'ri.qa.main.' + name.replace('_', '-') + '.independent087'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sample(node, root=None, name='', depth=0):
    root = node if root is None else root
    if '$ref' in node:
        return sample(root['$defs'][node['$ref'].split('/')[-1]], root, name, depth + 1)
    if 'const' in node:
        return node['const']
    if 'enum' in node:
        return node['enum'][0]
    for key in ('anyOf', 'oneOf'):
        if key in node:
            choices = [v for v in node[key] if v.get('type') != 'null']
            if not choices:
                return None
            return sample(choices[0], root, name, depth + 1)
    kind = node.get('type')
    if kind == 'object':
        if node.get('properties'):
            return {k: sample(v, root, k, depth + 1) for k, v in node['properties'].items()
                    if k in node.get('required', []) or 'const' in v}
        if isinstance(node.get('additionalProperties'), dict) and depth < 10:
            return {'independent087': sample(node['additionalProperties'], root, name, depth + 1)}
        return {}
    if kind == 'array':
        return [sample(node.get('items', {}), root, name, depth + 1)] if depth < 12 else []
    if kind == 'integer':
        return max(node.get('minimum', 1), 1)
    if kind == 'number':
        return 0.5
    if kind == 'boolean':
        return True
    if kind == 'null':
        return None
    if node.get('format') == 'date-time':
        return STAMP
    if node.get('format') == 'date':
        return '2026-10-28'
    if node.get('format') == 'uuid' or '0-9a-fA-F' in node.get('pattern', ''):
        return UUID
    if node.get('pattern', '').startswith('^ri'):
        return RID(re.sub(r'(?<!^)(?=[A-Z])', '-', name or 'resource').lower())
    return 'independent087' if kind == 'string' else {}


def encode(value):
    if isinstance(value, bytes):
        return {'__bytes_hex__': value.hex()}
    if isinstance(value, pydantic.BaseModel):
        return encode(value.model_dump(mode='python', by_alias=True, exclude_none=True))
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(v) for v in value]
    return value


def wire(expressions, module, kwargs):
    context = dict(vars(module), **kwargs)
    result = {k: encode(eval(expressions[k], context))
              for k in ('method', 'resource_path', 'query_params', 'path_params', 'header_params', 'body')}
    result['query_params'] = {k: v for k, v in result['query_params'].items() if v is not None}
    return result


def model_api():
    return {'inputs': [{'type': 'parameter', 'name': 'text', 'required': True, 'dataType': {'type': 'string'}}],
            'outputs': [{'type': 'parameter', 'name': 'score', 'dataType': {'type': 'double'}}]}


def rewrite_reply(value, resource, method, kwargs):
    if isinstance(value, list):
        return [rewrite_reply(v, resource, method, kwargs) for v in value]
    if not isinstance(value, dict):
        return value
    result = {k: rewrite_reply(v, resource, method, kwargs) for k, v in value.items()}
    if 'modelRid' in result:
        result['modelRid'] = kwargs.get('model_rid', RID('model'))
    if 'agentRid' in result:
        result['agentRid'] = kwargs.get('agent_rid', RID('agent'))
    if 'agentVersion' in result:
        result['agentVersion'] = '2.3'
    if 'string' in result and isinstance(result.get('version'), dict):
        result.update(string='2.3', version={'major': 2, 'minor': 3})
    if resource == 'Agent' and method == 'get' and 'rid' in result:
        result.update(rid=kwargs['agent_rid'], version=kwargs.get('version') or '2.3',
                      parameters={'question': {'parameterType': {'type': 'string'}, 'access': 'READ_WRITE'}})
    if resource == 'Session' and method in ('create', 'get') and 'rid' in result:
        result['rid'] = kwargs.get('session_rid', RID('session'))
    if resource == 'Experiment' and method == 'get' and 'rid' in result:
        result['rid'] = kwargs['experiment_rid']
    if 'sessionTraceId' in result:
        result['sessionTraceId'] = kwargs.get('session_trace_id', UUID)
    if 'agentMarkdownResponse' in result:
        result.update(agentMarkdownResponse='Two orders are delayed.', parameterUpdates={'question': {'type': 'string', 'value': 'Which orders are delayed?'}}, interruptedOutput=False)
    if resource == 'SessionTrace' and 'id' in result:
        result['id'] = kwargs['session_trace_id']
    if resource == 'Model' and method in ('get', 'create') and 'rid' in result:
        result['rid'] = kwargs.get('model_rid', RID('model'))
    if resource in ('ModelVersion', 'Model') and 'modelApi' in result:
        result.update(rid=kwargs.get('model_version_rid', RID('promoted-version') if method == 'promote_version' else RID('model-version')),
                      modelApi=copy.deepcopy(kwargs.get('model_api', model_api())),
                      condaRequirements=kwargs.get('conda_requirements', ['python=3.11']),
                      backingRepositories=kwargs.get('backing_repositories', [RID('repository')]))
    if resource == 'ModelFunction' and 'functionRid' in result:
        result.update(functionRid=RID('function'), functionVersion='2.3', apiName=kwargs.get('api_name', 'scoreText'),
                      displayName=kwargs.get('display_name', 'Score text'), isRowWise=kwargs.get('is_row_wise', True))
    if resource == 'LiveDeployment' and 'runtimeConfiguration' in result:
        result.update(rid=kwargs.get('live_deployment_rid', RID('deployment')),
                      runtimeConfiguration=copy.deepcopy(kwargs.get('runtime_configuration', {'minReplicas': 1, 'maxReplicas': 2})),
                      modelVersion={'modelRid': RID('model'), 'modelVersionRid': RID('model-version')})
    if resource == 'ModelStudio' and 'rid' in result:
        result['rid'] = kwargs.get('model_studio_rid', RID('studio'))
    if resource == 'ModelStudioConfigVersion' and 'trainer' in result:
        result.update(name=kwargs.get('name', 'Independent trainer configuration'), version=kwargs.get('model_studio_config_version_version', 2),
                      trainerId=kwargs.get('trainer_id', RID('trainer')), trainer={'trainerId': kwargs.get('trainer_id', RID('trainer')), 'version': '2.3'},
                      resources=copy.deepcopy(kwargs.get('resources', {'memory': '2Gi', 'cpu': '1'})),
                      workerConfig=copy.deepcopy(kwargs.get('worker_config', {'inputs': {}, 'outputs': {}})))
    if resource == 'ModelStudioTrainer' and 'trainerId' in result:
        result.update(trainerId=kwargs.get('model_studio_trainer_trainer_id', RID('trainer')),
                      version=kwargs.get('version') or '2.3')
    return result


domain = json.loads((REPO / 'maintainer/rest-domain-authoring-register.json').read_bytes())
oracle_path = REPO / 'tests/fixtures/offline/rest-acceptance/source-oracle.json'
oracle = json.loads(oracle_path.read_bytes())
rows = []
validation_gaps = []
for index, asset in enumerate((r for r in domain['operations'] if r['story'] == 'DEV-STORY-087'), 1):
    version, service, resource, method = asset['id'].split('.')
    module_name = 'foundry_sdk.' + version + '.' + service + '.' + re.sub(r'(?<!^)(?=[A-Z])', '_', resource).lower()
    module = importlib.import_module(module_name)
    source_path = Path(module.__file__)
    source = source_path.read_text()
    tree = ast.parse(source)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == resource + 'Client')
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == method)
    call = next(n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'RequestInfo')
    expressions = {kw.arg: ast.unparse(kw.value) for kw in call.keywords}
    assert sha(source_path) == oracle['operations'][asset['id']]['source_sha256']
    schemas, kwargs = {}, {}
    for arg in [*fn.args.args, *fn.args.kwonlyargs]:
        if arg.arg in ('self', '_sdk_internal', 'request_timeout'):
            continue
        annotation = eval(ast.unparse(arg.annotation), vars(module))
        schemas[arg.arg] = pydantic.TypeAdapter(annotation).json_schema()
        kwargs[arg.arg] = sample(schemas[arg.arg], name=arg.arg)
    defaults = {arg.arg for arg, default in zip(fn.args.kwonlyargs, fn.args.kw_defaults) if default is not None and arg.arg in kwargs}
    for name in defaults:
        kwargs[name] = None
    kwargs.update({k: RID(k.removesuffix('_rid')) for k in kwargs if k.endswith('_rid')})
    overrides = {'preview': True, 'page_size': 2, 'page_token': None, 'version': '2.3', 'agent_version': '2.3',
                 'agent_version_string': '2.3', 'session_trace_id': UUID, 'message_id': UUID,
                 'model_studio_config_version_version': 2, 'name': 'Independent087 resource',
                 'title': 'Independent review session', 'parameter_inputs': {'question': {'type': 'string', 'value': 'Which orders are delayed?'}},
                 'user_input': {'text': 'Which orders are delayed?'}, 'max_tokens': 128,
                 'messages': [{'role': 'USER', 'content': [{'type': 'text', 'text': 'Summarize delayed orders.'}]}],
                 'anthropic_model_model_id': 'claude-independent087', 'open_ai_model_model_id': 'text-embedding-3-independent087',
                 'input': ['Order delayed'] if service == 'language_models' else {'text': 'Order delayed'},
                 'runtime_configuration': {'minReplicas': 1, 'maxReplicas': 2, 'cpu': '1', 'memory': '2Gi', 'threadCount': 1},
                 'deployment_type': {'type': 'direct', 'modelRid': RID('model'), 'branch': 'master'},
                 'api_name': 'scoreText', 'display_name': 'Score text', 'is_row_wise': True,
                 'trainer_id': RID('trainer'), 'model_studio_trainer_trainer_id': RID('trainer'),
                 'resources': {'memory': '2Gi', 'cpu': '1'}, 'worker_config': {'inputs': {}, 'outputs': {}},
                 'model_api': model_api(), 'model_files': {'type': 'dill', 'serializedModelFunction': 'c3ludGhldGljLW5vdC1leGVjdXRhYmxl'},
                 'backing_repositories': [RID('repository')], 'conda_requirements': ['python=3.11'],
                 'branch': 'master', 'experiment_artifact_table_name': 'predictions', 'experiment_series_name': 'accuracy',
                 'offset': 0, 'where': None, 'order_by': None}
    kwargs.update({k: copy.deepcopy(v) for k, v in overrides.items() if k in kwargs})
    response_type = eval(expressions['response_type'], vars(module))
    response_schema = pydantic.TypeAdapter(response_type).json_schema()
    reply = rewrite_reply(sample(response_schema), resource, method, kwargs)
    if resource == 'OpenAiModel':
        reply = {'data': [[0.25, 0.75]], 'model': kwargs['open_ai_model_model_id'], 'usage': {'promptTokens': 3}}
    if resource == 'AnthropicModel':
        reply.update(id='independent-message087', model=kwargs['anthropic_model_model_id'], role='ASSISTANT',
                     content=[{'type': 'text', 'text': 'Two orders are delayed.'}], usage={'inputTokens': 8, 'outputTokens': 6})
    success = {'http_status': 204 if response_type is None else 200, 'json': reply, 'result_type': expressions['response_type'], 'schema': response_schema}
    if response_type is bytes:
        binary = (b'[{"score":0.75}]' if method == 'json' else b'PAR1-independent087-fixture-PAR1') if resource != 'Session' else b'event: complete\ndata: {"message":"done"}\n\n'
        success = {'http_status': 200, 'content_hex': binary.hex(), 'expected_bytes_hex': binary.hex(), 'result_type': 'bytes', 'schema': response_schema,
                   'boundary': 'Synthetic bytes exercise lifetime and exact persistence only; PAR1 marker is not a valid Parquet artifact.'}
    expected_wire = wire(expressions, module, kwargs)
    errors = []
    mapping = {'BadRequestError': (400, 'INVALID_ARGUMENT'), 'InternalServerError': (500, 'INTERNAL'),
               'UnauthorizedError': (401, 'UNAUTHORIZED'), 'UnprocessableEntityError': (422, 'INVALID_ARGUMENT'),
               'NotFoundError': (404, 'NOT_FOUND'), 'PermissionDeniedError': (403, 'PERMISSION_DENIED'),
               'InvalidArgumentError': (400, 'INVALID_ARGUMENT'), 'ConflictError': (409, 'CONFLICT'),
               'InternalError': (500, 'INTERNAL'), 'FailedPreconditionError': (400, 'FAILED_PRECONDITION'),
               'RequestEntityTooLargeError': (413, 'REQUEST_ENTITY_TOO_LARGE'), 'TimeoutError': (500, 'TIMEOUT'),
               'CustomClientError': (400, 'CUSTOM_CLIENT'), 'CustomServerError': (500, 'CUSTOM_SERVER')}
    for error_name, error_class in eval(expressions['throwable_errors'], vars(module)).items():
        parameter_type = typing.get_type_hints(error_class)['parameters']
        error_schema = pydantic.TypeAdapter(parameter_type).json_schema()
        params = sample(error_schema)
        error_kwargs = copy.deepcopy(kwargs)
        available = dict(expected_wire['query_params'], **expected_wire['path_params'])
        if isinstance(expected_wire['body'], dict):
            available.update(expected_wire['body'])
        params.update({k: copy.deepcopy(v) for k, v in available.items() if k in params})
        aliases = {'studioRid': ('model_studio_rid',),
                   'artifactName': ('experiment_artifact_table_name',),
                   'seriesName': ('experiment_series_name',),
                   'displayName': ('name', 'display_name'),
                   'trainerId': ('model_studio_trainer_trainer_id', 'trainer_id'),
                   'configVersion': ('model_studio_config_version_version', 'config_version'),
                   'modelVersionRid': ('model_version_rid', 'source_model_version_rid'),
                   'agentVersionString': ('agent_version_string', 'agent_version', 'version')}
        for target, arguments in aliases.items():
            if target in params:
                value = next((kwargs[key] for key in arguments if kwargs.get(key) is not None), None)
                if value is not None:
                    params[target] = copy.deepcopy(value)
        condition = ['Synthetic service state returns this source-declared named error; the SDK does not prove tenant validation or authorization.']
        if error_name == 'ModelNotFound' and isinstance(kwargs.get('deployment_type'), dict):
            params['modelRid'] = kwargs['deployment_type']['modelRid']
        if error_name == 'ModelStudioConfigVersionNotFound' and 'config_version' in error_kwargs:
            error_kwargs['config_version'] = 2
            params['configVersion'] = 2
            condition = ['The request filters runs by configuration version 2; the synthetic service reports that same configuration missing.']
        if error_name == 'InvalidDisplayName':
            error_kwargs['name'] = '..'
            params['displayName'] = '..'
            condition = ['The source explicitly rejects the display name ..; the adverse request and error parameter use that value.']
        if error_name == 'InvalidParameter' and 'parameter_inputs' in error_kwargs:
            error_kwargs['parameter_inputs'] = {'unknownVariable087': {'type': 'string', 'value': 'Order delayed'}}
            params['parameter'] = 'unknownVariable087'
            condition = ['The synthetic agent has only the question variable; the request supplies unknownVariable087 and the service reports that variable invalid.']
        if error_name == 'OntologyNotFound' and 'ontology_binding' in error_kwargs:
            error_kwargs['ontology_binding'] = RID('missing-ontology')
            params['ontologyRid'] = RID('missing-ontology')
            condition = ['The request explicitly binds the missing synthetic ontology identified by the error.']
        if error_name == 'InvalidFunctionApiName':
            condition = ['Typed service-error decoding only: the SDK declares this error but provides no API-name format constraint. The synthetic service rejects scoreText under an unspecified tenant rule; this does not establish a universal validation rule.']
        if error_name == 'InvalidAgentVersion':
            argument = next((key for key in ('agent_version_string', 'agent_version', 'version') if key in error_kwargs), None)
            if argument is not None:
                error_kwargs[argument] = 'invalid-version087'
                params.update({key: 'invalid-version087' for key in ('version', 'agentVersionString') if key in params})
                condition = ['The adverse request uses invalid-version087 instead of the documented major.minor format; the mock service returns the declared error.']
        if error_name == 'InvalidPageSize' and 'page_size' in kwargs:
            error_kwargs['page_size'] = 0
            params['pageSize'] = 0
            condition = ['Zero page size is invalid; rejection comes from the synthetic service, not a fabricated client validation constraint.']
        if 'InvalidParameterType' in error_name:
            params.update({k: v for k, v in {'expectedType': 'string', 'receivedType': 'objectSet'}.items() if k in params})
            if 'parameter' in params:
                params['parameter'] = 'question'
            if 'parameter_inputs' in error_kwargs:
                error_kwargs['parameter_inputs'] = {'question': {'type': 'objectSet', 'ontology': 'independent087', 'objectSet': {'type': 'static', 'objects': []}}}
        if 'MultipleSystemPrompts' in error_name:
            error_kwargs['system'] = [{'type': 'text', 'text': 'First prompt'}, {'type': 'text', 'text': 'Second prompt'}]
            params['systemPromptSize'] = 2
            condition = ['The request contains two system blocks; the source permits at most one.']
        if 'MultipleToolResult' in error_name:
            params['toolResultContentsSize'] = 2
            error_kwargs['messages'] = [{'role': 'USER', 'content': [{'type': 'toolResult', 'toolUseId': 'independent-tool087',
                'content': [{'type': 'text', 'text': 'First result'}, {'type': 'text', 'text': 'Second result'}]}]}]
            condition = ['One synthetic toolResult contains two text contents; the declared error rejects multiple contents. No real tool execution is claimed.']
        if 'requestedGpuType' in params:
            params.update(requestedGpuType='A100', availableGpuTypes=['T4'])
            error_kwargs['runtime_configuration']['gpu'] = {'count': 1, 'type': 'A100'}
        for provided, maximum in [('providedGpuCount', 'maxGpuCount'), ('providedThreadCount', 'maxThreadCount'), ('provided', 'max')]:
            if provided in params and maximum in params:
                params.update({provided: 3, maximum: 2})
                if 'runtime_configuration' in error_kwargs:
                    error_kwargs['runtime_configuration']['threadCount' if 'Thread' in error_name else 'gpu'] = 3 if 'Thread' in error_name else {'count': 3, 'type': 'T4'}
        base = next((c.__name__ for c in error_class.__mro__[1:] if c.__name__ in mapping), None)
        assert base, (asset['id'], error_name, error_class.__mro__)
        status, code = mapping[base]
        envelope = {'errorName': error_name, 'errorCode': code, 'errorInstanceId': UUID, 'parameters': params}
        errors.append({'name': error_name, 'status': status, 'errorCode': code, 'parameters': params,
                       'parameter_schema': error_schema, 'error_source': inspect.getfile(error_class),
                       'error_source_sha256': sha(inspect.getfile(error_class)), 'error_base': base,
                       'request': encode(error_kwargs), 'expected_wire': wire(expressions, module, error_kwargs),
                       'envelope': envelope, 'source_condition': condition,
                       'source_description': inspect.getdoc(error_class),
                       'expected': {'exception_class': error_class.__module__ + '.' + error_name,
                                    'name': error_name, 'parameters': copy.deepcopy(params), 'error_instance_id': UUID}})
    async_cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Async' + resource + 'Client')
    async_fn = next(n for n in async_cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method)
    assets = {kind: {'path': asset[kind] if kind != 'contract' else 'references/rest/contracts/' + asset['id'].replace('.', '/') + '.md',
                     'sha256': sha(OWNER / (asset[kind] if kind != 'contract' else 'references/rest/contracts/' + asset['id'].replace('.', '/') + '.md'))}
              for kind in ('behavior', 'example', 'contract')}
    row = {'case_id': f'F087-{index:02d}', 'operation': asset['id'], 'source': {'module': module_name, 'path': str(source_path),
           'sha256': sha(source_path), 'method_source_sha256': hashlib.sha256(ast.get_source_segment(source, fn).encode()).hexdigest(),
           'async_method_source_sha256': hashlib.sha256(ast.get_source_segment(source, async_fn).encode()).hexdigest(),
           'line': fn.lineno, 'docstring': ast.get_docstring(fn), 'request_expressions': expressions, 'oracle_sha256': sha(oracle_path)},
           'assets': assets, 'request': {'kwargs': encode(kwargs), 'argument_schemas': schemas, 'expected_wire': expected_wire,
           'path_prefix': '/api', 'timeout': 7, 'authorization': 'Bearer independent-qa-087'}, 'success': success, 'errors': errors,
           'additional_cases': [], 'semantic_expectation': ast.get_docstring(fn).split(':param')[0].strip(),
           'source_silence': ['Mock transport does not prove tenant access, service lifecycle effects, billing, inference quality or idempotency.'],
           'review': {'example_fixture_executed': False}}
    extras = row['additional_cases']
    minimal = copy.deepcopy(kwargs)
    minimal.update({k: None for k in defaults if k != 'preview'})
    extras.append({'name': 'optional omission', 'request': encode(minimal), 'expected_wire': wire(expressions, module, minimal),
                   'response': copy.deepcopy(reply), 'response_status': success['http_status'], 'success': copy.deepcopy(success)})
    required = [a.arg for a in fn.args.args[:len(fn.args.args) - len(fn.args.defaults)] if a.arg != 'self'] + [a.arg for a, d in zip(fn.args.kwonlyargs, fn.args.kw_defaults) if d is None]
    if required:
        missing = copy.deepcopy(kwargs)
        missing.pop(required[0])
        extras.append({'name': 'required argument omitted', 'request': encode(missing), 'expected_exception': 'pydantic.ValidationError',
                       'omitted_parameter': required[0], 'expected_request_count': 0})
    if 'page_token' in kwargs:
        first, second = copy.deepcopy(kwargs), copy.deepcopy(kwargs)
        first['page_token'] = None
        second['page_token'] = 'independent-next087'
        a, b = copy.deepcopy(reply), copy.deepcopy(reply)
        a['nextPageToken'] = 'independent-next087'
        b.pop('nextPageToken', None)
        item = b['data'][0]
        if isinstance(item, dict):
            if resource == 'AgentVersion':
                item.update(string='2.2', version={'major': 2, 'minor': 2})
            elif resource == 'ModelStudioConfigVersion':
                item['version'] = 3
            elif 'rid' in item:
                item['rid'] = RID('second-page-' + resource.lower())
            elif 'runId' in item:
                item['runId'] = RID('second-run')
        extras.append({'name': 'finite continuation', 'requests': [encode(first), encode(second)],
                       'expected_wires': [wire(expressions, module, first), wire(expressions, module, second)],
                       'responses': [a, b], 'response_status': 200, 'expected_request_count': 2, 'expected_terminal_token': None})
    if resource == 'ModelStudioConfigVersion' and method == 'get':
        row['native_sdk_limitation'] = {'expected_exception': 'TypeError', 'message_contains': 'quote_from_bytes() expected bytes',
                                        'expected_request_count': 0, 'cause': 'Pinned SDK integer path is passed to urllib quote without conversion.'}
        row['direct_rest_adapter'] = {'path': 'examples/rest/087/model_studio_config_version.py',
                                      'sha256': sha(OWNER / 'examples/rest/087/model_studio_config_version.py'),
                                      'call': 'get_config_version', 'kwargs': {'hostname': 'independent-qa.invalid', 'token': 'independent-qa-087',
                                      'studio_rid': kwargs['model_studio_rid'], 'version': 2, 'preview': True, 'timeout': 7},
                                      'required_checks': ['native failure before HTTP', 'typed bridge success', 'both named 404s', 'unknown 403',
                                      'byte and chunk budgets', 'malformed JSON', 'bool/string version rejected', 'response closure']}
    row['gherkin'] = {'feature': asset['id'], 'scenarios': [
        {'name': row['case_id'] + ' source-derived request and result', 'given': ['Pinned SDK and all source/asset hashes match.', 'Deny sockets and DNS; synthetic HTTP only.'],
         'when': ['Call exact operation in declared sync/async/raw/stream modes using request literals.'],
         'then': ['Compare HTTP method/path/query/headers/body and timeout7.', 'Decode declared SDK response or exact bytes; close responses and transports.']},
        {'name': row['case_id'] + ' every declared error', 'given': ['Use each errors entry with its source-derived request and error literal.'],
         'when': ['Synthetic service returns its literal status/envelope.'], 'then': ['Assert exact named SDK exception and typed parameters; no successful result.']}]}
    row['case_sha256'] = hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    rows.append(row)
manifest = {'story': 'DEV-STORY-087', 'testcase': 'TESTCASE-068', 'author_identity': AUTHOR, 'sdk_release': '1.101.0',
            'source_commit': oracle['source_commit'], 'reviewed_candidate_sha': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip(),
            'generation_method': 'Installed SDK AST, annotations, request/response/error definitions. Author register supplies operation IDs and asset paths. No example EXPECTED/SUCCESS/ERRORS values are used as oracles and no example invoke/verify is run. The direct-REST adapter implementation was inspected to target its callable and response budgets.',
            'approval': 'PENDING_INDEPENDENT_REVIEW', 'execution': 'NOT_RUN', 'operations': rows, 'review_gaps': validation_gaps,
            'network_policy': {'required': 'Deny public socket connect/connect_ex/create_connection and DNS; use fresh synthetic httpx.MockTransport.'}}
manifest['journeys'] = [{'id': 'J14', 'case': 'isolated agent version/session conversation',
    'sequence': ['v2.aip_agents.Agent.get', 'v2.aip_agents.AgentVersion.get', 'v2.aip_agents.Session.create',
                 'v2.aip_agents.Session.blocking_continue', 'v2.aip_agents.Content.get', 'v2.aip_agents.SessionTrace.get',
                 'v2.aip_agents.Session.update_title', 'v2.aip_agents.Session.get', 'v2.aip_agents.Session.delete'],
    'assertions': ['Selected agent and version match created session.', 'Writable question parameter matches continuation input.',
                   'Trace ID links result to trace request.', 'Session.get.metadata.title verifies update_title, which returns None.',
                   'Delete ends the local synthetic session; this does not prove service-side deletion or transaction atomicity.'],
    'adverse': 'Denied Agent.get stops the journey before any session mutation.',
    'boundaries': ['Each response is a local synthetic service state, not real inference.',
                   'Streaming bytes, canceled-message request and wrapper cleanup are checked separately per operation.']}]
out = TMP / 'rest087_formal_cases.json'
out.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'operations': len(rows), 'errors': sum(len(r['errors']) for r in rows), 'manifest_sha256': sha(out)}))
